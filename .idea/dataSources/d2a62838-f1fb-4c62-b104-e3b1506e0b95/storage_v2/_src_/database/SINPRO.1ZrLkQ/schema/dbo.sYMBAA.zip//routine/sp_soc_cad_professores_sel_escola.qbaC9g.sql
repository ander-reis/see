
/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_sel_escola
Descriçao:	Seleciona Escolas do Professor
Entrada:	@pNvc_professor  -> Codigo do Professor
Saída:		
Data da Criaçao: 14/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_sel_escola
(
@pNvc_professor		NVARCHAR(5)
)
AS

SELECT 
	PGE.CGC_Escola, 
	CE.Razao_Social, 
	COALESCE(CE.Nome_Fantasia,CE.Razao_Social) AS Nome_Fantasia,  
	CASE PGE.Cobranca
		WHEN 1 THEN 'Sim'
		ELSE	'Não'
	END AS Cobranca, 
	RTRIM(CASE CONVERT(CHAR(10),PGE.Data_Cobranca,103)
		WHEN '01/01/1900' THEN ''
		ELSE	CONVERT(CHAR(10),PGE.Data_Cobranca,103) 
	END) AS Data_Cobranca, 

	CASE PGE.Situacao
		WHEN 1 THEN 'Ativo'
 		WHEN 2 THEN 'Admitido'
		WHEN 4 THEN 'Lic. Sem Remuneração'
		WHEN 5 THEN 'Lic. Com Remuneração'
		WHEN 7 THEN 'Lic. Saúde'
	END AS Situacao,

	RTRIM(CASE CONVERT(CHAR(10),PGE.Data_Admissao,103)
		WHEN '01/01/1900' THEN ''
		ELSE	CONVERT(CHAR(10),PGE.Data_Admissao,103) 
	END) AS Data_Admissao,  

	RTRIM(CASE CONVERT(CHAR(10),PGE.Data_Cadastro,103)
		WHEN '01/01/1900' THEN ''
		ELSE	CONVERT(CHAR(10),PGE.Data_Cadastro,103) 
	END) AS Data_Cadastro  

FROM Professores_Geral_Escolas as PGE INNER JOIN 
	Cadastro_Escolas  as CE ON PGE.CGC_Escola = CE.CGC_Escola  

WHERE /* PGE.Codigo_Professor = @pNvc_professor */
	PGE.CPF = (SELECT TOP 1 CPF FROM Professores_Geral_Escolas WHERE Codigo_Professor = @pNvc_professor)
	AND PGE.CGC_Escola <> '000.000.000/0000-00' 
	AND PGE.Situacao IN (1,2,4,5,6,7,8) 
	AND PGE.status_web <> '4' 

ORDER BY PGE.Data_Cobranca DESC,CE.Razao_Social
go

