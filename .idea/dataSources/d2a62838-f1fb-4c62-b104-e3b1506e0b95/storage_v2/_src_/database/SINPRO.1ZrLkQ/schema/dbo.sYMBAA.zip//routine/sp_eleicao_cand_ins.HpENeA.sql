

/*******************************************************************
Objeto criado: 	 sp_eleicao_cand_ins
Descriçao:	Inclui Cadastro do Candidato e Atualiza o Cadastro do Professor
Data da Criaçao: 04/07/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_cand_ins
(
@Pcd_candidato		NVARCHAR(5),

@Pnr_cargo			TINYINT,
@Pds_eleicao			CHAR(4),
@Pds_chapa			CHAR(2),

@Pnm_mae			NVARCHAR(100),
@Pnm_pai			NVARCHAR(100),
@ds_cidade_nasc		NVARCHAR(21),
@Pds_uf_nasc			CHAR(2),
@Pfl_civil			TINYINT,
@Pds_orgao_rg			NVARCHAR(6),
@Pdt_exped_rg			DATETIME,
@Pds_pis			NVARCHAR(14),
@Pds_ctps			NVARCHAR(11),
@Pds_ctps_serie		NVARCHAR(6),
@Pds_posicao			NVARCHAR(3)
    
)
AS

UPDATE Cadastro_Professores SET
	PIS			= @Pds_pis,
	Estado_Civil		= @Pfl_civil,
	CTPS			= @Pds_ctps,
	CTPS_Serie		= @Pds_ctps_serie,
	Nome_Mae		= @Pnm_mae,
	Orgao_Expedidor	= @Pds_orgao_rg,
	Cidade_Nasc		= @ds_cidade_nasc,
	UF_Nasc		= @Pds_uf_nasc,
	Data_Expedicao		= @Pdt_exped_rg,
	Nome_Pai		= @Pnm_pai
WHERE Codigo_Professor = @Pcd_candidato

INSERT INTO tb_ele_cand_dados (
	ele_cda_cd_candidato,		
	ele_cda_nr_cargo,
	ele_cda_ds_eleicao,	
	ele_cda_ds_chapa,
	ele_cda_ds_posicao) 
VALUES (
	@Pcd_candidato,
	 @Pnr_cargo,
	@Pds_eleicao,
	@Pds_chapa,
	@Pds_posicao
	)
go

