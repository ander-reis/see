

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_financeiro_sel
Descriçao:	Seleciona o Financeiro do Professor para possível alteração de conta
Data da Criaçao: 05/07/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_financeiro_sel
(
@Pcd_professor	NVARCHAR(5)
)
AS

SELECT
	PCF.jur_pcf_nr_pagamento,
	PCF.jur_pcf_nr_pasta,
	PCF.jur_pcf_nr_parcela,
	CONVERT(NVARCHAR(10),PCF.jur_pcf_dt_vencimento,103) AS jur_pcf_dt_vencimento,
	CONVERT(DECIMAL(10,2),PCF.jur_pcf_vl_parcela - PCF.jur_pcf_vl_taxa - PCF.jur_pcf_vl_honorario) AS jur_pcf_vl_total,
	PCF.jur_pcf_ds_titulo,
	FIP.jur_fip_cd_professor
FROM
	 tb_jur_ficha_professor FIP
	INNER JOIN tb_jur_processo_financeiro PCF
	 ON FIP.jur_fip_cd_fic_pro = PCF.jur_pcf_cd_fic_pro
WHERE
	FIP.jur_fip_cd_professor = @Pcd_professor
	AND PCF.jur_pcf_fl_destino = 0
	AND PCF.jur_pcf_ds_forma = 'DOC'
	AND PCF.jur_pcf_fl_situacao <> 5
ORDER BY
	CONVERT(CHAR(8),jur_pcf_dt_vencimento,112), jur_pcf_nr_parcela
go

