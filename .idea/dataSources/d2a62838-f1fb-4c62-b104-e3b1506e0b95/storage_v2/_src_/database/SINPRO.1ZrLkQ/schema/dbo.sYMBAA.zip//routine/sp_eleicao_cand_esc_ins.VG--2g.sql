

/*******************************************************************
Objeto criado: 	sp_eleicao_cand_esc_ins
Descriçao:	Inclui Observação do Candidato
Saída:		
Data da Criaçao: 29/09/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_cand_esc_ins
(
@Pcd_candidato	CHAR(5),
@Pcd_escola		NVARCHAR(18)
)
AS

INSERT INTO tb_ele_cand_escola (
	ele_ces_cd_candidato,
	ele_ces_cd_escola) 
VALUES (
	@Pcd_candidato,
	@Pcd_escola
	)

go

