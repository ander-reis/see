/*******************************************************************
Objeto criado: 	 sp_email_see_observacao_sel
Descriçao:	Carrega os e-mails já cadastrados para envio
Data da Criaçao: 24/06/2015
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE [dbo].[sp_email_see_observacao_sel]
(
@Pfl_tipo			TINYINT,
@Pcd_observacao		NVARCHAR(30)
)

AS
IF @Pfl_tipo = 0
	SELECT
		ema_see_cd_observacao, 
		ema_see_ds_de, ema_see_ds_exibir, ema_see_ds_assunto, ema_see_ds_copia, ema_see_ds_para, 
	             CAST(ema_see_ds_lista AS TEXT) AS ema_see_ds_lista, ema_see_ds_tipo, ema_see_ds_login, CONVERT(CHAR(10),ema_see_dt_envio,103) + ' ' + CONVERT(CHAR(5),ema_see_dt_envio,108) AS ema_see_dt_envio,
		CONVERT(CHAR(10),ema_see_dt_envio,103) + ' ' + CONVERT(CHAR(5),ema_see_dt_envio,108) AS ema_see_dt_envio,
		CASE WHEN CONVERT(CHAR(10),ema_see_dt_inicio,103) <> '01/01/1900' THEN
			CONVERT(CHAR(10),ema_see_dt_inicio,103) + ' ' + CONVERT(CHAR(5),ema_see_dt_inicio,108)
		ELSE
			''
		END  AS ema_see_dt_inicio,
		CASE WHEN	CONVERT(CHAR(10),ema_see_dt_fim,103) <> '01/01/1900' THEN
			CONVERT(CHAR(10),ema_see_dt_fim,103) + ' ' + CONVERT(CHAR(5),ema_see_dt_fim,108)
		ELSE
			'' 
		END AS ema_see_dt_fim,
		CASE ema_see_fl_status
			WHEN 0 THEN 'Agendado'
			WHEN 1 THEN 'Enviando'
			WHEN 2 THEN 'Enviado'
		END as ema_see_ds_status,
		ema_see_fl_status
	FROM         tb_email_see
	ORDER BY CONVERT(CHAR(10),ema_see_dt_envio,111) + ' ' + CONVERT(CHAR(5),ema_see_dt_envio,108) DESC, CONVERT(CHAR(10),ema_see_dt_cadastro,111) + ' ' + CONVERT(CHAR(5),ema_see_dt_cadastro,108) 

ELSE IF @Pfl_tipo = 1
	SELECT
		ema_see_cd_observacao, 
		CAST(ema_see_ds_email AS TEXT) AS ema_see_ds_email, 
		 ema_see_ds_de, ema_see_ds_exibir, ema_see_ds_assunto, ema_see_ds_copia, ema_see_ds_para, 
	             CAST(ema_see_ds_lista AS TEXT) AS ema_see_ds_lista, ema_see_ds_tipo, ema_see_ds_login, CONVERT(CHAR(10),ema_see_dt_envio,103) + ' ' + CONVERT(CHAR(5),ema_see_dt_envio,108) AS ema_see_dt_envio,
		CONVERT(CHAR(10),ema_see_dt_envio,103) + ' ' + CONVERT(CHAR(5),ema_see_dt_envio,108) AS ema_see_dt_envio,
		CASE WHEN CONVERT(CHAR(10),ema_see_dt_inicio,103) <> '01/01/1900' THEN
			CONVERT(CHAR(10),ema_see_dt_inicio,103) + ' ' + CONVERT(CHAR(5),ema_see_dt_inicio,108)
		ELSE
			''
		END  AS ema_see_dt_inicio,
		CASE WHEN	CONVERT(CHAR(10),ema_see_dt_fim,103) <> '01/01/1900' THEN
			CONVERT(CHAR(10),ema_see_dt_fim,103) + ' ' + CONVERT(CHAR(5),ema_see_dt_fim,108)
		ELSE
			'' 
		END AS ema_see_dt_fim,
		CASE ema_see_fl_status
			WHEN 0 THEN 'Agendado'
			WHEN 1 THEN 'Enviando'
			WHEN 2 THEN 'Enviado'
		END as ema_see_ds_status,
		ema_see_fl_status
	FROM         tb_email_see
	WHERE ema_see_cd_observacao = @Pcd_observacao	
	ORDER BY CONVERT(CHAR(10),ema_see_dt_envio,111) + ' ' + CONVERT(CHAR(5),ema_see_dt_envio,108) DESC, CONVERT(CHAR(10),ema_see_dt_cadastro,111) + ' ' + CONVERT(CHAR(5),ema_see_dt_cadastro,108)

ELSE IF @Pfl_tipo = 2
	SELECT
		ema_see_ds_lista
	FROM         tb_email_see
	WHERE ema_see_cd_observacao = @Pcd_observacao
go

