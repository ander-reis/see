

/*******************************************************************
Objeto criado: 	 sp_eleicao_cand_sel
Descriçao:	Seleciona Candidatos
Data da Criaçao: 03/07/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_cand_sel
(
@Pcd_matricula		NVARCHAR(14),
@Pfl_tipo			Tinyint,
@Pds_eleicao		CHAR(4)
)
AS

DECLARE @Vmatricula		NVARCHAR(5),
	@Vescola		INT

IF @Pfl_tipo = 1
	SELECT @Vmatricula = Codigo_Professor
	FROM Cadastro_Professores 
	WHERE CPF = @Pcd_matricula
ELSE
	SET @Vmatricula = @Pcd_matricula

SELECT 
	Codigo_Professor, 
	Nome, 
	Sexo, 

	RTRIM(CASE CONVERT(CHAR(10),Data_Aniversario,103)
		WHEN '01/01/1900' THEN ''
		ELSE	CONVERT(CHAR(10),Data_Aniversario,103)
	END)  AS Data_Aniversario, 

	CPF, 
	RG,

	RTRIM(CASE CONVERT(CHAR(10),Data_Modificacao,103)
		WHEN '01/01/1900' THEN ''
		ELSE	CONVERT(CHAR(10),Data_Modificacao,103)
	END) AS Data_Modificacao, 

	CEP, 
	Endereco, 
	Numero, 
	Complemento, 
	Bairro, 
	Cidade, 
	Estado, 
	DDD_Telefone_Residencial, 
	Telefone_Residencial, 
	DDD_Telefone_Celular, 
	Telefone_Celular, 
	LEFT(CASE   WHEN ISNULL(pro_ema_ds_email1,'') <> '' THEN ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END 
		         + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END,
		         LEN(CASE   WHEN  ISNULL(pro_ema_ds_email1,'') <> '' THEN  ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END) -1) AS Email,
	Situacao, 
	CASE	Situacao
		WHEN   1 THEN 'Ativo'
		WHEN   2 THEN 'Aposentado'
		WHEN   4 THEN 'Cancelado'
		WHEN   5 THEN 'Licença Com Remuneração'
		WHEN   6 THEN 'Desvinculado'
		WHEN   7 THEN 'Não Sindicalizado'
		WHEN   8 THEN 'Aposentado Cancelado'
		WHEN   9 THEN 'Licença Sem Remuneração'
		WHEN 10 THEN 'Aposentado Especial'
		WHEN 11 THEN 'Aposentado Desvinculado'
		WHEN 12 THEN 'Aposentado Ativo'
		WHEN 13 THEN 'Licença Saúde'
	END AS Desc_Situacao,

	RTRIM(CASE CONVERT(CHAR(10),Data_Inicio,103)
		WHEN '01/01/1900' THEN ''
		ELSE	CONVERT(CHAR(10),Data_Inicio,103)
	END) AS Data_Inicio,

	Estado_Civil,
	PIS, 
	CTPS, 
	CTPS_Serie, 
	Nome_Mae,
	Orgao_Expedidor,
	Cidade_Nasc,

	RTRIM(UF_Nasc) AS UF_Nasc,
	
	RTRIM(CASE CONVERT(CHAR(10),Data_Expedicao,103)
		WHEN '01/01/1900' THEN ''
		ELSE	CONVERT(CHAR(10),Data_Expedicao,103)
	END) AS Data_Expedicao, 

	Nome_Pai

FROM Cadastro_Professores CP LEFT JOIN tb_professor_email ON CP.Codigo_Professor  = pro_ema_cd_professor 
WHERE Codigo_Professor = @Vmatricula

--Eleicao
SELECT
	ele_cda_ds_eleicao ,
	ele_cda_nr_cargo,
	ele_cda_ds_chapa,
	ele_cda_ds_posicao,
	CONVERT(CHAR(10),ele_cda_dt_cadastro,103) + ' ' + CONVERT(CHAR(8),ele_cda_dt_cadastro,108) AS ele_cda_dt_cadastro
FROM tb_ele_cand_dados 
WHERE ele_cda_cd_candidato = @Vmatricula AND ele_cda_ds_eleicao = @Pds_eleicao

-- Escola
SELECT 
	@Vescola = COUNT(1)
FROM tb_ele_cand_escola
WHERE ele_ces_cd_candidato = @Vmatricula
	
IF @Vescola >= 1
	SELECT 
	CES.ele_ces_cd_escola AS CNPJ, 
	CE.Razao_Social, 
	COALESCE(CE.Nome_Fantasia,CE.Razao_Social) AS Nome_Fantasia,
	CE.Endereco + ', ' + CE.Numero AS Endereco,
	CE.Bairro + ', ' + CE.Cidade + ', SP - '  + CE.CEP AS Bairro_Cidade_UF_CEP,
	CE.Complemento,
	CE.Telefone1,
	0 AS Situacao
	FROM tb_ele_cand_escola as CES INNER JOIN 
		Cadastro_Escolas  as CE ON CES.ele_ces_cd_escola = CE.CGC_Escola  
	WHERE CES.ele_ces_cd_candidato = @Vmatricula
	ORDER BY CE.Razao_Social

ELSE
	SELECT 
	PGE.CGC_Escola AS CNPJ, 
	CE.Razao_Social, 
	COALESCE(CE.Nome_Fantasia,CE.Razao_Social) AS Nome_Fantasia,
	CE.Endereco + ', ' + CE.Numero AS Endereco,
	CE.Bairro + ', ' + CE.Cidade + ', SP - '  + CE.CEP AS Bairro_Cidade_UF_CEP,
	CE.Complemento,
	CE.Telefone1,
	1 AS Situacao
	FROM Professores_Geral_Escolas as PGE INNER JOIN 
		Cadastro_Escolas  as CE ON PGE.CGC_Escola = CE.CGC_Escola  

	WHERE PGE.Codigo_Professor = @Vmatricula
		AND PGE.CGC_Escola <> '000.000.000/0000-00' 
		AND PGE.Situacao IN (1,2,4,5,6,7,8) 
		AND PGE.status_web <> '4' 
	ORDER BY CE.Razao_Social

--Observacoes

SELECT 
	RTRIM(CASE CONVERT(CHAR(10),ele_cob_dt_observacao,103)
		WHEN '01/01/1900' THEN ''
		ELSE	CONVERT(CHAR(10),ele_cob_dt_observacao,103)
	END)					AS ele_cob_dt_observacao,

	ele_cob_ds_observacao,

	RTRIM(ISNULL(ele_cob_nm_login,''))	AS ele_cob_nm_login,


	RTRIM(CASE CONVERT(CHAR(10),ele_cob_dt_hora,108)
		WHEN '00:00:00' THEN ''
		ELSE	CONVERT(CHAR(10),ele_cob_dt_hora,108)
	END) 					 AS ele_cob_dt_hora
FROM tb_ele_cand_observacao
WHERE ele_cob_cd_candidato = @Vmatricula
ORDER BY CONVERT(CHAR(10),ele_cob_dt_observacao,111) DESC, CONVERT(CHAR(8),ele_cob_dt_hora,108) DESC
go

