/*******************************************************************
Objeto criado: 	 sp_eleicao_urna_funcionario_sel
Descriçao:	Seleciona os Funcionários / Urnas da Eleição
Data da Criaçao: 19/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_urna_funcionario_sel
(
@Pds_eleicao		NVARCHAR(4),
@Pds_urna		INT = 0
)
AS
IF @Pds_urna <> 0
	SELECT     
		FUN.ele_fun_cd_funcionario,
		FUN.ele_fun_nm_funcionario, 
		FUN.ele_fun_ds_endereco + ', ' + FUN.ele_fun_ds_numero AS endereco, 
		FUN.ele_fun_ds_complemento, 
		FUN.ele_fun_ds_bairro,
		FUN.ele_fun_ds_cidade,
		FUN.ele_fun_ds_uf,
		FUN.ele_fun_ds_cep,
		'(' + FUN.ele_fun_nr_ddd_fone_residencial + ')' + FUN.ele_fun_nr_fone_residencial AS ele_fun_nr_fone_residencial,
		'(' + FUN.ele_fun_nr_ddd_celular + ')' + FUN.ele_fun_nr_celular AS ele_fun_nr_celular,
		
		CASE FDA.ele_dad_ds_cargo
			WHEN 0 THEN 'Presidente'
			WHEN 1 THEN 'Mesário'
			ELSE 'Suplente'
		END AS ele_dad_ds_cargo,

		CASE FDA.ele_dad_fl_carro
			WHEN 0 THEN 'Carro'
			WHEN 1 THEN 'Moto'
			ELSE 'Não Possui'
		END AS ele_dad_fl_carro,
		FUN.ele_fun_ds_cpf,
		FUN.ele_fun_fl_sexo,
		FUN.ele_fun_ds_rg,
		CASE 
			WHEN ele_fun_nr_banco NOT IN (0,'') THEN ' Banco: ' + BAN.Banco + ' Ag.: ' + FUN.ele_fun_nr_agencia + CASE ele_fun_fl_poupanca WHEN 0 THEN ' Conta Corrente: ' ELSE ' Conta Poupança: ' END + FUN.ele_fun_nr_conta
			ELSE ''
		END AS Banco
	FROM         
		tb_ele_funcionario FUN INNER JOIN
		tb_ele_func_dados FDA ON FUN.ele_fun_cd_funcionario = FDA.ele_dad_cd_funcionario
		LEFT JOIN Cadastro_Banco BAN on FUN.ele_fun_nr_banco = BAN.CodBanco
	WHERE     
		FDA.ele_dad_ds_eleicao = @Pds_eleicao
		AND FDA.ele_dad_fl_aprovado = 1
		AND NOT FDA.ele_dad_nr_urna IN (0)
		AND FDA.ele_dad_nr_urna = @Pds_urna
	ORDER BY 
		FDA.ele_dad_nr_urna, 
		FUN.ele_fun_nm_funcionario
ELSE
	SELECT     
		FUN.ele_fun_cd_funcionario,
		FUN.ele_fun_nm_funcionario, 
		FUN.ele_fun_ds_endereco + ', ' + FUN.ele_fun_ds_numero AS endereco, 
		FUN.ele_fun_ds_complemento, 
		FUN.ele_fun_ds_bairro,
		FUN.ele_fun_ds_cidade,
		FUN.ele_fun_ds_uf,
		FUN.ele_fun_ds_cep,

		'(' + FUN.ele_fun_nr_ddd_fone_residencial + ')' + FUN.ele_fun_nr_fone_residencial AS ele_fun_nr_fone_residencial,
		'(' + FUN.ele_fun_nr_ddd_celular + ')' + FUN.ele_fun_nr_celular AS ele_fun_nr_celular,

		CASE FDA.ele_dad_ds_cargo
			WHEN 0 THEN 'Presidente'
			WHEN 1 THEN 'Mesário'
			ELSE 'Suplente'
		END AS ele_dad_ds_cargo,

		CASE FDA.ele_dad_fl_carro
			WHEN 0 THEN 'Carro'
			WHEN 1 THEN 'Moto'
			ELSE 'Não Possui'
		END AS ele_dad_fl_carro,
		FUN.ele_fun_ds_cpf,
		FUN.ele_fun_fl_sexo,
		FUN.ele_fun_ds_rg,
		CASE 
			WHEN ele_fun_nr_banco NOT IN (0,'') THEN ' Banco: ' + BAN.Banco + ' Ag.: ' + FUN.ele_fun_nr_agencia + CASE ele_fun_fl_poupanca WHEN 0 THEN ' Conta Corrente: ' ELSE ' Conta Poupança: ' END + FUN.ele_fun_nr_conta
			ELSE ''
		END AS Banco
	FROM         
		tb_ele_funcionario FUN INNER JOIN
		tb_ele_func_dados FDA ON FUN.ele_fun_cd_funcionario = FDA.ele_dad_cd_funcionario
		LEFT JOIN Cadastro_Banco BAN on FUN.ele_fun_nr_banco = BAN.CodBanco
	WHERE     
		FDA.ele_dad_ds_eleicao = @Pds_eleicao
		AND FDA.ele_dad_fl_aprovado = 1
		AND NOT FDA.ele_dad_nr_urna IN (0)
	ORDER BY 
		FDA.ele_dad_nr_urna, 
		FUN.ele_fun_nm_funcionario
go

