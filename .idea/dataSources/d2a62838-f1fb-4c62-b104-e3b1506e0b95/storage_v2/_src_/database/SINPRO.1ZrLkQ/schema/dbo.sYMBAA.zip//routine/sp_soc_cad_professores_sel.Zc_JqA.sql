

/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_sel
Descriçao:	Seleciona Cadastro do Professor
Entrada:	@pNvc_professor  -> Codigo ou CPF do Professor
		@pTin_tipo -> 0 = Codigo ou 1 = CPF
Saída:		
Data da Criaçao: 11/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_sel
(
@pNvc_professor		NVARCHAR(14),
@pTin_tipo			Tinyint
)
AS

IF @pTin_tipo = 0
	SELECT 
		Codigo_Professor, 
		Nome, 
		Sexo, 

		RTRIM(CASE CONVERT(CHAR(10),Data_Aniversario,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),Data_Aniversario,103)
		END)  AS Data_Aniversario, 

		CPF, 
		RG,

		RTRIM(CASE CONVERT(CHAR(10),Data_Modificacao,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),Data_Modificacao,103)
		END) AS Data_Modificacao, 
 
		CEP, 
		Caixa_Postal, 
		Endereco, 
		Numero, 
		Complemento, 
		Bairro, 
		Cidade, 
		Estado, 
		DDD_Telefone_Residencial, 
		Telefone_Residencial_Ramal, 
		Telefone_Residencial, 
		DDD_Telefone_Comercial,
		Telefone_Comercial, 
		Telefone_Comercial_Ramal, 
		DDD_Telefone_Celular, 
		Telefone_Celular, 
	
		LEFT(CASE   WHEN ISNULL(pro_ema_ds_email1,'') <> '' THEN ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END 
		         + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END,
		         LEN(CASE   WHEN  ISNULL(pro_ema_ds_email1,'') <> '' THEN  ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END) -1) AS Email,

		RTRIM(CASE CONVERT(CHAR(10),Data_Situacao,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),Data_Situacao,103)
		END) AS Data_Situacao, 

		Situacao, 
		CASE Situacao WHEN '1' THEN 'ATIVO' WHEN '2' THEN 'APOSENTADO REMIDO' WHEN '3' THEN 'FALECIDO' WHEN '4' THEN 'CANCELADO' WHEN '5' THEN 'LIC. C/ REMUNERAÇÃO' WHEN '6' THEN 'DESVINCULADO' WHEN '7' THEN 'NÃO SINDICALIZADO' WHEN '8' THEN 'APOSENTADO CANCELADO' WHEN '9' THEN 'LIC. S/ REMUNERAÇÃO' WHEN '10' THEN 'APOS. ESPECIAL' WHEN '11' THEN 'APOS. DESVINCULADO' WHEN '12' THEN 'APOS. ATIVO' WHEN '13' THEN 'LIC. SAÚDE' END DESC_SITUACAO, 
		Recuperado, 

		RTRIM(CASE CONVERT(CHAR(10),Data_Carteirinha,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),Data_Carteirinha,103)
		END) AS Data_Carteirinha, 

		RTRIM(CASE CONVERT(CHAR(10),Data_Inicio,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),Data_Inicio,103)
		END) AS Data_Inicio,

		Sindicalizado, 
		Materia, 
		Avulsas, 
		Pre, 
		[1_4Serie], 
		[5_8Serie], 
		Ens_Medio, 
		Ens_Superior, 
		Tecnico, 
		Curso_Livre, 
		Supletivo,
		Correspondencia,
		NewsLetter, 
		Observacao,
		Senha,
		Agenda,
	Estado_Civil,
	PIS, 
	CTPS, 
	CTPS_Serie, 
	Nome_Mae,
	Orgao_Expedidor,
	Cidade_Nasc,
	UF_Nasc,
	Naturalidade,
	
	RTRIM(CASE CONVERT(CHAR(10),Data_Expedicao,103)
		WHEN '01/01/1900' THEN ''
		ELSE	CONVERT(CHAR(10),Data_Expedicao,103)
	END) AS Data_Expedicao, 

	Nome_Pai,

	Votou,
	Rec_Agenda,
	Passar_Urna,
	Urna,

	Banco,
	Agencia,
	Conta,
	Poupanca,
	Conjunta,
	Obs_Eleicao


	FROM Cadastro_Professores  LEFT JOIN tb_professor_email ON Codigo_Professor  = pro_ema_cd_professor 
	WHERE Codigo_Professor = @pNvc_professor
	ORDER BY Codigo_Professor

ELSE
	SELECT 
		Codigo_Professor, 
		Nome, 
		Sexo, 

		RTRIM(CASE CONVERT(CHAR(10),Data_Aniversario,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),Data_Aniversario,103)
		END)  AS Data_Aniversario, 

		CPF, 
		RG,

		RTRIM(CASE CONVERT(CHAR(10),Data_Modificacao,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),Data_Modificacao,103)
		END) AS Data_Modificacao, 
 
		CEP, 
		Caixa_Postal, 
		Endereco, 
		Numero, 
		Complemento, 
		Bairro, 
		Cidade, 
		Estado, 
		DDD_Telefone_Residencial, 
		Telefone_Residencial_Ramal, 
		Telefone_Residencial, 
		DDD_Telefone_Comercial,
		Telefone_Comercial, 
		Telefone_Comercial_Ramal, 
		DDD_Telefone_Celular, 
		Telefone_Celular, 
		
		LEFT(CASE   WHEN ISNULL(pro_ema_ds_email1,'') <> '' THEN ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END 
		         + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END,
		         LEN(CASE   WHEN  ISNULL(pro_ema_ds_email1,'') <> '' THEN  ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END) -1) AS Email, 

		RTRIM(CASE CONVERT(CHAR(10),Data_Situacao,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),Data_Situacao,103)
		END) AS Data_Situacao, 

		Situacao, 
		CASE Situacao WHEN '1' THEN 'ATIVO' WHEN '2' THEN 'APOSENTADO REMIDO' WHEN '3' THEN 'FALECIDO' WHEN '4' THEN 'CANCELADO' WHEN '5' THEN 'LIC. C/ REMUNERAÇÃO' WHEN '6' THEN 'DESVINCULADO' WHEN '7' THEN 'NÃO SINDICALIZADO' WHEN '8' THEN 'APOSENTADO CANCELADO' WHEN '9' THEN 'LIC. S/ REMUNERAÇÃO' WHEN '10' THEN 'APOS. ESPECIAL' WHEN '11' THEN 'APOS. DESVINCULADO' WHEN '12' THEN 'APOS. ATIVO' WHEN '13' THEN 'LIC. SAÚDE' END DESC_SITUACAO, 
		Recuperado, 

		RTRIM(CASE CONVERT(CHAR(10),Data_Carteirinha,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),Data_Carteirinha,103)
		END) AS Data_Carteirinha, 

		RTRIM(CASE CONVERT(CHAR(10),Data_Inicio,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),Data_Inicio,103)
		END) AS Data_Inicio,

		Sindicalizado, 
		Materia, 
		Avulsas, 
		Pre, 
		[1_4Serie], 
		[5_8Serie], 
		Ens_Medio, 
		Ens_Superior, 
		Tecnico, 
		Curso_Livre, 
		Supletivo,
		Correspondencia,
		NewsLetter, 
		Observacao,
		Senha,
		Agenda,
	Estado_Civil,
	PIS, 
	CTPS, 
	CTPS_Serie, 
	Nome_Mae,
	Orgao_Expedidor,
	Cidade_Nasc,
	UF_Nasc,
	
	RTRIM(CASE CONVERT(CHAR(10),Data_Expedicao,103)
		WHEN '01/01/1900' THEN ''
		ELSE	CONVERT(CHAR(10),Data_Expedicao,103)
	END) AS Data_Expedicao, 

	Nome_Pai,

	Votou,
	Rec_Agenda,
	Passar_Urna,
	Urna,
	Obs_Eleicao

	FROM Cadastro_Professores  LEFT JOIN tb_professor_email ON Codigo_Professor  = pro_ema_cd_professor
	WHERE CPF = @pNvc_professor
	ORDER BY Codigo_Professor
go

