
/*******************************************************************
Objeto criado: 	sp_soc_cad_professores_email_upd
Descriçao:	Inclui e Atualiza o Email  do Professor
Data da Criaçao: 28/05/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_email_upd
(
@Pcd_professor		NVARCHAR(6),
@Pds_email1		NVARCHAR(60) = '',
@Pds_email2		NVARCHAR(60) = '',
@Pds_email3		NVARCHAR(60) = ''
    
)
AS

DELETE 
	FROM tb_professor_email
	WHERE pro_ema_cd_professor = @Pcd_professor

IF @Pds_email1 <> '' OR @Pds_email2 <> '' OR @Pds_email3 <> ''

	INSERT INTO tb_professor_email (
		pro_ema_cd_professor,
		pro_ema_ds_email1,
		pro_ema_ds_email2,
		pro_ema_ds_email3)
	VALUES (
		@Pcd_professor,
		@Pds_email1,
		@Pds_email2,
		@Pds_email3)
go

