
/*******************************************************************
Objeto criado: 	 sp_juridico_processo_agendameto_del
Descriçao:	Apaga os Agendamentos do Processo
Data da Criaçao: 26/07/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_agendamento_del
(
@Pcd_agendamento	INT
)

AS

DELETE 
FROM
	tb_jur_processo_agendamento 
WHERE
	jur_pca_cd_agendamento = @Pcd_agendamento
go

