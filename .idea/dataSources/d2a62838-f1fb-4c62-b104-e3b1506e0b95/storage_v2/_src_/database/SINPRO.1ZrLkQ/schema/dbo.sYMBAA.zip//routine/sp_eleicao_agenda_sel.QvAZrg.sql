/*******************************************************************
Objeto criado: 	 sp_eleicao_agenda_sel
Descriçao:	Seleciona Dados para Distribuição de Agendas
Data da Criaçao: 03/07/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_agenda_sel
(
@Pds_eleicao		CHAR(4),
--@Pdt_eleicao		DATETIME,
@Pds_urna		INT

)
AS

-- Pesquisar Funcionários que acompanharam a Urna
SELECT     
	fun.ele_fun_nm_funcionario,
	fun.ele_fun_ds_cpf,
	CASE fda.ele_dad_ds_cargo
		WHEN 0 THEN 'Mesário'
		WHEN 1 THEN 'Mesário'
		WHEN 2 THEN 'Mesário'
	END AS ds_cargo
FROM         tb_ele_funcionario fun INNER JOIN
                      tb_ele_func_dados fda ON fun.ele_fun_cd_funcionario = fda.ele_dad_cd_funcionario
WHERE fda.ele_dad_ds_eleicao = @Pds_eleicao
	AND fda.ele_dad_nr_urna = @Pds_urna
	AND fda.ele_dad_fl_aprovado = 1
ORDER BY fun.ele_fun_nm_funcionario


-- Contar o Número de eleitores da Urna
SELECT 
	COUNT(DISTINCT PGE.CPF) AS Votos
	FROM Cadastro_Escolas CE INNER JOIN 
		Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
		Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
	WHERE  CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
		AND CP.Situacao IN (1,5,2,10,12,13)
		AND PGE.CGC_Escola <> '00.000.000/0000-00'
	 	AND ((CE.Categoria IN (1,6) AND CE.Situacao IN (0,1) ) OR Categoria = 11)
		AND CE.Urna = @Pds_urna
	GROUP BY CE.Urna
	HAVING COUNT(PGE.CPF) >= 1


-- Selecionar os dados das agendas que foram enviadas com a Urna
SELECT 
	ele_eag_cd_agenda,
	ele_eag_nr_entregue,
	ele_eag_nr_valido,
	ele_eag_nr_separado,
	ele_eag_nr_devolvida,
	CONVERT(CHAR(8),ele_eag_dt_hora,108) AS ele_eag_dt_hora,
	CONVERT(CHAR(10),ele_eag_dt_eleicao,103) AS ele_eag_dt_eleicao
	FROM tb_ele_agenda
	WHERE
		ele_eag_ds_eleicao = @Pds_eleicao
		AND ele_eag_ds_urna	= @Pds_urna
	ORDER BY ele_eag_cd_agenda ASC
go

