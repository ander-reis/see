
/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_sel
Descriçao:	Seleciona Audiencias do Dia
Data da Criaçao: 08/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_sel
(
@Pdt_audiencia		DATETIME
)

AS
SELECT    
	AUD.jur_aud_cd_audiencia,
	AUD.jur_aud_nr_pasta,
	PRC.jur_prc_nr_processo,
	CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia,108) AS Horario,
	CASE AUD.jur_aud_fl_retorno
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS Retorno, 
	CAU.jur_cau_ds_audiencia Audiencia,
	ADV.jur_adv_nm_advogado + SPACE(100) + ' -- ' + ADV.jur_adv_nr_oab AS Advogado,
	FIP.jur_fip_cd_professor,
	CP.Nome, 
	CE.Nome_Fantasia,
	CVA.jur_cva_ds_vara,
	AUD.jur_aud_nm_cadastrado,
	CONVERT(CHAR(10),AUD.jur_aud_dt_cadastrado,103) + ' ' + CONVERT(CHAR(10),AUD.jur_aud_dt_cadastrado,108) AS dt_cadastrado, 
	'(' + CP.DDD_Telefone_Residencial + ') ' + CP.Telefone_Residencial AS Residencial, 
	'(' + CP.DDD_Telefone_Comercial + ') ' + CP.Telefone_Comercial AS Comercial, 
	'(' + CP.DDD_Telefone_Celular + ') ' + CP.Telefone_Celular AS Celular,
	AUD.jur_aud_fl_situacao,
	AUD.jur_aud_cd_advogado,
	AUD.jur_aud_fl_audiencia,
	
	CASE AUD.jur_aud_fl_realizada
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END jur_aud_fl_realizada,
	AUD.jur_aud_fl_bloquear,
	CE.fl_judicial,
	CP.Situacao,
	FIC.jur_fic_fl_processo,
	PRC.jur_prc_fl_greve,
	AUD.jur_aud_nr_mesa
FROM
	tb_jur_processo AS PRC INNER JOIN
	tb_jur_cadastro_vara AS CVA ON PRC.jur_prc_cd_vara = CVA.jur_cva_cd_vara INNER JOIN
	tb_jur_ficha_consulta AS FIC  ON PRC.jur_prc_nr_pasta = FIC.jur_fic_nr_pasta INNER JOIN
	tb_jur_ficha_professor AS FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
	Cadastro_Professores CP ON FIP.jur_fip_cd_professor  = CP.Codigo_Professor INNER JOIN
	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
	tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta INNER JOIN
	tb_jur_cadastro_advogado ADV ON AUD.jur_aud_cd_advogado = ADV.jur_adv_cd_advogado INNER JOIN
	tb_jur_cadastro_audiencia CAU ON AUD.jur_aud_fl_audiencia = CAU.jur_cau_fl_audiencia
	WHERE     
		CONVERT(CHAR(8),AUD.jur_aud_dt_audiencia,112) = CONVERT(CHAR(8),@Pdt_audiencia,112)
		
AND FIC.jur_fic_fl_processo = 0

UNION

SELECT 
	AUD.jur_aud_cd_audiencia,
	AUD.jur_aud_nr_pasta,
	PRC.jur_prc_nr_processo,
	CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia,108) AS Horario,
	CASE AUD.jur_aud_fl_retorno
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS Retorno, 
	CAU.jur_cau_ds_audiencia Audiencia,
	ADV.jur_adv_nm_advogado + SPACE(100) + ' -- ' + ADV.jur_adv_nr_oab AS Advogado,
	FIP.jur_fip_cd_professor,
	CP.Nome, 
	CE.Nome_Fantasia,
	CVA.jur_cva_ds_vara,
	AUD.jur_aud_nm_cadastrado,
	CONVERT(CHAR(10),AUD.jur_aud_dt_cadastrado,103) + ' ' + CONVERT(CHAR(10),AUD.jur_aud_dt_cadastrado,108) AS dt_cadastrado, 
	'(' + CP.DDD_Telefone_Residencial + ') ' + CP.Telefone_Residencial AS Residencial, 
	'(' + CP.DDD_Telefone_Comercial + ') ' + CP.Telefone_Comercial AS Comercial, 
	'(' + CP.DDD_Telefone_Celular + ') ' + CP.Telefone_Celular AS Celular,
	AUD.jur_aud_fl_situacao,
	AUD.jur_aud_cd_advogado,
	AUD.jur_aud_fl_audiencia,
	
	CASE AUD.jur_aud_fl_realizada
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END jur_aud_fl_realizada,
	AUD.jur_aud_fl_bloquear,
	CE.fl_judicial,
	CP.Situacao,
	FIC.jur_fic_fl_processo,
	PRC.jur_prc_fl_greve,
	AUD.jur_aud_nr_mesa
FROM
	tb_jur_processo AS PRC INNER JOIN
	tb_jur_cadastro_vara AS CVA ON PRC.jur_prc_cd_vara = CVA.jur_cva_cd_vara INNER JOIN
	tb_jur_ficha_consulta AS FIC  ON PRC.jur_prc_nr_pasta = FIC.jur_fic_nr_pasta INNER JOIN
	tb_jur_ficha_professor AS FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
	Cadastro_Professores CP ON FIP.jur_fip_cd_professor  = CP.Codigo_Professor INNER JOIN
	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
	tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta INNER JOIN
	tb_jur_cadastro_advogado ADV ON AUD.jur_aud_cd_advogado = ADV.jur_adv_cd_advogado INNER JOIN
	tb_jur_cadastro_audiencia CAU ON AUD.jur_aud_fl_audiencia = CAU.jur_cau_fl_audiencia
	WHERE     
		CONVERT(CHAR(8),AUD.jur_aud_dt_audiencia,112) = CONVERT(CHAR(8),@Pdt_audiencia,112)
		AND FIC.jur_fic_fl_processo = 1
		AND FIP.jur_fip_cd_professor = '00000'

--ORDER BY 
--	CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia,108),	
--	CVA.jur_cva_ds_vara, FIP.jur_fip_cd_professor

UNION

SELECT  TOP 1 
	AUD.jur_aud_cd_audiencia,
	AUD.jur_aud_nr_pasta,
	PRC.jur_prc_nr_processo,
	CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia,108) AS Horario,
	CASE AUD.jur_aud_fl_retorno
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS Retorno, 
	CAU.jur_cau_ds_audiencia Audiencia,
	ADV.jur_adv_nm_advogado + SPACE(100) + ' -- ' + ADV.jur_adv_nr_oab AS Advogado,
	FIP.jur_fip_cd_professor,
	CP.Nome, 
	CE.Nome_Fantasia,
	CVA.jur_cva_ds_vara,
	AUD.jur_aud_nm_cadastrado,
	CONVERT(CHAR(10),AUD.jur_aud_dt_cadastrado,103) + ' ' + CONVERT(CHAR(10),AUD.jur_aud_dt_cadastrado,108) AS dt_cadastrado, 
	'(' + CP.DDD_Telefone_Residencial + ') ' + CP.Telefone_Residencial AS Residencial, 
	'(' + CP.DDD_Telefone_Comercial + ') ' + CP.Telefone_Comercial AS Comercial, 
	'(' + CP.DDD_Telefone_Celular + ') ' + CP.Telefone_Celular AS Celular,
	AUD.jur_aud_fl_situacao,
	AUD.jur_aud_cd_advogado,
	AUD.jur_aud_fl_audiencia,
	
	CASE AUD.jur_aud_fl_realizada
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END jur_aud_fl_realizada,
	AUD.jur_aud_fl_bloquear,
	CE.fl_judicial,
	CP.Situacao,
	FIC.jur_fic_fl_processo,
	PRC.jur_prc_fl_greve,
	AUD.jur_aud_nr_mesa
FROM
	tb_jur_processo AS PRC INNER JOIN
	tb_jur_cadastro_vara AS CVA ON PRC.jur_prc_cd_vara = CVA.jur_cva_cd_vara INNER JOIN
	tb_jur_ficha_consulta AS FIC  ON PRC.jur_prc_nr_pasta = FIC.jur_fic_nr_pasta INNER JOIN
	tb_jur_ficha_professor AS FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
	Cadastro_Professores CP ON FIP.jur_fip_cd_professor  = CP.Codigo_Professor INNER JOIN
	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
	tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta INNER JOIN
	tb_jur_cadastro_advogado ADV ON AUD.jur_aud_cd_advogado = ADV.jur_adv_cd_advogado INNER JOIN
	tb_jur_cadastro_audiencia CAU ON AUD.jur_aud_fl_audiencia = CAU.jur_cau_fl_audiencia
	WHERE     
		CONVERT(CHAR(8),AUD.jur_aud_dt_audiencia,112) = CONVERT(CHAR(8),@Pdt_audiencia,112)
		AND FIC.jur_fic_fl_processo = 2
		AND FIP.jur_fip_fl_plurima = 1
ORDER BY 
	CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia,108),	
	CVA.jur_cva_ds_vara, FIP.jur_fip_cd_professor
go

