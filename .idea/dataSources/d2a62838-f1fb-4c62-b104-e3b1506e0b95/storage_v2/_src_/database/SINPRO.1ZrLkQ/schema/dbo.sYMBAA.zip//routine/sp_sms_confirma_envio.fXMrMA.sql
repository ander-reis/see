/*******************************************************************
Objeto criado: 	sp_sms_confirma_envio
Descriçao:	Procedure responsável apagar os emails
		que tiveram o boletim enviado
Entrada:	
Saída:		
Data da Criaçao: 24/03/2005
Autor:		Ronaldo Araujo (SinproSP)
*******************************************************************/

CREATE PROCEDURE sp_sms_confirma_envio (
@Pcd_matricula		AS VARCHAR(5),
@Pnm_professor	AS VARCHAR(150),
@Pnr_celular		AS VARCHAR(50),
@Pds_mensagem	AS VARCHAR(400),
@Pds_origem		AS VARCHAR(100)
)
AS
BEGIN

	INSERT INTO tb_professor_sms
		(cd_matricula, nm_professor, nr_celular, ds_mensagem, ds_origem) 
	VALUES (
		@Pcd_matricula,
		@Pnm_professor,
		@Pnr_celular,
		@Pds_mensagem,
		@Pds_origem
	)
END
go

