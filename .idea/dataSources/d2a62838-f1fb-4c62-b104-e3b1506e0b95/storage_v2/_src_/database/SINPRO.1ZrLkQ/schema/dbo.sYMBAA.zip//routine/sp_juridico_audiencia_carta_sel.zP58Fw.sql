
/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_carta_sel
Descriçao:	Seleciona Audiencias à Serem Impressas
Data da Criaçao: 22/11/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_carta_sel

AS
/*CASE AUD.jur_aud_fl_audiencia 
		WHEN 143 THEN 'AV. MARQUES DE SAO VICENTE, 235 - 02 ANDAR – BL. B'
		WHEN 144 THEN 'AV. MARQUES DE SAO VICENTE, 235 - TÉRREO - MESA ' + CONVERT(NVARCHAR(3),AUD.jur_aud_nr_mesa)
		ELSE CVA.jur_cva_ds_endereco + ', ' + CVA.jur_cva_ds_numero + ' - ' + CVA.jur_cva_ds_complemento
	END AS End_Vara,
*/

SELECT    
	AUD.jur_aud_cd_audiencia,
	AUD.jur_aud_nr_pasta,
	PRC.jur_prc_nr_processo AS Numero_Processo,
	AUD.jur_aud_fl_audiencia,
	CONVERT(CHAR(10),AUD.jur_aud_dt_audiencia,103) AS Data,
	CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia,108) AS Horario,
	CASE AUD.jur_aud_fl_situacao
		WHEN 0 THEN 'DESIGNADA'
		WHEN 1 THEN 'REDESIGNADA'
		ELSE 'CANCELADA'
	END AS Tipo, 

	CASE FIC.jur_fic_fl_testemunha
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS Testemunha,

	CP.Nome, 
	CE.Razao_Social,
	CVA.jur_cva_ds_vara AS Vara,
	CASE CP.Sexo
		WHEN 0 THEN 'Professor'
		ELSE 'Professora'
	END AS Tratamento,
	CP.Endereco + ', ' + CP.Numero + ' - ' + CP.Complemento AS Endereco,
	CP.Bairro + ', ' + CP.Cidade + ', ' + CP.Estado AS Bairro,
	CP.CEP,
	CVA.jur_cva_ds_endereco + ', ' + CVA.jur_cva_ds_numero + ' - ' + CVA.jur_cva_ds_complemento AS End_Vara,
	FIC.jur_fic_ds_testemunha,
	AUD.jur_aud_nr_mesa
FROM
	tb_jur_processo PRC INNER JOIN
	tb_jur_cadastro_vara CVA ON PRC.jur_prc_cd_vara = CVA.jur_cva_cd_vara INNER JOIN
	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor INNER JOIN
	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
	tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta LEFT JOIN 
	( SELECT DISTINCT jur_fic_nr_pasta FROM tb_jur_ficha_causa FCA INNER JOIN
              tb_jur_ficha_consulta FIC ON FCA.jur_fca_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
              tb_jur_cadastro_causa  CAU ON FCA.jur_fca_cd_causa = CAU.jur_cau_cd_causa
	WHERE     CAU.jur_cau_fl_testemunha = 1) AS JPC ON AUD.jur_aud_nr_pasta = JPC.jur_fic_nr_pasta
	
	WHERE     
		AUD.jur_aud_fl_carta = 0 AND FIC.jur_fic_fl_processo = 0

UNION
SELECT    
	AUD.jur_aud_cd_audiencia,
	AUD.jur_aud_nr_pasta,
	PRC.jur_prc_nr_processo AS Numero_Processo,
	AUD.jur_aud_fl_audiencia,
	CONVERT(CHAR(10),AUD.jur_aud_dt_audiencia,103) AS Data,
	CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia,108) AS Horario,
	CASE AUD.jur_aud_fl_situacao
		WHEN 0 THEN 'DESIGNADA'
		WHEN 1 THEN 'REDESIGNADA'
		ELSE 'CANCELADA'
	END AS Tipo, 

	CASE FIC.jur_fic_fl_testemunha
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS Testemunha,

	CP.Nome, 
	CE.Razao_Social,
	CVA.jur_cva_ds_vara AS Vara,
	CASE CP.Sexo
		WHEN 0 THEN 'Professor'
		ELSE 'Professora'
	END AS Tratamento,
	CP.Endereco + ', ' + CP.Numero + ' - ' + CP.Complemento AS Endereco,
	CP.Bairro + ', ' + CP.Cidade + ', ' + CP.Estado AS Bairro,
	CP.CEP,
	CVA.jur_cva_ds_endereco + ', ' + CVA.jur_cva_ds_numero + ' - ' + CVA.jur_cva_ds_complemento AS End_Vara,
	FIC.jur_fic_ds_testemunha,
	AUD.jur_aud_nr_mesa
FROM
	tb_jur_processo PRC INNER JOIN
	tb_jur_cadastro_vara CVA ON PRC.jur_prc_cd_vara = CVA.jur_cva_cd_vara INNER JOIN
	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor INNER JOIN
	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
	tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta LEFT JOIN 
	( SELECT DISTINCT jur_fic_nr_pasta FROM tb_jur_ficha_causa FCA INNER JOIN
              tb_jur_ficha_consulta FIC ON FCA.jur_fca_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
              tb_jur_cadastro_causa  CAU ON FCA.jur_fca_cd_causa = CAU.jur_cau_cd_causa
	WHERE     CAU.jur_cau_fl_testemunha = 1) AS JPC ON AUD.jur_aud_nr_pasta = JPC.jur_fic_nr_pasta
	
	WHERE     
		AUD.jur_aud_fl_carta = 0 AND FIC.jur_fic_fl_processo = 1 AND FIP.jur_fip_cd_professor = '00000'

ORDER BY 
	Tipo, CP.Nome
go

