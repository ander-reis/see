/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_escola_total_sel
Descriçao:	Conta as Denúncias e os Professores da Escola
Data da Criaçao: 24/07/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_escola_total_sel
(
@Pcd_cnpj	NVARCHAR(18)
)
AS

SELECT
	COUNT(1) AS jur_tot_nr_processo
FROM
	tb_jur_processo PRC
	INNER JOIN tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha
WHERE
	FIC.jur_fic_cd_cnpj = @Pcd_cnpj

SELECT
	COUNT(1) AS jur_tot_nr_denuncia
FROM
	Irr_Dados
WHERE
	CGC_Escola = @Pcd_cnpj
go

