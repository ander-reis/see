
/*******************************************************************
Objeto criado: 	sp_eleicao_cand_obs_ins
Descriçao:	Inclui Observação do Candidato
Saída:		
Data da Criaçao: 09/06/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_cand_obs_ins
(
@Pcd_candidato			CHAR(5),
@Pdt_observacao			DATETIME,
@Pds_observacao			NTEXT,
@Pnm_login				NVARCHAR(30),
@Pdt_hora				DATETIME
)
AS

INSERT INTO tb_ele_cand_observacao (
	ele_cob_cd_candidato,
	ele_cob_dt_observacao,
	ele_cob_ds_observacao,
	ele_cob_nm_login,
	ele_cob_dt_hora) 
VALUES (
	@Pcd_candidato,
	@Pdt_observacao,
	@Pds_observacao,
	@Pnm_login,
	@Pdt_hora
	)
go

