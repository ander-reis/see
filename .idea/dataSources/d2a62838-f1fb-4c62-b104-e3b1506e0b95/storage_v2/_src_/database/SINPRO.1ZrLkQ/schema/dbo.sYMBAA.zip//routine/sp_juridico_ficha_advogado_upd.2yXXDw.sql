/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_advogado_upd
Descriçao:	Altera o advogado do Processo com base na Ficha
Data da Criaçao: 06/08/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_advogado_upd
(
@Pnr_pasta		NVARCHAR(8),
@Pcd_advogado	INT,
@Pnm_login		NVARCHAR(30),
@Pnm_advogado_de	NVARCHAR(60),
@Pnm_advogado_pa	NVARCHAR(60)
)
AS

DECLARE @Vdt_cadastro	DATETIME
DECLARE @Vds_observacao	NVARCHAR(120)

SET @Vdt_cadastro = GETDATE()
SET @Vds_observacao = 'ALTERADO O ADVOGADO DE: '  + @Pnm_advogado_de + ' PARA: ' + @Pnm_advogado_pa

UPDATE    tb_jur_processo SET
	jur_prc_cd_advogado	= @Pcd_advogado
WHERE
	jur_prc_nr_pasta		= @Pnr_pasta

EXEC sp_juridico_processo_observacao_ins @Pnr_pasta, @Vdt_cadastro, @Vdt_cadastro, @Pnm_login,  @Vds_observacao
go

