

/*******************************************************************
Objeto criado: 	 sp_eleicao_eleitor_aposentado_sel
Descriçao:	Seleciona Escola
Data da Criaçao: 20/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_eleitor_aposentado_sel
(
@Pnr_urna	INT
)
AS

SELECT     	

	CP.Codigo_Professor, 
	CP.Nome,

	CASE CP.Votou
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS Votou

	FROM Cadastro_Professores CP 
--	RIGHT JOIN Professores_Geral_Escolas PGE ON CP.Codigo_Professor = PGE.Codigo_Professor
WHERE --CP.Situacao IN (2,10 )
	CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
--	AND (PGE.CGC_Escola = '00.000.000/0000-00' OR PGE.CGC_Escola IS NULL)
	AND CP.Urna = @Pnr_urna
ORDER BY CP.CEP, CP.Nome
go

