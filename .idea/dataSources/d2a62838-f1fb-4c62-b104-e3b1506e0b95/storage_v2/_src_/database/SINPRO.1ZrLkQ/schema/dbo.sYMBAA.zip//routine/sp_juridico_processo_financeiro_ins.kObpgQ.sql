
/*******************************************************************
Objeto criado: 	 sp_juridico_processo_financeiro_ins
Descriçao:	Insere as Parcelas do Processo
Data da Criaçao: 02/07/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_financeiro_ins
(
@Pnr_pasta		NVARCHAR(8),
@Pcd_fic_pro		INT,	
@Pnr_parcelas		NVARCHAR(5),
@Pdt_vencimento	DATETIME,
@Pvl_parcelas		NUMERIC(10,2),
@Pnr_taxa		NVARCHAR(4),
@Pvl_taxa		NUMERIC(10,2),
@Pvl_honorario		NUMERIC(10,2),
@Pds_observacao	NVARCHAR(100),
@Pfl_destino		TINYINT,
@Pds_titutlo		NVARCHAR(10),
@Pfl_situacao		TINYINT,
@Pdt_pagamento	DATETIME,
@Pds_forma		NVARCHAR(3),
@Pcd_banco		NVARCHAR(3),
@Pnr_agencia		NVARCHAR(8),
@Pnr_conta		NVARCHAR(18),
@Pfl_poupanca		TINYINT,
@Pfl_conjunta		TINYINT,
@Pnm_login		NVARCHAR(30),
@Pfl_siga		NVARCHAR(1),
@Pnr_pagamento	INT OUTPUT
)
AS

INSERT INTO tb_jur_processo_financeiro (
	jur_pcf_nr_pasta,
	jur_pcf_cd_fic_pro,
	jur_pcf_nr_parcela,
	jur_pcf_dt_vencimento,
	jur_pcf_vl_parcela,
	jur_pcf_nr_taxa,
	jur_pcf_vl_taxa,
	jur_pcf_vl_honorario,
	jur_pcf_ds_observacao,
	jur_pcf_fl_destino,
	jur_pcf_ds_titulo,
	jur_pcf_fl_situacao,
	jur_pcf_dt_pagamento,
	jur_pcf_ds_forma,
	jur_pcf_cd_banco,
	jur_pcf_nr_agencia,
	jur_pcf_nr_conta,
	jur_pcf_fl_poupanca,
	jur_pcf_fl_conjunta,
	jur_pcf_nm_login,
	jur_pcf_dt_geracao,
	jur_pcf_fl_siga)
VALUES     (
	@Pnr_pasta,
	@Pcd_fic_pro,
	@Pnr_parcelas,
	@Pdt_vencimento,
	@Pvl_parcelas,
	@Pnr_taxa,
	@Pvl_taxa,
	@Pvl_honorario,
	@Pds_observacao,
	@Pfl_destino,
	@Pds_titutlo,
	@Pfl_situacao,
	@Pdt_pagamento,
	@Pds_forma,
	@Pcd_banco,
	@Pnr_agencia,
	@Pnr_conta,
	@Pfl_poupanca,
	@Pfl_conjunta,
	@Pnm_login,
	GETDATE(),
	@Pfl_siga
	)

SELECT
	@Pnr_pagamento = jur_pcf_nr_pagamento
FROM 
	tb_jur_processo_financeiro
WHERE
	jur_pcf_nr_pasta 	= @Pnr_pasta
	AND jur_pcf_cd_fic_pro 	= @Pcd_fic_pro
	AND @Pnr_parcelas	= jur_pcf_nr_parcela
go

