/*******************************************************************
Objeto criado: 	 sp_eleicao_func_recibo_sel
Descriçao:	Seleciona Funcionários para Impressão de Recibo
Data da Criaçao: 29/09/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_func_recibo_sel
(
@Pds_eleicao	CHAR(4),
@Pnr_urna	INT,
@Pfl_tipo	TINYINT
)
AS

IF @Pfl_tipo = 0
BEGIN
	IF @Pnr_urna <> 0
		SELECT
			FUN.ele_fun_nm_funcionario, FUN.ele_fun_ds_cpf, FUN.ele_fun_ds_rg, DAD.ele_dad_ds_eleicao, DAD.ele_dad_ds_cargo, DAD.ele_dad_nr_urna, 
                    		DAD.ele_dad_fl_aprovado, TOT.ele_dad_tot_func
		FROM
			tb_ele_funcionario FUN
			INNER JOIN tb_ele_func_dados DAD ON FUN.ele_fun_cd_funcionario = DAD.ele_dad_cd_funcionario
			INNER JOIN  (SELECT
						ele_dad_ds_eleicao, ele_dad_nr_urna, COUNT(1) AS ele_dad_tot_func
			                        FROM
						tb_ele_func_dados
			                         WHERE
						ele_dad_fl_aprovado = 1
						AND ele_dad_ds_eleicao = @Pds_eleicao
						AND ele_dad_nr_urna = @Pnr_urna
		                                      GROUP BY
						ele_dad_ds_eleicao, ele_dad_nr_urna
				         ) TOT ON DAD.ele_dad_ds_eleicao = TOT.ele_dad_ds_eleicao AND DAD.ele_dad_nr_urna = TOT.ele_dad_nr_urna
		WHERE
			DAD.ele_dad_fl_aprovado = 1
			AND DAD.ele_dad_ds_cargo = 0
			AND DAD.ele_dad_ds_eleicao = @Pds_eleicao
			AND DAD.ele_dad_nr_urna = @Pnr_urna
		ORDER BY
			DAD.ele_dad_nr_urna,
			FUN.ele_fun_nm_funcionario
	ELSE
		SELECT
			FUN.ele_fun_nm_funcionario, FUN.ele_fun_ds_cpf, FUN.ele_fun_ds_rg, DAD.ele_dad_ds_eleicao, DAD.ele_dad_ds_cargo, DAD.ele_dad_nr_urna, 
                    		DAD.ele_dad_fl_aprovado, TOT.ele_dad_tot_func
		FROM
			tb_ele_funcionario FUN
			INNER JOIN tb_ele_func_dados DAD ON FUN.ele_fun_cd_funcionario = DAD.ele_dad_cd_funcionario
			INNER JOIN  (SELECT
						ele_dad_ds_eleicao, ele_dad_nr_urna, COUNT(1) AS ele_dad_tot_func
			                        FROM
						tb_ele_func_dados
			                         WHERE
						ele_dad_fl_aprovado = 1
						AND ele_dad_ds_eleicao = @Pds_eleicao
		                                      GROUP BY
						ele_dad_ds_eleicao, ele_dad_nr_urna
				         ) TOT ON DAD.ele_dad_ds_eleicao = TOT.ele_dad_ds_eleicao AND DAD.ele_dad_nr_urna = TOT.ele_dad_nr_urna
		WHERE
			DAD.ele_dad_fl_aprovado = 1
			AND DAD.ele_dad_ds_cargo = 0
			AND DAD.ele_dad_ds_eleicao = @Pds_eleicao
			AND DAD.ele_dad_nr_urna NOT IN(0,1,10)
		ORDER BY
			DAD.ele_dad_nr_urna,
			FUN.ele_fun_nm_funcionario

END
ELSE
PRINT 1
go

