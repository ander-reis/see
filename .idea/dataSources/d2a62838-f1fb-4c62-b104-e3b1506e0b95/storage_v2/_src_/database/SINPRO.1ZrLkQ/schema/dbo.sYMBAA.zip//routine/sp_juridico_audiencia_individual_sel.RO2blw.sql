

/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_individual_sel
Descriçao:	Seleciona Audiencias do Dia
Data da Criaçao: 08/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_individual_sel
(
@Pcd_audiencia		INT
)
AS

SELECT    
	CONVERT(CHAR(10),AUD.jur_aud_dt_audiencia,103) AS Data,
	CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia,108) AS Horario,
	CAU.jur_cau_ds_audiencia Audiencia,
	ADV.jur_adv_nm_advogado  AS Advogado
FROM
	tb_jur_audiencia AUD  INNER JOIN
	tb_jur_cadastro_advogado ADV ON AUD.jur_aud_cd_advogado = ADV.jur_adv_cd_advogado INNER JOIN
	tb_jur_cadastro_audiencia CAU ON AUD.jur_aud_fl_audiencia = CAU.jur_cau_fl_audiencia
WHERE     
	AUD.jur_aud_cd_audiencia = @Pcd_audiencia
go

