/*******************************************************************
Objeto criado: 	 sp_baixar_boleto
Descriçao:	Pegar quais os boletos estão baixados no Microsiga e que não estão baixados na WebSindical e no SAS
Data da Criaçao: 18/08/2006
Alterado em: 19/08/213 - otimizado a rotina para baixa pendente
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_baixar_boleto
(
@Pnr_retorno		INT	OUTPUT
)
AS

UPDATE DADOSADV.dbo.SE1010 SET E1_MSEXP = '' WHERE  E1_NUMBCO IN
                          (SELECT     BU.cd_boleto
                            FROM          sinprosp.dbo.tb_boletos BU INNER JOIN
                                                   sinprosp.dbo.tb_historico_status HSB ON BU.cd_arrecadacao = HSB.cd_arrecadacao AND BU.cd_escola = HSB.cd_escola AND 
                                                   BU.nr_via = HSB.nr_via
                            WHERE      HSB.cd_status <> 5 ) AND E1_STATUS = 'B'

SELECT @Pnr_retorno = @@rowcount
go

