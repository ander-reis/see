

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_professor_documento_ins
Descriçao:	 Inserir Causa do Processo na Ficha
Data da Criaçao: 05/03/2007
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_professor_documento_ins
(
@Pcd_fic_pro 		INT,
@Pcd_documento 	INT,
@Pnm_login		NVARCHAR(30),
@Pdt_entrega		DATETIME,
@Pnm_entrega		NVARCHAR(30),
@Pds_complemento	NVARCHAR(300) = '',
@Pcd_doc_pro		INT OUTPUT
)
AS

INSERT INTO tb_jur_ficha_professor_documento
	(jur_fpd_cd_fic_pro,
	jur_fpd_cd_documento,
	jur_fpd_dt_entrega,
	jur_fpd_nm_login,
	jur_fpd_nm_entrega,
	jur_fpd_ds_complemento)
VALUES
	(@Pcd_fic_pro,
	@Pcd_documento,
	@Pdt_entrega,	
	@Pnm_login,
	@Pnm_entrega,
	@Pds_complemento)

SELECT @Pcd_doc_pro = jur_fpd_cd_doc_pro
FROM tb_jur_ficha_professor_documento
WHERE jur_fpd_cd_fic_pro = @Pcd_fic_pro 
	AND jur_fpd_cd_documento = @Pcd_documento
go

