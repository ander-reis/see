
/*******************************************************************
Objeto criado: 	 sp_soc_cad_escola_log
Descriçao:	Seleciona Log's da Escola
Entrada:	@pNvc_CNPJ  -> Codigo da Escola
Saída:		
Data da Criaçao: 25/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_escola_sel_log
(
@pNvc_CNPJ		NVARCHAR(18)
)
AS


SELECT 
	User_Escola,
	CONVERT(CHAR(10),Data_Escola,103)  AS Data_Escola,
	CONVERT(CHAR(8),Data_Escola,108) AS Hora_Escola
FROM Log_Escola
WHERE CNPJ_Escola = @pNvc_CNPJ
ORDER BY CONVERT(DATETIME,Data_Escola,120) DESC


go

