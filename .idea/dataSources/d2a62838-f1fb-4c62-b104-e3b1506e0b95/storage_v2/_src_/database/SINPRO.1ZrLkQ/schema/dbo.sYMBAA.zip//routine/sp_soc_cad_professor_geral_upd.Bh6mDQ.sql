/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_geral_upd
Descriçao:	Atualiza o Soc_Cadastro_Professor_Geral
Data da Criaçao: 13/01/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professor_geral_upd
(
@pTinTipo			TINYINT,
@pRea_codprof_geral		REAL,
@pNvc_professor		NVARCHAR(5),
@pNvc_nome			NVARCHAR(100),
@pTin_caixa_postal		TINYINT		= 0,
@pNvc_endereco		NVARCHAR(63)		= '',
@pNvc_numero			NVARCHAR(6)		= '',
@pNvc_complemento		NVARCHAR(50)		= '',
@pNvc_bairro			NVARCHAR(59)		= '',
@pNvc_cidade			NVARCHAR(21)		= '',
@pNvc_uf			NVARCHAR(2)		= 'SP',
@pNvc_cep			NVARCHAR(9)		= '',
@pNvc_ddd_residencial		NVARCHAR(2)		= '11',
@pNvc_fone_residencial	NVARCHAR(9)		= '',
@pNvc_ramal_residencial	NVARCHAR(5)		= '',
@pNvc_ddd_comercial		NVARCHAR(2)		= '11',
@pNvc_fone_comercial		NVARCHAR(9)		= '',	
@pNvc_ramal_comercial		NVARCHAR(5)		= '',
@pNvc_ddd_celular		NVARCHAR(2)		= '11',
@pNvc_celular			NVARCHAR(10)		= '',
@pNvc_CPF			NVARCHAR(14),
@pNvc_RG			NVARCHAR(12)		='',
@pNvc_naturalidade		NVARCHAR(40)		='BRASILEIRO',
@pDt_aniversario		DATETIME		= '01/01/1900',
@pDt_modificacao		DATETIME		= GETDATE,
@pTin_sexo			TINYINT		= 1,
@pNvc_email			NVARCHAR(120),
@pTin_estado_civil		TINYINT		= 5,
@Pds_Banco			NVARCHAR(3) = '000',
@Pds_Agencia			NVARCHAR(8) = '',
@Pds_Conta			NVARCHAR(18) = '',
@Pfl_Poupanca			TINYINT = 0,
@Pfl_Conjunta			TINYINT = 0
)
AS


IF @pTinTipo = 0   --  Atualização Completa no SOC
BEGIN
	UPDATE Soc_Cadastro_Professor_Geral SET
		Codigo_Professor		= @pNvc_professor,
		Nome  				= @pNvc_nome,	
		Caixa_Postal			= @pTin_caixa_postal,
		Endereco			= @pNvc_endereco,	
	             Numero				= @pNvc_numero,	
		Complemento			= @pNvc_complemento,
		Bairro				= @pNvc_bairro,	
		Cidade				= @pNvc_cidade,			
		Estado				= @pNvc_uf,
		CEP				= @pNvc_cep,
		DDD_Telefone_Residencial 	= @pNvc_ddd_residencial,
		Telefone_Residencial		= @pNvc_fone_residencial,
		Telefone_Residencial_Ramal	= @pNvc_ramal_residencial,
      		DDD_Telefone_Comercial	= @pNvc_ddd_comercial,
		Telefone_Comercial		= @pNvc_fone_comercial,
		Telefone_Comercial_Ramal	= @pNvc_ramal_comercial,
		DDD_Telefone_Celular		= @pNvc_ddd_celular,
		Telefone_Celular		= @pNvc_celular,
		CPF				= @pNvc_CPF,	
		RG				= @pNvc_RG,
		Naturalidade			= @pNvc_naturalidade,
		Data_Aniversario		= @pDt_aniversario,
		Data_Modificacao		= GETDATE(),
		Sexo				= @pTin_sexo,
		Email				= @pNvc_email,
		Estado_Civil			= @pTin_estado_civil,
		Ronaldo			= '',
		Banco				= @Pds_Banco,
		Agencia				= @Pds_Agencia,
		Conta				= @Pds_Conta,
		Poupanca			= @Pfl_Poupanca,
		Conjunta			= @Pfl_Conjunta
	WHERE CodProf_Geral = @pRea_codprof_geral
END
ELSE IF @pTinTipo = 1   --  Atualização Parcial no SOC
	UPDATE Soc_Cadastro_Professor_Geral SET
		Codigo_Professor		= @pNvc_professor,
		Nome  				= @pNvc_nome,	
		Endereco			= @pNvc_endereco,	
	             Numero				= @pNvc_numero,	
		Complemento			= @pNvc_complemento,
		Bairro				= @pNvc_bairro,	
		Cidade				= @pNvc_cidade,			
		Estado				= @pNvc_uf,
		CEP				= @pNvc_cep,
		DDD_Telefone_Residencial 	= @pNvc_ddd_residencial,
		Telefone_Residencial		= @pNvc_fone_residencial,
		Telefone_Residencial_Ramal	= @pNvc_ramal_residencial,
		DDD_Telefone_Celular		= @pNvc_ddd_celular,
		Telefone_Celular		= @pNvc_celular,
		CPF				= @pNvc_CPF,	
		Naturalidade			= @pNvc_naturalidade,
		Data_Aniversario		= @pDt_aniversario,
		Data_Modificacao		= GETDATE(),
		Sexo				= @pTin_sexo,
		Email				= @pNvc_email,
		Banco				= @Pds_Banco,
		Agencia				= @Pds_Agencia,
		Conta				= @Pds_Conta,
		Poupanca			= @Pfl_Poupanca,
		Conjunta			= @Pfl_Conjunta
	WHERE CodProf_Geral = @pRea_codprof_geral

ELSE IF @pTinTipo = 2   --  Atualização Parcial no SOC
	UPDATE Soc_Cadastro_Professor_Geral SET
		Codigo_Professor		= @pNvc_professor,

		Nome  				= @pNvc_nome,	
		DDD_Telefone_Residencial 	= @pNvc_ddd_residencial,
		Telefone_Residencial		= @pNvc_fone_residencial,
		Telefone_Residencial_Ramal	= @pNvc_ramal_residencial,
		DDD_Telefone_Celular		= @pNvc_ddd_celular,
		Telefone_Celular		= @pNvc_celular,
		CPF				= @pNvc_CPF,	
		Data_Modificacao		= GETDATE(),
		Email				= @pNvc_email
	WHERE CodProf_Geral = @pRea_codprof_geral
go

