
/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_sel_urna
Descriçao:	Seleciona Professores de Determinada Urna
Data da Criaçao: 20/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_sel_urna
(
@Pnr_urna		INT

)
AS


SELECT 
	CP.Codigo_Professor, 
	CP.Nome, 
	SUBSTRING(CP.CEP,1,5) AS CEP,
	CP.Endereco + ', ' + CP.Numero AS Endereco,
	CP.Bairro + ' - ' + CP.Cidade + ' - ' + CP.CEP AS Complemento,
	CP.Urna,
	CP.Obs_Eleicao
FROM Cadastro_Professores CP 
--	RIGHT JOIN Professores_Geral_Escolas PGE ON CP.Codigo_Professor = PGE.Codigo_Professor
WHERE --CP.Situacao IN (2,10 )
	CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/27/2010'))
--	AND (PGE.CGC_Escola = '00.000.000/0000-00' OR PGE.CGC_Escola IS NULL)
	AND CP.Urna = @Pnr_urna
ORDER BY CP.Nome
go

