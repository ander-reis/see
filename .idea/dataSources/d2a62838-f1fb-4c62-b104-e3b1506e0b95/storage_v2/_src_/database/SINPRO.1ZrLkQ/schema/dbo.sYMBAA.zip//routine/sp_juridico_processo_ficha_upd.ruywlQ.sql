

/*******************************************************************
Objeto criado: 	 sp_juridico_processo_ficha_upd
Descriçao:	 Atualizarr Professor na Ficha de Consulta
Data da Criaçao: 28/02/2007
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_ficha_upd
(
@Pcd_fic_pro		INT,
@Pfl_receber		TINYINT
)
AS	

UPDATE tb_jur_ficha_professor SET 
	jur_fip_fl_receber = @Pfl_receber
WHERE jur_fip_cd_fic_pro =  @Pcd_fic_pro

go

