/*******************************************************************
Objeto criado: 	 sp_juridico_processo_observacao_ins
Descriçao:	Cadastra a observação do Processo
Data da Criaçao: 03/07/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_observacao_ins
(
@Pnr_pasta		NVARCHAR(8),
@Pdt_observacao	DATETIME,
@Phr_observacao	DATETIME,
@Pnm_login		NVARCHAR(30),
@Pds_observacao	NVARCHAR(600)
)

AS

INSERT INTO tb_jur_processo_observacao
	(jur_pco_nr_pasta,
	jur_pco_dt_observacao,
	jur_pco_hr_observacao,
	jur_pco_nm_login,
	jur_pco_ds_observacao)
VALUES
	(@Pnr_pasta,
	@Pdt_observacao,
	@Phr_observacao,
	@Pnm_login,
	@Pds_observacao)
go

