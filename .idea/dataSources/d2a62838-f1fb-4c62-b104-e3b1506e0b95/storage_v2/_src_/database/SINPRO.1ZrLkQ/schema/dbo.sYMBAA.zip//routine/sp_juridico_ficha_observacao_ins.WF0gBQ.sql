

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_observacao_ins
Descriçao:	Cadastra a observação da Ficha de Consulta
Data da Criaçao: 05/03/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_observacao_ins
(
@Pnr_ficha		INT,
@Pdt_observacao	DATETIME,
@Phr_observacao	DATETIME,
@Pnm_login		NVARCHAR(30),
@Pds_observacao	NTEXT


)

AS

INSERT INTO    tb_jur_ficha_observacao
	(jur_fio_nr_ficha,
	jur_fio_dt_observacao,
	jur_fio_hr_observacao,
	jur_fio_nm_login,
	jur_fio_ds_observacao)
VALUES
	(@Pnr_ficha,
	@Pdt_observacao,
	@Phr_observacao,
	@Pnm_login,
	@Pds_observacao)

go

