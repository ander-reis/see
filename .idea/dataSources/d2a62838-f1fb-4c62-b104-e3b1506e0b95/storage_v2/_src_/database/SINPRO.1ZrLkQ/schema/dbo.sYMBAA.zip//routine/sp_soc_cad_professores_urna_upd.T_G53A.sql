

/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_urna_upd
Descriçao:	Atualiza o Pasar Urna do Cadastro do Professor
Data da Criaçao: 09/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_urna_upd
(
@pNvc_professor		NVARCHAR(5),
@pTin_passar_urna		TINYINT
)
AS

UPDATE Cadastro_Professores SET
	Passar_Urna		= @pTin_passar_urna
WHERE Codigo_Professor = @pNvc_professor
go

