CREATE TRIGGER [INSSOC_PRO] ON dbo.Cadastro_Professores 
FOR INSERT

AS
DECLARE @Vcd_professor		NVARCHAR(5)
DECLARE @Vnm_professor		NVARCHAR(100)
DECLARE @Vfl_caixa_postal		TINYINT
DECLARE @Vds_endereco		NVARCHAR(63)
DECLARE @Vds_numero		NVARCHAR(6)
DECLARE @Vds_complemento		NVARCHAR(50)
DECLARE @Vds_bairro			NVARCHAR(59)
DECLARE @Vds_cidade		NVARCHAR(21)
DECLARE @Vds_uf			NVARCHAR(2)
DECLARE @Vds_cep			NVARCHAR(9)
DECLARE @Vds_ddd_residencial	NVARCHAR(2)
DECLARE @Vds_fone_residencial	NVARCHAR(9)
DECLARE @Vds_ramal_residencial	NVARCHAR(5)
DECLARE @Vds_ddd_comercial		NVARCHAR(2)
DECLARE @Vds_fone_comercial	NVARCHAR(9)
DECLARE @Vds_ramal_comercial	NVARCHAR(5)
DECLARE @Vds_ddd_celular		NVARCHAR(2)
DECLARE @Vds_celular			NVARCHAR(10)
DECLARE @Vds_CPF			NVARCHAR(14)
DECLARE @Vds_RG			NVARCHAR(12)
DECLARE @Vds_naturalidade		NVARCHAR(40)
DECLARE @Vdt_aniversario		DATETIME
DECLARE @Vdt_modificacao		DATETIME
DECLARE @Vfl_sexo			TINYINT
DECLARE @Vds_estado_civil		TINYINT
DECLARE @Vcd_prof_geral		REAL

DECLARE CurSOC_PRO_INS CURSOR FAST_FORWARD FOR

SELECT     Codigo_Professor, Nome, Caixa_Postal, Endereco, Numero, Complemento, Bairro, Cidade, Estado, CEP, DDD_Telefone_Residencial, 
                      Telefone_Residencial, Telefone_Residencial_Ramal, DDD_Telefone_Comercial, Telefone_Comercial, Telefone_Comercial_Ramal, 
                      DDD_Telefone_Celular, Telefone_Celular, CPF, RG, Naturalidade, Data_Aniversario, Data_Modificacao, Sexo, Estado_Civil
FROM Inserted

--Abrindo cursor
OPEN CurSOC_PRO_INS

--Buscando registro
FETCH NEXT FROM CurSOC_PRO_INS INTO @Vcd_professor, @Vnm_professor, @Vfl_caixa_postal, @Vds_endereco, @Vds_numero, @Vds_complemento, @Vds_bairro, @Vds_cidade, @Vds_uf,
					         @Vds_cep, @Vds_ddd_residencial, @Vds_fone_residencial, @Vds_ramal_residencial, @Vds_ddd_comercial, @Vds_fone_comercial, @Vds_ramal_comercial,
					         @Vds_ddd_celular, @Vds_celular, @Vds_CPF, @Vds_RG, @Vds_naturalidade, @Vdt_aniversario, @Vdt_modificacao, @Vfl_sexo, @Vds_estado_civil

--Laço do cursor
WHILE @@FETCH_STATUS = 0
BEGIN
	SET @Vcd_prof_geral = 0

	SELECT @Vcd_prof_geral = CodProf_Geral FROM Soc_Cadastro_Professor_Geral WHERE CPF = @Vds_CPF

	IF @Vcd_prof_geral = 0
		exec sp_soc_cad_professor_geral_ins @Vcd_professor, @Vnm_professor, @Vfl_caixa_postal, @Vds_endereco, @Vds_numero, @Vds_complemento, @Vds_bairro, @Vds_cidade, @Vds_uf,
						         @Vds_cep, @Vds_ddd_residencial, @Vds_fone_residencial, @Vds_ramal_residencial, @Vds_ddd_comercial, @Vds_fone_comercial, @Vds_ramal_comercial,
						         @Vds_ddd_celular, @Vds_celular, @Vds_CPF, @Vds_RG, @Vds_naturalidade, @Vdt_aniversario, @Vdt_modificacao, @Vfl_sexo, '', @Vds_estado_civil

	ELSE
		exec sp_soc_cad_professor_geral_upd 0, @Vcd_prof_geral, @Vcd_professor, @Vnm_professor, @Vfl_caixa_postal, @Vds_endereco, @Vds_numero, @Vds_complemento, @Vds_bairro, @Vds_cidade, @Vds_uf,
						         @Vds_cep, @Vds_ddd_residencial, @Vds_fone_residencial, @Vds_ramal_residencial, @Vds_ddd_comercial, @Vds_fone_comercial, @Vds_ramal_comercial,
						         @Vds_ddd_celular, @Vds_celular, @Vds_CPF, @Vds_RG, @Vds_naturalidade, @Vdt_aniversario, @Vdt_modificacao, @Vfl_sexo, '', @Vds_estado_civil

FETCH NEXT FROM CurSOC_PRO_INS INTO @Vcd_professor, @Vnm_professor, @Vfl_caixa_postal, @Vds_endereco, @Vds_numero, @Vds_complemento, @Vds_bairro, @Vds_cidade, @Vds_uf,
					         @Vds_cep, @Vds_ddd_residencial, @Vds_fone_residencial, @Vds_ramal_residencial, @Vds_ddd_comercial, @Vds_fone_comercial, @Vds_ramal_comercial,
					         @Vds_ddd_celular, @Vds_celular, @Vds_CPF, @Vds_RG, @Vds_naturalidade, @Vdt_aniversario, @Vdt_modificacao, @Vfl_sexo, @Vds_estado_civil
END

--Fechando e desalocando cursor
CLOSE CurSOC_PRO_INS
DEALLOCATE CurSOC_PRO_INS

go

