
CREATE TRIGGER [DELEMAIL_PRO] ON [dbo].[tb_professor_email] 
FOR DELETE

AS

DECLARE @Vcd_professor 	VARCHAR(5)
DECLARE @Vds_email1 	VARCHAR(120)
DECLARE @Vds_email2 	VARCHAR(120)
DECLARE @Vds_email3 	VARCHAR(120)

DECLARE CurEmail_SAS_DEL CURSOR FAST_FORWARD FOR
SELECT pro_ema_cd_professor, pro_ema_ds_email1, pro_ema_ds_email2, pro_ema_ds_email3
	FROM Deleted  

--Abrindo cursor
OPEN CurEmail_SAS_DEL

--Buscando registro
FETCH NEXT FROM CurEmail_SAS_DEL INTO @Vcd_professor, @Vds_email1, @Vds_email2, @Vds_email3

--Laço do cursor
WHILE @@FETCH_STATUS = 0
BEGIN
	DELETE FROM website.dbo.tb_sinpro_email_boletim 
		WHERE num_matricula = '0' + @Vcd_professor 
		
FETCH NEXT FROM CurEmail_SAS_DEL INTO @Vcd_professor, @Vds_email1, @Vds_email2, @Vds_email3
END

--Fechando e desalocando cursor
CLOSE CurEmail_SAS_DEL
DEALLOCATE CurEmail_SAS_DEL



go

