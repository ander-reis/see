

/*******************************************************************
Objeto criado: 	 sp_juridico_processo_angendamento_sel
Descriçao:	Seleciona os Agendamentos do Processo
Data da Criaçao: 26/06/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_agendamento_sel
(
@Pnr_pasta	NVARCHAR(8)
)
AS

SELECT
	PCA.jur_pca_cd_agendamento,
	PCA.jur_pca_cd_andamento,
	CONVERT(NVARCHAR(10),PCA.jur_pca_dt_agendamento,103) AS jur_pca_dt_agendamento,
	DAM.jur_and_ds_andamento,
	CONVERT(NVARCHAR(5),PCA.jur_pca_hr_agendamento,108) AS jur_pca_hr_agendamento, 
	PCA.jur_pca_ds_observacao,
	CASE PCA.jur_pca_fl_concluido
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS jur_pca_fl_concluido,
	CONVERT(NVARCHAR(10),PCA.jur_pca_dt_cadastro,103) AS jur_pca_dt_cadastro,
	PCA.jur_pca_nm_login,
	CASE ADV.jur_adv_cd_advogado
		WHEN 0 THEN ''
		ELSE ADV.jur_adv_nm_advogado
	END AS jur_adv_nm_advogado
FROM
	 tb_jur_processo_agendamento PCA
	INNER JOIN tb_jur_cadastro_andamento DAM ON PCA.jur_pca_cd_andamento = DAM.jur_and_cd_andamento
	INNER JOIN tb_jur_cadastro_advogado ADV ON PCA.jur_pca_cd_advogado = ADV.jur_adv_cd_advogado
WHERE
	PCA.jur_pca_nr_pasta = @Pnr_pasta
ORDER BY
	CONVERT(CHAR(10),PCA.jur_pca_dt_agendamento,111) DESC, CONVERT(CHAR(10),PCA.jur_pca_dt_cadastro,111) DESC
go

