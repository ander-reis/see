
/*******************************************************************
Objeto criado: 	 sp_eleicao_votos_sel
Descriçao:	Seleciona Votos na Eleicao
Data da Criaçao: 03/07/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_votos_sel
(
@Pds_eleicao		CHAR(4),
@Pdt_eleicao		DATETIME = '01/01/1900',
@Pds_urna		INT = 0,
@Pfl_tipo		TINYINT = 0

)
AS

IF @Pfl_tipo = 0 
BEGIN
	DECLARE @Vfl_urna	BIT
	
	IF @Pdt_eleicao = '1900/01/01' AND @Pds_urna = 0
	BEGIN
	
		EXEC sp_eleicao_data_sel @Pds_eleicao
	
	END
	ELSE
	BEGIN
		SELECT @Vfl_urna = 1 
		FROM tb_ele_votos EVT INNER JOIN
				tb_ele_votos_detalhe EVD ON EVT.ele_evt_ds_eleicao = EVD.ele_evd_ds_eleicao
			WHERE     EVT.ele_evt_ds_eleicao = @Pds_eleicao
				AND EVT.ele_evt_ds_urna = @Pds_urna
	
		IF @Vfl_urna = 1
		BEGIN
			SELECT     
				EVT.ele_evt_nr_eleitor, 
				EVT.ele_evt_nr_total_votos AS Votos, 
				EVT.ele_evt_nr_total_separado,
				EVT.ele_evt_nr_total_branco,
				EVT.ele_evt_nr_total_nulo,
				EVT.ele_evt_nr_inscrito,
				EVT.ele_evt_nr_normal,
				EVT.ele_evt_nr_desprezado,
				EVT.ele_evt_fl_status,
				EVT.ele_evt_ds_urna,
				1 AS Retorno
			FROM tb_ele_votos EVT INNER JOIN
	        			tb_ele_datas EDT ON EVT.ele_evt_ds_eleicao = EDT.ele_edt_ds_eleicao
			WHERE EVT.ele_evt_ds_eleicao = @Pds_eleicao
				AND EVT.ele_evt_ds_urna = @Pds_urna
		
			SET @Vfl_urna = 0
	
			SELECT     @Vfl_urna = 1
			FROM tb_ele_votos EVT INNER JOIN
				tb_ele_votos_detalhe EVD ON EVT.ele_evt_ds_eleicao = EVD.ele_evd_ds_eleicao AND EVT.ele_evt_ds_urna = EVD.ele_evd_ds_urna
			WHERE     EVT.ele_evt_ds_eleicao = @Pds_eleicao
				AND EVD.ele_evd_dt_eleicao =  @Pdt_eleicao 
				AND EVT.ele_evt_ds_urna = @Pds_urna
	
			IF @Vfl_urna = 1
				SELECT     
					EVT.ele_evt_nr_inscrito,
					EVD.ele_evd_ds_chapa, 
					EVD.ele_evd_nr_valido, 
					EVD.ele_evd_nr_val_branco, 
					EVD.ele_evd_nr_val_nulo,
					1 AS Retorno
				FROM tb_ele_votos EVT INNER JOIN
					tb_ele_votos_detalhe EVD ON EVT.ele_evt_ds_eleicao = EVD.ele_evd_ds_eleicao AND EVT.ele_evt_ds_urna = EVD.ele_evd_ds_urna
				WHERE     EVT.ele_evt_ds_eleicao = @Pds_eleicao
					AND EVD.ele_evd_dt_eleicao =  @Pdt_eleicao 
					AND EVT.ele_evt_ds_urna = @Pds_urna
				ORDER BY EVD.ele_evd_ds_chapa
			ELSE
				SELECT     
					DISTINCT ele_cda_ds_chapa AS ele_cda_ds_chapa,
					0 AS Retorno
				FROM tb_ele_cand_dados
				WHERE ele_cda_ds_eleicao = @Pds_eleicao
				ORDER BY ele_cda_ds_chapa ASC
		END
		ELSE
		BEGIN
			SELECT 
				COUNT(DISTINCT PGE.CPF) AS Votos,
				0 AS Retorno
			FROM Cadastro_Escolas CE INNER JOIN 
				Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
				Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
			WHERE  CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
				AND CP.Situacao IN (1,5,9,2,10,12,13) 
				AND PGE.CGC_Escola <> '00.000.000/0000-00'
			 	AND CE.Categoria IN (1,6) 
				AND CE.Situacao IN (0,1) 
				AND CE.Urna = @Pds_urna 
			GROUP BY CE.Urna
			HAVING COUNT(PGE.CPF) >= 1
	
			SELECT     
				DISTINCT ele_cda_ds_chapa AS ele_cda_ds_chapa,
				0 AS Retorno
			FROM tb_ele_cand_dados
			WHERE ele_cda_ds_eleicao = @Pds_eleicao
			ORDER BY ele_cda_ds_chapa ASC
		END
	END
END
ELSE
BEGIN
	DECLARE @Vnr_direito_voto	AS INTEGER

	SET @Vnr_direito_voto = 0

	SELECT 
		@Vnr_direito_voto = COUNT(DISTINCT PGE.CPF)
	FROM Cadastro_Escolas CE INNER JOIN 
		Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
		Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
	WHERE  CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
		AND CP.Situacao IN (1,5,9,2,10,12,13) 
		AND PGE.CGC_Escola <> '00.000.000/0000-00'
	 	AND CE.Categoria IN (1,6) 
		AND CE.Situacao IN (0,1) 
	
	HAVING COUNT(PGE.CPF) >= 1

	
	SELECT     
		EVT.ele_evt_ds_urna,
		EVT.ele_evt_nr_inscrito,
		EVT.ele_evt_nr_total_votos,
		EVT.ele_evt_nr_total_branco,
		EVT.ele_evt_nr_total_nulo,
		@Vnr_direito_voto AS ele_evt_eleicao_inscrito,
--		TOT.ele_evt_eleicao_inscrito,
		TOT.ele_evt_eleicao_valido,
		TOT.ele_evt_eleicao_branco,
		TOT.ele_evt_eleicao_nulo
	FROM tb_ele_votos EVT
		INNER JOIN (SELECT EVT.ele_evt_ds_eleicao, SUM(EVT.ele_evt_nr_inscrito) AS ele_evt_eleicao_inscrito,
				SUM(EVT.ele_evt_nr_total_votos) AS ele_evt_eleicao_valido,
				SUM(EVT.ele_evt_nr_total_branco) AS ele_evt_eleicao_branco,
				SUM(EVT.ele_evt_nr_total_nulo) AS ele_evt_eleicao_nulo
				FROM tb_ele_votos EVT
				WHERE EVT.ele_evt_ds_eleicao = @Pds_eleicao
				GROUP BY EVT.ele_evt_ds_eleicao
			    ) AS TOT ON EVT.ele_evt_ds_eleicao = TOT.ele_evt_ds_eleicao
	
	WHERE     EVT.ele_evt_ds_eleicao = @Pds_eleicao
	ORDER BY EVT.ele_evt_ds_urna
END
go

