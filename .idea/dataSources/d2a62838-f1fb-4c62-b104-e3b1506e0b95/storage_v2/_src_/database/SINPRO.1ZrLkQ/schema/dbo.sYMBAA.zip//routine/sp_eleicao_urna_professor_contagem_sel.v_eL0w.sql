/*******************************************************************
Objeto criado: 	 sp_eleicao_urna_professor_contagem_sel
Descriçao:	Tabela para contagem dos inscritos por urna
Data da Criaçao: 03/10/2014
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_urna_professor_contagem_sel
(
@Pnr_urna		SMALLINT = 0
)
AS
DELETE
FROM tb_eleicao_urna_contagem_professor
WHERE ele_urc_ds_eleicao = DATEPART(year,GETDATE())
	AND ele_urc_nr_urna = @Pnr_urna

IF @Pnr_urna <> 1 

	INSERT INTO tb_eleicao_urna_contagem_professor (ele_urc_ds_eleicao, ele_urc_nr_urna, ele_urc_cd_professor, ele_urc_ds_cnpj, ele_urc_fl_fechou, ele_urc_fl_quorum)
		SELECT DISTINCT DATEPART(year,GETDATE()),@Pnr_urna,CP.Codigo_Professor, PGE.CGC_Escola, 0,1
		FROM Cadastro_Escolas CE
			INNER JOIN Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola
			INNER JOIN Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
		 WHERE CP.Situacao IN (1, 2, 5, 10, 12, 13)
			AND CP.CPF <> '000.000.000-00' 
			AND CE.CGC_Escola <> '00.000.000/0000-00'
			AND CE.Urna  = @Pnr_urna 
			AND CONVERT(CHAR(8),CP.Data_Inicio,112) <= CONVERT(CHAR(8),DATEADD(month, - 6, DATEADD(day, - 1, '10/24/2018')),112)
		ORDER BY CP.Codigo_Professor

ELSE

	INSERT INTO tb_eleicao_urna_contagem_professor (ele_urc_ds_eleicao, ele_urc_nr_urna, ele_urc_cd_professor, ele_urc_ds_cnpj, ele_urc_fl_fechou, ele_urc_fl_quorum)
		SELECT DISTINCT DATEPART(year,GETDATE()),@Pnr_urna,CP.Codigo_Professor, PGE.CGC_Escola, 0, 1
		FROM Cadastro_Escolas CE
			INNER JOIN Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola
			INNER JOIN Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
		 WHERE CP.Situacao IN (1, 2, 5, 10, 12, 13)
			AND CP.CPF <> '000.000.000-00' 
			AND CE.CGC_Escola <> '00.000.000/0000-00'
			AND CE.Urna  = @Pnr_urna 
			AND CONVERT(CHAR(8),CP.Data_Inicio,112) <= CONVERT(CHAR(8),DATEADD(month, - 6, DATEADD(day, - 1, '10/24/2018')),112)

		UNION 
		
		SELECT DISTINCT DATEPART(year,GETDATE()),@Pnr_urna,CP.Codigo_Professor, PGE.CGC_Escola, 0, 0
		FROM Cadastro_Escolas CE
			INNER JOIN Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola
			INNER JOIN Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
		 WHERE CP.Situacao IN (2, 10)
			AND CP.CPF <> '000.000.000-00' 
			AND CE.CGC_Escola = '00.000.000/0000-00'
			AND CONVERT(CHAR(8),CP.Data_Inicio,112) <= CONVERT(CHAR(8),DATEADD(month, - 6, DATEADD(day, - 1, '10/24/2018')),112)
		ORDER BY CP.Codigo_Professor
go

