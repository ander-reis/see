/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_processo_sel
Descriçao:	Seleciona Processo para Audiência
Data da Criaçao: 08/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_processo_sel
(
@Pnr_pasta	VARCHAR(20),
@Pfl_tipo	TINYINT
)
AS

IF @Pfl_tipo = 1
	SELECT
		PRC.jur_prc_nr_pasta,
		PRC.jur_prc_nr_processo,
		PRC.jur_prc_fl_situacao,
		PRC.jur_prc_fl_encerrado,
		PRC.jur_prc_cd_advogado, 
                     	ADV.jur_adv_nm_advogado, FIP.jur_fip_cd_professor, CP.Nome, CE.Nome_Fantasia,
		'(' + CP.DDD_Telefone_Residencial + ')' + CP.Telefone_Residencial AS Residencial,
		'(' + CP.DDD_Telefone_Celular + ')' + CP.Telefone_Celular AS Celular,
		'(' + CP.DDD_Telefone_Comercial + ')' + CP.Telefone_Comercial AS Comercial,
		CVA.jur_cva_ds_vara,
		CONVERT(CHAR(10),ISNULL(AUD.jur_aud_dt_audiencia, '01/01/1900'),103) AS jur_aud_dt_audiencia,
		CONVERT(CHAR(5),ISNULL(AUD.jur_aud_hr_audiencia, '00:00:00'),108) AS jur_aud_hr_audiencia,
		ISNULL(AUD.jur_aud_fl_situacao, 9) AS jur_aud_fl_situacao,
		AUD.jur_aud_fl_realizada
	FROM         Cadastro_Professores CP INNER JOIN
                      tb_jur_ficha_consulta FIC INNER JOIN
                      tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      tb_jur_cadastro_advogado ADV ON PRC.jur_prc_cd_advogado = ADV.jur_adv_cd_advogado INNER JOIN
                      tb_jur_cadastro_vara CVA ON PRC.jur_prc_cd_vara = CVA.jur_cva_cd_vara INNER JOIN
                      Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola ON CP.Codigo_Professor = FIP.jur_fip_cd_professor
	         LEFT OUTER JOIN tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta
	WHERE
		PRC.jur_prc_nr_pasta = @Pnr_pasta
ELSE
	SELECT
		PRC.jur_prc_nr_pasta,
		PRC.jur_prc_nr_processo,
		PRC.jur_prc_fl_situacao,
		PRC.jur_prc_fl_encerrado,
		PRC.jur_prc_cd_advogado, 
                     	ADV.jur_adv_nm_advogado, FIP.jur_fip_cd_professor, CP.Nome, CE.Nome_Fantasia,
		'(' + CP.DDD_Telefone_Residencial + ')' + CP.Telefone_Residencial AS Residencial,
		'(' + CP.DDD_Telefone_Celular + ')' + CP.Telefone_Celular AS Celular,
		'(' + CP.DDD_Telefone_Comercial + ')' + CP.Telefone_Comercial AS Comercial,
		CVA.jur_cva_ds_vara,
		CONVERT(CHAR(10),ISNULL(AUD.jur_aud_dt_audiencia, '01/01/1900'),103) AS jur_aud_dt_audiencia,
		CONVERT(CHAR(5),ISNULL(AUD.jur_aud_hr_audiencia, '00:00:00'),108) AS jur_aud_hr_audiencia,
		ISNULL(AUD.jur_aud_fl_situacao, 9) AS jur_aud_fl_situacao,
		AUD.jur_aud_fl_realizada
	FROM         Cadastro_Professores CP INNER JOIN
                      tb_jur_ficha_consulta FIC INNER JOIN
                      tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      tb_jur_cadastro_advogado ADV ON PRC.jur_prc_cd_advogado = ADV.jur_adv_cd_advogado INNER JOIN
                      tb_jur_cadastro_vara CVA ON PRC.jur_prc_cd_vara = CVA.jur_cva_cd_vara INNER JOIN
                      Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola ON CP.Codigo_Professor = FIP.jur_fip_cd_professor
	         LEFT OUTER JOIN tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta
	WHERE
		PRC.jur_prc_nr_processo = @Pnr_pasta
go

