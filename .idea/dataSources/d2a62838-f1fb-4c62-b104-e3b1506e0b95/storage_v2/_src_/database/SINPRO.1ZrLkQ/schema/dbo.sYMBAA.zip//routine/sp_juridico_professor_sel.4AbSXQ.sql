


/*******************************************************************
Objeto criado: 	 sp_juridico_professor_sel
Descriçao:	Seleciona o Telefone do Professor
Data da Criaçao: 08/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_professor_sel
(
@Pcd_matricula	AS NVARCHAR(5)
)
AS

SELECT 
	'(' + DDD_Telefone_Residencial + ') ' + Telefone_Residencial AS Residencial,
	'(' + DDD_Telefone_Comercial + ') ' + Telefone_Comercial AS Comercial,
	'(' + DDD_Telefone_Celular + ') ' + Telefone_Celular AS Celular
FROM Cadastro_Professores 
WHERE Codigo_Professor = @Pcd_matricula

go

