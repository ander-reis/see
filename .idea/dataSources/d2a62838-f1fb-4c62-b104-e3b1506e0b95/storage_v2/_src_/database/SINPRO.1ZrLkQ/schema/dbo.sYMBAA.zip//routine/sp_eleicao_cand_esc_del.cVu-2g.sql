

/*******************************************************************
Objeto criado: 	 sp_eleicao_cand_esc_del
Descriçao:	Apaga Causas
Data da Criaçao: 29/09/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_cand_esc_del
(
@Pcd_candidato 	NVARCHAR(5),
@Pcd_escola		NVARCHAR(18)
)
AS

DELETE
FROM
	tb_ele_cand_escola
WHERE     
	ele_ces_cd_candidato = @Pcd_candidato
	AND ele_ces_cd_escola = @Pcd_escola

go

