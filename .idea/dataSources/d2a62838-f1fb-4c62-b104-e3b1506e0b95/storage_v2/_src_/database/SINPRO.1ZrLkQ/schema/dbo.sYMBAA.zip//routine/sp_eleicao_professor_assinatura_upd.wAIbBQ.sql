/*******************************************************************
Objeto criado: 	 sp_eleicao_professor_assinatura_upd
Descriçao:	Atualiza a Vara
Data da Criaçao:25/10/2018
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_professor_assinatura_upd
(
@Pcd_professor		NVARCHAR(5),
@Pass1	NVARCHAR(4000),
@Pass2	NVARCHAR(4000),
@Pass3	NVARCHAR(4000),
@Pass4	NVARCHAR(4000),
@Pass5	NVARCHAR(4000),
@Pass6	NVARCHAR(4000),
@Pass7	NVARCHAR(4000),
@Pass8	NVARCHAR(4000),
@Pass9	NVARCHAR(4000),
@Pass10	NVARCHAR(4000)
)

AS

UPDATE tb_eleicao_professor_assinatura SET
                    ds_ass1 = CONVERT(NVARCHAR(4000),@Pass1),
                    ds_ass2 = CONVERT(NVARCHAR(4000),@Pass2),
                    ds_ass3 = CONVERT(NVARCHAR(4000),@Pass3),
                    ds_ass4 = CONVERT(NVARCHAR(4000),@Pass4),
                    ds_ass5 = CONVERT(NVARCHAR(4000),@Pass5),
                    ds_ass6 = CONVERT(NVARCHAR(4000),@Pass6),
                    ds_ass7 = CONVERT(NVARCHAR(4000),@Pass7),
                    ds_ass8 = CONVERT(NVARCHAR(4000),@Pass8),
                    ds_ass9 = CONVERT(NVARCHAR(4000),@Pass9),
                    ds_ass10 = CONVERT(NVARCHAR(4000),@Pass10)
                    WHERE cd_professor = @Pcd_professor
go

