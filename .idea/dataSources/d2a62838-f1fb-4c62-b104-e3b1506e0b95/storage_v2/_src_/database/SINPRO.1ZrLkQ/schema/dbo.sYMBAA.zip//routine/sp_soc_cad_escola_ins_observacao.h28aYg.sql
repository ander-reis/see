
/*******************************************************************
Objeto criado: 	 sp_soc_cad_escola_ins_observacao
Descriçao:	Inclui Observações da Escola
Entrada:	@pNvc_CNPJ  -> CNPJ da Escola
Saída:		
Data da Criaçao: 28/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_escola_ins_observacao
(
@pNvc_CNPJ				NVARCHAR(18),
@pDt_data				DATETIME,
@pNtx_observacao			NTEXT,
@pNvc_user				VARCHAR(30),
@pDt_hora				DATETIME
)
AS


INSERT INTO SINPRO.dbo.Escola_Observacoes (
	CGC_Escola,
	Data,
	Observacoes,
	Login,
	Hora) 
VALUES (
	@pNvc_CNPJ,
	CONVERT(DATETIME,@pDt_data,102),
	@pNtx_observacao,
	@pNvc_user,
	CONVERT(DATETIME,@pDt_hora,108)
	)
go

