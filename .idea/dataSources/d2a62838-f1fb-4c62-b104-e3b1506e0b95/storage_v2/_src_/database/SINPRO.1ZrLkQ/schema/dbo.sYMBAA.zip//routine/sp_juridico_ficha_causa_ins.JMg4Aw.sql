

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_causa_ins
Descriçao:	 Inserir Causa do Processo na Ficha
Data da Criaçao: 02/03/2007
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_causa_ins
(
@Pnr_ficha 	INT,
@Pcd_causa 	INT,
@Pnm_login	NVARCHAR(30)
)
AS

INSERT INTO tb_jur_ficha_causa
	(jur_fca_nr_ficha,
	jur_fca_cd_causa,
	jur_fca_nm_login,
	jur_fca_dt_cadastro,	
	jur_fca_fl_vara)
VALUES
	(@Pnr_ficha,
	@Pcd_causa,
	@Pnm_login,
	GETDATE(),
	-1)
go

