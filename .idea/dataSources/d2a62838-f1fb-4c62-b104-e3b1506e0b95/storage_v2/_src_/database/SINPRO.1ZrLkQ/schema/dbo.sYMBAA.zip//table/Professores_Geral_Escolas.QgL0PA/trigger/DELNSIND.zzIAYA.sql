CREATE TRIGGER [DELNSIND] ON dbo.Professores_Geral_Escolas 
FOR DELETE 
AS

INSERT PGE_BKP SELECT *, GETDATE() FROM deleted WHERE Sindicalizado = 0
go

