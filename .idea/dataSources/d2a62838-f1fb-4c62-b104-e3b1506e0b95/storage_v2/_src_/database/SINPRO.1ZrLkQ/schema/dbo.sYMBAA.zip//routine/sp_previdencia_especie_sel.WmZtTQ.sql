

/*******************************************************************
Objeto criado: 	 sp_previdencia_especie_sel
Descriçao:	Seleciona as espécies de um determinado período
Data da Criaçao: 10/09/2007
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_previdencia_especie_sel
(
@Pnr_especie	INT,
@Pdt_Inicio	DATETIME,
@Pdt_Fim 	DATETIME ,
@Pnr_tipo 	INT
)
AS
IF @Pnr_tipo='0' --COM ENTRADA
	SELECT     
		PRA.prev_pra_cd_previdencia, 
		SCPG.Codigo_Professor, 
		SCPG.Nome, 
		SCPG.CPF, 
		PRA.prev_pra_nr_beneficio, 
		PRA.prev_pra_dt_entrada, 
                      	PRA.prev_pra_dt_concessao,
		CASE PRA.prev_pra_fl_situacao WHEN '0' THEN 'Ativo' WHEN '1' THEN 'Cancelado' WHEN '2' THEN 'Finalizado' END AS SITUACAO
	FROM   
		tb_prev_atendimento PRA INNER JOIN   Soc_Cadastro_Professor_Geral SCPG ON PRA.prev_pra_cd_codprofgeral = SCPG.CodProf_Geral INNER JOIN   tb_prev_atendimento_tipoespecie PAE ON PRA.prev_pra_cd_tipoespecie = PAE.prev_pae_cd_tipoespecie
	WHERE     
		PRA.prev_pra_cd_tipoespecie = @Pnr_especie  AND PRA.prev_pra_dt_entrada BETWEEN @Pdt_Inicio  AND @Pdt_Fim AND PRA.prev_pra_fl_situacao<>'1'
	ORDER BY SCPG.Nome
ELSE IF @Pnr_tipo='1' --- SEM ENTRADA
	SELECT     
		PRA.prev_pra_cd_previdencia, 
		SCPG.Codigo_Professor, 
		SCPG.Nome, 
		SCPG.CPF, 
		PRA.prev_pra_nr_beneficio, 
		PRA.prev_pra_dt_entrada, 
                      	PRA.prev_pra_dt_concessao,
		CASE PRA.prev_pra_fl_situacao WHEN '0' THEN 'Ativo' WHEN '1' THEN 'Cancelado' WHEN '2' THEN 'Finalizado' END AS SITUACAO
	FROM   
		tb_prev_atendimento PRA INNER JOIN   Soc_Cadastro_Professor_Geral SCPG ON PRA.prev_pra_cd_codprofgeral = SCPG.CodProf_Geral INNER JOIN   tb_prev_atendimento_tipoespecie PAE ON PRA.prev_pra_cd_tipoespecie = PAE.prev_pae_cd_tipoespecie
	WHERE     
		PRA.prev_pra_cd_tipoespecie = @Pnr_especie  AND PRA.prev_pra_dt_cadastro  BETWEEN @Pdt_Inicio  AND @Pdt_Fim AND PRA.prev_pra_fl_situacao<>'1' AND PRA.prev_pra_dt_entrada='01/01/1900'
	ORDER BY SCPG.Nome
ELSE IF @Pnr_tipo='2' --- TODOS
	SELECT     
		PRA.prev_pra_cd_previdencia, 
		SCPG.Codigo_Professor, 
		SCPG.Nome, 
		SCPG.CPF, 
		PRA.prev_pra_nr_beneficio, 
		PRA.prev_pra_dt_entrada, 
                      	PRA.prev_pra_dt_concessao,
		CASE PRA.prev_pra_fl_situacao WHEN '0' THEN 'Ativo' WHEN '1' THEN 'Cancelado' WHEN '2' THEN 'Finalizado' END AS SITUACAO
	FROM   
		tb_prev_atendimento PRA INNER JOIN   Soc_Cadastro_Professor_Geral SCPG ON PRA.prev_pra_cd_codprofgeral = SCPG.CodProf_Geral INNER JOIN   tb_prev_atendimento_tipoespecie PAE ON PRA.prev_pra_cd_tipoespecie = PAE.prev_pae_cd_tipoespecie
	WHERE     
		PRA.prev_pra_cd_tipoespecie = @Pnr_especie  AND PRA.prev_pra_dt_cadastro  BETWEEN @Pdt_Inicio  AND @Pdt_Fim AND PRA.prev_pra_fl_situacao<>'1' 
	ORDER BY SCPG.Nome
go

