/*******************************************************************
Objeto criado: 	 sp_juridico_processo_financeiro_sel
Descriçao:	Seleciona o Financeiro do Professor do Processo
Data da Criaçao: 27/06/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_financeiro_sel
(
@Pnr_pasta	NVARCHAR(8),
@Pcd_fic_pro	INT
)
AS

SELECT
	PCF.jur_pcf_nr_pagamento,
	PCF.jur_pcf_nr_parcela,
	CONVERT(NVARCHAR(10),PCF.jur_pcf_dt_vencimento,103) AS jur_pcf_dt_vencimento,
	CONVERT(DECIMAL(10,2),PCF.jur_pcf_vl_parcela) AS jur_pcf_vl_parcelas,
	CONVERT(DECIMAL(10,2),PCF.jur_pcf_vl_taxa) AS jur_pcf_vl_taxa,
	CONVERT(DECIMAL(10,2),PCF.jur_pcf_vl_honorario) AS jur_pcf_vl_honorario,
	CONVERT(DECIMAL(10,2),PCF.jur_pcf_vl_parcela - PCF.jur_pcf_vl_taxa - PCF.jur_pcf_vl_honorario) AS jur_pcf_vl_total,
	PCF.jur_pcf_ds_observacao,
	PCF.jur_pcf_nr_taxa,
	CASE PCF.jur_pcf_fl_destino
		WHEN 0 THEN 'SINPRO'
		ELSE 'PROFESSOR'
	END jur_pcf_fl_destino,
	PCF.jur_pcf_ds_titulo,
	CASE CONVERT(NVARCHAR(10),PCF.jur_pcf_dt_pagamento,103) 
		WHEN '01/01/1900' THEN ''
		ELSE CONVERT(NVARCHAR(10),PCF.jur_pcf_dt_pagamento,103)
	END AS jur_pcf_dt_pagamento,
	PCF.jur_pcf_ds_forma,
	PCF.jur_pcf_cd_banco,
	CB.Banco AS pro_ban_ds_banco,
	PCF.jur_pcf_nr_agencia,
	PCF.jur_pcf_nr_conta,
	CASE PCF.jur_pcf_fl_poupanca
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END jur_pcf_fl_poupanca,
	CASE PCF.jur_pcf_fl_conjunta
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS jur_pcf_fl_conjunta,
	PCF.jur_pcf_nm_login,
	PCF.jur_pcf_fl_situacao
FROM
	tb_jur_processo_financeiro PCF
	INNER JOIN Cadastro_Banco CB ON PCF.jur_pcf_cd_banco = CB.CodBanco
WHERE
	PCF.jur_pcf_nr_pasta = @Pnr_pasta
	AND PCF.jur_pcf_cd_fic_pro = @Pcd_fic_pro
	AND PCF.jur_pcf_fl_siga <= 5
ORDER BY
	CONVERT(CHAR(8),jur_pcf_dt_vencimento,112), jur_pcf_nr_parcela
go

