

/*******************************************************************
Objeto criado: 	 sp_previdencia_especie_resumo_sel
Descriçao:	Seleciona as espécies de um determinado período
Data da Criaçao: 10/09/2007
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_previdencia_especie_resumo_sel
(
@Pdt_Inicio	DATETIME,
@Pdt_Fim 	DATETIME ,
@Pnr_tipo 	INT
)
AS
IF @Pnr_tipo='0' -- COM ENTRADA
	SELECT 
		DISTINCT PAE.prev_pae_ds_especie, 
		COUNT(PAE.prev_pae_ds_especie) AS QTDE
	FROM         
		tb_prev_atendimento PRA INNER JOIN   tb_prev_atendimento_tipoespecie PAE ON PRA.prev_pra_cd_tipoespecie = PAE.prev_pae_cd_tipoespecie
	WHERE    PRA.prev_pra_dt_entrada BETWEEN @Pdt_Inicio  AND @Pdt_Fim AND PRA.prev_pra_fl_situacao<>'1'
	GROUP BY PAE.prev_pae_ds_especie
	ORDER BY PAE.prev_pae_ds_especie
ELSE IF @Pnr_tipo='1' -- SEM ENTRADA
	SELECT 
		DISTINCT PAE.prev_pae_ds_especie, 
		COUNT(PAE.prev_pae_ds_especie) AS QTDE
	FROM         
		tb_prev_atendimento PRA INNER JOIN   tb_prev_atendimento_tipoespecie PAE ON PRA.prev_pra_cd_tipoespecie = PAE.prev_pae_cd_tipoespecie
	WHERE     (PRA.prev_pra_dt_cadastro  BETWEEN @Pdt_Inicio AND @Pdt_Fim) AND (PRA.prev_pra_fl_situacao <> '1') AND PRA.prev_pra_dt_entrada='01/01/1900'
	GROUP BY PAE.prev_pae_ds_especie
	ORDER BY PAE.prev_pae_ds_especie
ELSE IF @Pnr_tipo='2' -- SEM ENTRADA
	SELECT 
		DISTINCT PAE.prev_pae_ds_especie, 
		COUNT(PAE.prev_pae_ds_especie) AS QTDE
	FROM         
		tb_prev_atendimento PRA INNER JOIN   tb_prev_atendimento_tipoespecie PAE ON PRA.prev_pra_cd_tipoespecie = PAE.prev_pae_cd_tipoespecie
	WHERE     (PRA.prev_pra_dt_cadastro  BETWEEN @Pdt_Inicio AND @Pdt_Fim) AND (PRA.prev_pra_fl_situacao <> '1')
	GROUP BY PAE.prev_pae_ds_especie
	ORDER BY PAE.prev_pae_ds_especie
go

