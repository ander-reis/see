/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_imagem_ins
Descriçao:	Cadastra as Imagens da Ficha de Consulta
Data da Criaçao: 13/03/2014
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_imagem_ins
(
@Pcd_imagem		INT,
@Pnr_ficha		INT,
@Pds_arquivo		NVARCHAR(300),
@Pds_observacao	NVARCHAR(600),
@Pdt_cadastro		DATETIME,
@Pnm_login		NVARCHAR(30)
)

AS

IF @Pcd_imagem = 0  
	INSERT INTO tb_jur_ficha_imagem
		(jur_img_nr_ficha,
		jur_img_ds_arquivo,
		jur_img_ds_observacao,
		jur_img_dt_cadastro,
		jur_img_nm_login)
	VALUES
		(@Pnr_ficha,
		@Pds_arquivo,
		@Pds_observacao,
		@Pdt_cadastro,
		@Pnm_login)
ELSE
	UPDATE  tb_jur_ficha_imagem SET
		jur_img_ds_arquivo	= @Pds_arquivo,
		jur_img_ds_observacao	= @Pds_observacao,
		jur_img_dt_cadastro	= @Pdt_cadastro, 
		jur_img_nm_login	= @Pnm_login
	WHERE
		jur_img_cd_imagem = @Pcd_imagem
go

