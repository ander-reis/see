

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_professor_documento_upd
Descriçao:	 Inserir Causa do Processo na Ficha
Data da Criaçao: 05/03/2007
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_professor_documento_upd
(
@Pcd_doc_pro		INT,
@Pdt_entrega		DATETIME,
@Pnm_entrega		NVARCHAR(30),
@Pds_complemento	NVARCHAR(300) = ''
)
AS

UPDATE tb_jur_ficha_professor_documento SET
	jur_fpd_dt_entrega = @Pdt_entrega,	
	jur_fpd_nm_entrega = @Pnm_entrega,
	jur_fpd_ds_complemento = @Pds_complemento
WHERE
	jur_fpd_cd_doc_pro = @Pcd_doc_pro
go

