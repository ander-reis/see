--*******************************************************************
--Objeto criado: 	 sp_juridico_processo_tempo_sel
--**Descriçao:	Informa o tempo dos processos
--Data da Criaçao: 19/02/20088
--Autor:		Adriana - SinproSP
--*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_tempo_sel
(
@Pdt_inicio		DATETIME,
@Pfl_situacao		INT,
@Pfl_encerramento	INT=''


)

AS

IF @Pfl_situacao=0
BEGIN
	SELECT DISTINCT 
                      	PRC.jur_prc_nr_pasta, 
		PRC.jur_prc_dt_distribuicao, 
		CP.Nome, CE.Razao_Social, 
		DATEDIFF(day, PRC.jur_prc_dt_distribuicao, GETDATE())  AS DIFERENCA, 
		CASE PRC.jur_prc_fl_encerrado WHEN '0' THEN 'NÃO' WHEN '1' THEN 'SIM' END AS ENCERRADO
	FROM    
		tb_jur_ficha_professor FIP INNER JOIN
                     	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                     	 tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                     	 Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola
	WHERE     PRC.jur_prc_dt_distribuicao >= @Pdt_inicio
		AND CP.Codigo_Professor <> '00000'
		AND  FIC.jur_fic_fl_processo = '0' 
		AND PRC.jur_prc_fl_encerrado=@Pfl_encerramento

	UNION 

	SELECT DISTINCT 
                     	 PRC.jur_prc_nr_pasta, 
		PRC.jur_prc_dt_distribuicao, 
		CP.Nome, 
		CE.Razao_Social, 
		DATEDIFF(day, PRC.jur_prc_dt_distribuicao, GETDATE()) 	AS DIFERENCA, 
		CASE PRC.jur_prc_fl_encerrado WHEN '0' THEN 'NÃO' WHEN '1' THEN 'SIM' END AS ENCERRADO
	FROM
  		tb_jur_ficha_professor FIP INNER JOIN
                     	 Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola
	WHERE     PRC.jur_prc_dt_distribuicao >= @Pdt_inicio
		AND CP.Codigo_Professor = '00000'
		AND FIC.jur_fic_fl_processo = '1'
		AND PRC.jur_prc_fl_encerrado=@Pfl_encerramento
END
ELSE IF @Pfl_situacao=1
BEGIN
	SELECT DISTINCT 
                      	PRC.jur_prc_nr_pasta, 
		PRC.jur_prc_dt_distribuicao, 
		CP.Nome, CE.Razao_Social, 
		DATEDIFF(day, PRC.jur_prc_dt_distribuicao, PRC.jur_prc_dt_final)  AS DIFERENCA, 
		CASE PRC.jur_prc_fl_encerrado WHEN '0' THEN 'NÃO' WHEN '1' THEN 'SIM' END AS ENCERRADO
	FROM    
		tb_jur_ficha_professor FIP INNER JOIN
                     	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                     	 tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                     	 Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola
	WHERE     PRC.jur_prc_dt_distribuicao >= @Pdt_inicio
		AND CP.Codigo_Professor <> '00000'
		AND  FIC.jur_fic_fl_processo = '0' 
		AND PRC.jur_prc_fl_encerrado=@Pfl_encerramento

	UNION 

	SELECT DISTINCT 
                     	 PRC.jur_prc_nr_pasta, 
		PRC.jur_prc_dt_distribuicao, 
		CP.Nome, 
		CE.Razao_Social, 
		DATEDIFF(day, PRC.jur_prc_dt_distribuicao,PRC.jur_prc_dt_final) 	AS DIFERENCA, 
		CASE PRC.jur_prc_fl_encerrado WHEN '0' THEN 'NÃO' WHEN '1' THEN 'SIM' END AS ENCERRADO
	FROM
  		tb_jur_ficha_professor FIP INNER JOIN
                     	 Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola
	WHERE     PRC.jur_prc_dt_distribuicao >= @Pdt_inicio
		AND CP.Codigo_Professor = '00000'
		AND FIC.jur_fic_fl_processo = '1'
		AND PRC.jur_prc_fl_encerrado=@Pfl_encerramento
END
ELSE IF @Pfl_situacao=2
BEGIN
	SELECT DISTINCT 
                      	PRC.jur_prc_nr_pasta, 
		PRC.jur_prc_dt_distribuicao, 
		CP.Nome, CE.Razao_Social, 
		DATEDIFF(day, PRC.jur_prc_dt_distribuicao, PRC.jur_prc_dt_final)  AS DIFERENCA, 
		CASE PRC.jur_prc_fl_encerrado WHEN '0' THEN 'NÃO' WHEN '1' THEN 'SIM' END AS ENCERRADO
	FROM    
		tb_jur_ficha_professor FIP INNER JOIN
                     	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                     	 tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                     	 Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola
	WHERE     PRC.jur_prc_dt_distribuicao >= @Pdt_inicio
		AND CP.Codigo_Professor <> '00000'
		AND  FIC.jur_fic_fl_processo = '0' 
		AND PRC.jur_prc_fl_encerrado='1'		

	UNION 

	SELECT DISTINCT 
                     	 PRC.jur_prc_nr_pasta, 
		PRC.jur_prc_dt_distribuicao, 
		CP.Nome, 
		CE.Razao_Social, 
		DATEDIFF(day, PRC.jur_prc_dt_distribuicao,PRC.jur_prc_dt_final) 	AS DIFERENCA, 
		CASE PRC.jur_prc_fl_encerrado WHEN '0' THEN 'NÃO' WHEN '1' THEN 'SIM' END AS ENCERRADO
	FROM
  		tb_jur_ficha_professor FIP INNER JOIN
                     	 Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola
	WHERE     PRC.jur_prc_dt_distribuicao >= @Pdt_inicio
		AND CP.Codigo_Professor = '00000'
		AND FIC.jur_fic_fl_processo = '1'
		AND PRC.jur_prc_fl_encerrado='1'

	UNION

	SELECT DISTINCT 
                      	PRC.jur_prc_nr_pasta, 
		PRC.jur_prc_dt_distribuicao, 
		CP.Nome, CE.Razao_Social, 
		DATEDIFF(day, PRC.jur_prc_dt_distribuicao, GETDATE())  AS DIFERENCA, 
		CASE PRC.jur_prc_fl_encerrado WHEN '0' THEN 'NÃO' WHEN '1' THEN 'SIM' END AS ENCERRADO
	FROM    
		tb_jur_ficha_professor FIP INNER JOIN
                     	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                     	 tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                     	 Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola
	WHERE     PRC.jur_prc_dt_distribuicao >= @Pdt_inicio
		AND CP.Codigo_Professor <> '00000'
		AND  FIC.jur_fic_fl_processo = '0' 
		AND PRC.jur_prc_fl_encerrado='0'

	UNION 

	SELECT DISTINCT 
                     	 PRC.jur_prc_nr_pasta, 
		PRC.jur_prc_dt_distribuicao, 
		CP.Nome, 
		CE.Razao_Social, 
		DATEDIFF(day, PRC.jur_prc_dt_distribuicao, GETDATE()) 	AS DIFERENCA, 
		CASE PRC.jur_prc_fl_encerrado WHEN '0' THEN 'NÃO' WHEN '1' THEN 'SIM' END AS ENCERRADO
	FROM
  		tb_jur_ficha_professor FIP INNER JOIN
                     	 Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola
	WHERE     PRC.jur_prc_dt_distribuicao >= @Pdt_inicio
		AND CP.Codigo_Professor = '00000'
		AND FIC.jur_fic_fl_processo = '1'
		AND PRC.jur_prc_fl_encerrado='0'
END
go

