/*******************************************************************
Objeto criado: 	 sp_denuncia_imagem_sel
Descriçao:	Seleciona as Imagens da Denuncia
Data da Criaçao: 09/08/2011
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_denuncia_imagem_sel
(
@Pcd_denuncia	NVARCHAR(10)
)
AS


SELECT
	IMG.den_img_cd_imagem,
	IMG.den_img_ds_arquivo,
	IMG.den_img_ds_observacao,
	CONVERT(NVARCHAR(10), IMG.den_img_dt_cadastro,103) AS den_img_dt_cadastro,
	IMG.den_img_nm_login,
	CONVERT(NVARCHAR(8),IMG.den_img_dt_cadastro,108) AS den_img_hr_cadastro
FROM
	tb_denuncia_imagem IMG
WHERE
	IMG.den_img_cd_denuncia = @Pcd_denuncia
ORDER BY
	CONVERT(CHAR(10),IMG.den_img_dt_cadastro,111) DESC,
	CONVERT(NVARCHAR(8),IMG.den_img_dt_cadastro,108) DESC
go

