/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_email_sel
Descriçao:	Seleciona Audiencias à Serem Enviadas por E-mail
Data da Criaçao: 22/11/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_email_sel
(
@Pfl_tipo	TINYINT = 0
)
AS

IF @Pfl_tipo = 0
BEGIN
	
	SELECT
		AUD.jur_aud_cd_audiencia,
		AUD.jur_aud_nr_pasta,
		AUD.jur_aud_fl_audiencia,
		CONVERT(CHAR(10),AUD.jur_aud_dt_audiencia,103) AS Data,
		CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia,108) AS Horario,
		CASE AUD.jur_aud_fl_situacao
			WHEN 0 THEN 'DESIGNADA'
			WHEN 1 THEN 'REDESIGNADA'
			ELSE 'CANCELADA'
		END AS Tipo, 
	
		CASE FIC.jur_fic_fl_testemunha
			WHEN 0 THEN 'NÃO'
			ELSE 'SIM'
		END AS Testemunha,
	
		CP.Nome, 
		CE.Razao_Social,
		LEFT(CVA.jur_cva_ds_vara, 5) + 'VT/SP' AS Vara,
		CASE CP.Sexo
			WHEN 0 THEN 'Professor'
			ELSE 'Professora'
		END AS Tratamento,
		CASE WHEN pro_ema_ds_email1 IS NOT NULL THEN
			LEFT(CASE   WHEN pro_ema_ds_email1 <> '' THEN pro_ema_ds_email1 + ';' ELSE '' END 
		             + CASE WHEN pro_ema_ds_email2 <> '' THEN pro_ema_ds_email2 + ';' ELSE '' END
	         		+ CASE WHEN pro_ema_ds_email3 <> '' THEN pro_ema_ds_email3 + ';' ELSE '' END,
			LEN(CASE   WHEN pro_ema_ds_email1 <> '' THEN pro_ema_ds_email1 + ';' ELSE '' END
			+ CASE WHEN pro_ema_ds_email2 <> '' THEN pro_ema_ds_email2 + ';' ELSE '' END
	         		+ CASE WHEN pro_ema_ds_email3 <> '' THEN pro_ema_ds_email3 + ';' ELSE '' END) -1)
		ELSE ''
		END AS Email,
		CVA.jur_cva_ds_endereco + ', ' + CVA.jur_cva_ds_numero + ' - ' + CVA.jur_cva_ds_complemento AS End_Vara,
		FIC.jur_fic_ds_testemunha,
		AUD.jur_aud_nr_mesa
	FROM
		tb_jur_processo PRC INNER JOIN
		tb_jur_cadastro_vara CVA ON PRC.jur_prc_cd_vara = CVA.jur_cva_cd_vara INNER JOIN
		tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_pasta = FIC.jur_fic_nr_pasta INNER JOIN
		tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
		Cadastro_Professores CP ON FIP.jur_fip_cd_professor  = CP.Codigo_Professor LEFT JOIN
		tb_professor_email EMA ON CP.Codigo_Professor = EMA.pro_ema_cd_professor INNER JOIN
		Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
		tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta LEFT JOIN 
		( SELECT DISTINCT jur_fic_nr_pasta FROM tb_jur_ficha_causa FCA INNER JOIN
	              tb_jur_ficha_consulta FIC ON FIC.jur_fic_nr_ficha = FCA.jur_fca_nr_ficha  INNER JOIN
	              tb_jur_cadastro_causa CAU ON FCA.jur_fca_cd_causa = CAU.jur_cau_cd_causa
		WHERE     CAU.jur_cau_fl_testemunha = 1) AS JPC ON AUD.jur_aud_nr_pasta = JPC.jur_fic_nr_pasta
	
		WHERE     
			AUD.jur_aud_fl_email = 0 AND FIC.jur_fic_fl_processo = 0
			AND jur_aud_fl_audiencia <> 146
	
	UNION
	
	SELECT
		AUD.jur_aud_cd_audiencia,
		AUD.jur_aud_nr_pasta,
		AUD.jur_aud_fl_audiencia,
		CONVERT(CHAR(10),AUD.jur_aud_dt_audiencia,103) AS Data,
		CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia,108) AS Horario,
		CASE AUD.jur_aud_fl_situacao
			WHEN 0 THEN 'DESIGNADA'
			WHEN 1 THEN 'REDESIGNADA'
			ELSE 'CANCELADA'
		END AS Tipo, 
	
		CASE FIC.jur_fic_fl_testemunha
			WHEN 0 THEN 'NÃO'
			ELSE 'SIM'
		END AS Testemunha,
	
		CP.Nome, 
		CE.Razao_Social,
		LEFT(CVA.jur_cva_ds_vara, 5) + 'VT/SP' AS Vara,
		CASE CP.Sexo
			WHEN 0 THEN 'Professor'
			ELSE 'Professora'
		END AS Tratamento,
		'advogados@sinprosp.org.br' AS Email,
		CVA.jur_cva_ds_endereco + ', ' + CVA.jur_cva_ds_numero + ' - ' + CVA.jur_cva_ds_complemento AS End_Vara,
		FIC.jur_fic_ds_testemunha,
		AUD.jur_aud_nr_mesa
	FROM
		tb_jur_processo PRC INNER JOIN
		tb_jur_cadastro_vara CVA ON PRC.jur_prc_cd_vara = CVA.jur_cva_cd_vara INNER JOIN
		tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_pasta = FIC.jur_fic_nr_pasta INNER JOIN
		tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
		Cadastro_Professores CP ON FIP.jur_fip_cd_professor  = CP.Codigo_Professor LEFT JOIN
		tb_professor_email EMA ON CP.Codigo_Professor = EMA.pro_ema_cd_professor INNER JOIN
		Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
		tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta LEFT JOIN 
		( SELECT DISTINCT jur_fic_nr_pasta FROM tb_jur_ficha_causa FCA INNER JOIN
	              tb_jur_ficha_consulta FIC ON FIC.jur_fic_nr_ficha = FCA.jur_fca_nr_ficha  INNER JOIN
	              tb_jur_cadastro_causa CAU ON FCA.jur_fca_cd_causa = CAU.jur_cau_cd_causa
		WHERE     CAU.jur_cau_fl_testemunha = 1) AS JPC ON AUD.jur_aud_nr_pasta = JPC.jur_fic_nr_pasta
		
		WHERE     
			AUD.jur_aud_fl_email = 0 AND FIC.jur_fic_fl_processo = 1 AND FIP.jur_fip_cd_professor = '00000'
			AND jur_aud_fl_audiencia <> 146
	
	ORDER BY 
		Tipo, CP.Nome
END
ELSE IF @Pfl_tipo = 1
BEGIN
	SELECT
		CONVERT(CHAR(10), AUD.jur_aud_dt_audiencia, 103) AS jur_aud_dt_audiencia, CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia,108) AS jur_aud_hr_audiencia,
		LEFT(CVA.jur_cva_ds_vara, 5) + 'VT/SP' AS jur_cva_ds_vara, CVA.jur_cva_ds_endereco + ', ' +  CVA.jur_cva_ds_numero + ' - ' + CVA.jur_cva_ds_complemento AS Endereco,
		CP.Sexo, CP.Codigo_Professor, CP.Nome, CP.DDD_Telefone_Celular + RTRIM(CP.Telefone_Celular) AS CELULAR,
		ADV.jur_adv_fl_sexo, ADV.jur_adv_nm_advogado, AUD.jur_aud_fl_audiencia, AUD.jur_aud_nr_mesa
	FROM         tb_jur_audiencia AUD INNER JOIN
	                      tb_jur_processo PRC ON AUD.jur_aud_nr_pasta = PRC.jur_prc_nr_pasta INNER JOIN
	                      tb_jur_cadastro_vara CVA ON PRC.jur_prc_cd_vara = CVA.jur_cva_cd_vara INNER JOIN
	                      tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
	                      tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
	                      Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor INNER JOIN
	                      tb_jur_cadastro_advogado ADV ON AUD.jur_aud_cd_advogado = ADV.jur_adv_cd_advogado
	WHERE     (CONVERT(CHAR(10), AUD.jur_aud_dt_audiencia, 111) = CONVERT(CHAR(10), DATEADD(day, 1, GETDATE()), 111))
	AND AUD.jur_aud_fl_situacao <> 2
	AND jur_aud_fl_audiencia <> 146
	ORDER BY CONVERT(CHAR(10), AUD.jur_aud_dt_audiencia, 111), CP.Nome
END
go

