
/*******************************************************************
Objeto criado: 	 sp_soc_cad_escola_sel_professores
Descriçao:	Seleciona Professores da Escola
Entrada:	@pNvc_CNPJ  -> CNPJ da Escola
Saída:		
Data da Criaçao: 25/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_escola_sel_professores
(
@pNvc_CNPJ		NVARCHAR(18)
)
AS
SET NOCOUNT ON

SELECT 
	ISNULL(CP.Codigo_Professor,'') AS Codigo_Professor, 
	COALESCE(CP.Nome, PGE.Nome) AS Nome, 
	COALESCE(CP.CPF,PGE.CPF) AS CPF,
	CONVERT(CHAR(10),COALESCE(CP.Data_Inicio,'01/01/1900'),103) AS Data_Inicio,
	CASE PGE.Cobranca
		WHEN 1 THEN 'Sim'
		ELSE 'Não'
	END AS Desconto, 
	CASE PGE.Sindicalizado
		WHEN 1 THEN 'Sim'
		ELSE 'Não'
	END AS Sindicalizado 
FROM Cadastro_Professores AS CP RIGHT JOIN Professores_Geral_Escolas AS PGE
	ON CP.Codigo_Professor = PGE.Codigo_Professor
WHERE 
PGE.CGC_Escola = @pNvc_CNPJ AND 
	(
		PGE.Situacao IN (1,2,4,5,6,7,8)) AND 
	status_web <> '4' 

/*PGE.CGC_Escola = @pNvc_CNPJ AND 
	((CP.Situacao IN (1,2,5,9,10) OR
		CP.Situacao IS NULL)AND
		PGE.Situacao IN (1,2,4,5,6,7,8)) AND 
	status_web <> '4' 
*/
ORDER BY Nome
go

