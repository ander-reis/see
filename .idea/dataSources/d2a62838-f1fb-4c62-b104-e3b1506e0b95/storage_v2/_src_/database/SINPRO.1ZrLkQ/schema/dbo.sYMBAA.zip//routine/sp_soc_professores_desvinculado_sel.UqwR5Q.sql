/*******************************************************************
Objeto criado: 	 sp_soc_professores_desvinculado_sel
Descriçao:	Seleciona E-mail dos Professores Desvinculados no Periodo
Data da Criaçao: 05/03/2008
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_professores_desvinculado_sel
(
@Pdt_de	DATETIME,
@Pdt_ate	DATETIME
)
AS

SELECT
	CP.Nome, 
	CASE CP.Sexo 
		WHEN 1 THEN 'PREZADA PROFESSORA' 
		ELSE 'PREZADO PROFESSOR' 
	END AS Tratamento, 
	
	LEFT(CASE   WHEN ISNULL(pro_ema_ds_email1,'') <> '' THEN ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END 
	+ CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
	+ CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END,
	LEN(CASE   WHEN  ISNULL(pro_ema_ds_email1,'') <> '' THEN  ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END
	+ CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
	+ CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END) -1) AS Email,
	CP.Sexo
FROM
	 Cadastro_Professores CP
	INNER JOIN tb_professor_email EMA ON CP.Codigo_Professor = EMA.pro_ema_cd_professor
WHERE
	CONVERT(CHAR(10),CP.Data_Situacao,111) BETWEEN @Pdt_de AND @Pdt_ate
	AND Situacao = 6
ORDER BY
	CP.Codigo_Professor
go

