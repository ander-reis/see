/*******************************************************************
Objeto criado: 	 sp_escola_imagem_ins
Descriçao:	Cadastra as Imagens do Cadatro da Escola
Data da Criaçao: 30/01/2014
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_escola_imagem_ins
(
@Pcd_imagem		INT,
@Pcd_escola		NVARCHAR(18),
@Pds_arquivo		NVARCHAR(300),
@Pds_observacao	NVARCHAR(600),
@Pdt_cadastro		DATETIME,
@Pnm_login		NVARCHAR(30)
)

AS

IF @Pcd_imagem = 0  
	INSERT INTO tb_escola_imagem
		(esc_img_cd_escola,
		esc_img_ds_arquivo,
		esc_img_ds_observacao,
		esc_img_dt_cadastro,
		esc_img_nm_login)
	VALUES
		(@Pcd_escola,
		@Pds_arquivo,
		@Pds_observacao,
		@Pdt_cadastro,
		@Pnm_login)
ELSE
	UPDATE tb_escola_imagem SET
		esc_img_ds_arquivo	= @Pds_arquivo,
		esc_img_ds_observacao	= @Pds_observacao,
		esc_img_dt_cadastro	= @Pdt_cadastro, 
		esc_img_nm_login	= @Pnm_login
	WHERE
		esc_img_cd_imagem = @Pcd_imagem
go

