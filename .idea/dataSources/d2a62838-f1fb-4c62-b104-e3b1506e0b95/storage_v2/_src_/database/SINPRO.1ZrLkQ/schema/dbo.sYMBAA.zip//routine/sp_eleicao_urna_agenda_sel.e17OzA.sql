

/*******************************************************************
Objeto criado: 	 sp_eleicao_urna_agenda_sel
Descriçao:	Seleciona Escola
Data da Criaçao: 20/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_urna_agenda_sel
(
@Pnr_urna	INT
)
AS

IF @Pnr_urna <> 0 
	SELECT     CE.CGC_Escola, 
		CE.Razao_Social, 
		CE.Nome_Fantasia, 
		CE.Endereco + ', ' + CE.Numero AS Endereco, 
		CE.Bairro, CE.CEP, 
		CE.Telefone1, 
		CE.Telefone2, 
           		      
		CASE CE.contato_eleicao 
			WHEN '' THEN CE.Contato 
			ELSE CE.contato_eleicao 
		END AS Contato, 

		CE.Urna, 
		CP.Codigo_Professor, 
		CP.Nome
FROM         Cadastro_Professores CP INNER JOIN
                      Professores_Geral_Escolas PGE ON CP.Codigo_Professor = PGE.Codigo_Professor INNER JOIN
                      Cadastro_Escolas CE ON PGE.CGC_Escola = CE.CGC_Escola
WHERE     		 CP.Situacao IN (1, 5, 9, 2, 10,12,13)
			AND PGE.CGC_Escola <> '00.000.000/0000-00'
			AND CE.Categoria IN (1, 6)
			AND CE.Situacao IN (0, 1)
			AND CE.Urna =@Pnr_urna
			AND CP.Codigo_Professor NOT IN
(	

SELECT	CP.Codigo_Professor
		

		FROM         Cadastro_Escolas CE INNER JOIN
             			         Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
             			         Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
	
		WHERE     CP.Data_Inicio <= DATEADD(month, - 6, DATEADD(day, - 1, '10/24/2018'))
			AND CP.Situacao IN (1, 5, 9, 2, 10,12,13)
			AND PGE.CGC_Escola <> '00.000.000/0000-00'
			AND CE.Categoria IN (1, 6)
			AND CE.Situacao IN (0, 1)
			AND CE.Urna =@Pnr_urna
			AND CP.Votou = 0

)
ORDER BY CE.Urna, CE.CEP , CE.CGC_Escola, CP.Nome

ELSE
	SELECT     CE.CGC_Escola, 
		CE.Razao_Social, 
		CE.Nome_Fantasia, 
		CE.Endereco + ', ' + CE.Numero AS Endereco, 
		CE.Bairro, CE.CEP, 
		CE.Telefone1, 
		CE.Telefone2, 
           		      
		CASE CE.contato_eleicao 
			WHEN '' THEN CE.Contato 
			ELSE CE.contato_eleicao 
		END AS Contato, 
		CE.Urna, 
		CP.Codigo_Professor, 
		CP.Nome
FROM         Cadastro_Professores CP INNER JOIN
                      Professores_Geral_Escolas PGE ON CP.Codigo_Professor = PGE.Codigo_Professor INNER JOIN
                      Cadastro_Escolas CE ON PGE.CGC_Escola = CE.CGC_Escola
WHERE     		 CP.Situacao IN (1, 5, 9, 2, 10,12,13)
			AND PGE.CGC_Escola <> '00.000.000/0000-00'
			AND CE.Categoria IN (1, 6)
			AND CE.Situacao IN (0, 1)
			AND CE.Urna NOT IN (0,1)
			AND CP.Codigo_Professor NOT IN
(	

SELECT	CP.Codigo_Professor
		

		FROM         Cadastro_Escolas CE INNER JOIN
             			         Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
             			         Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
	
		WHERE     CP.Data_Inicio <= DATEADD(month, - 6, DATEADD(day, - 1, '10/24/2018'))
			AND CP.Situacao IN (1, 5, 9, 2, 10,12,13)
			AND PGE.CGC_Escola <> '00.000.000/0000-00'
			AND CE.Categoria IN (1, 6)
			AND CE.Situacao IN (0, 1)
			AND CE.Urna NOT IN (0,1)
			AND CP.Votou = 0
			
)
ORDER BY CE.Urna, CE.CEP , CE.CGC_Escola, CP.Nome
go

