/*******************************************************************
Objeto criado: 	 sp_email_sas_upd
Descriçao:	Atualiza o Agendamento de Envio de E-mail pelo SAS
Data da Criaçao: 22/06/2015
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_email_sas_upd
(
@Pcd_email		BIGINT
)

AS
UPDATE tb_email_sas
SET ema_sas_dt_envio = GETDATE()
WHERE ema_sas_cd_email = @Pcd_email
go

