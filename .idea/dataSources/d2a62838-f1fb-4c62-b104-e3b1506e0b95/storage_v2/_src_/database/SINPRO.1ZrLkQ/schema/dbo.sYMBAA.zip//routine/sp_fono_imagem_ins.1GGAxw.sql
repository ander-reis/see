/*******************************************************************
Objeto criado: 	 sp_fono_imagem_ins
Descriçao:	Cadastra as Imagens do Cadatro Fono
Data da Criaçao: 03/05/2013
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_fono_imagem_ins
(
@Pcd_imagem		INT,
@Pcd_cod_prof_geral 	NVARCHAR(6),
@Pds_arquivo		NVARCHAR(300),
@Pds_observacao	NVARCHAR(600),
@Pdt_cadastro		DATETIME,
@Pnm_login		NVARCHAR(30)
)

AS

IF @Pcd_imagem = 0  
	INSERT INTO tb_fono_cad_imagem
		( fono_img_cd_cod_prof_geral, 
		 fono_img_ds_arquivo, 
		 fono_img_ds_observacao, 
		 fono_img_dt_data, 
		 fono_img_ds_login)
	VALUES
		(@Pcd_cod_prof_geral ,
		@Pds_arquivo,
		@Pds_observacao,
		@Pdt_cadastro,
		@Pnm_login)
ELSE
	UPDATE tb_fono_cad_imagem SET
		fono_img_ds_arquivo	= @Pds_arquivo,
		fono_img_ds_observacao = @Pds_observacao,
		fono_img_dt_data	= @Pdt_cadastro, 
		fono_img_ds_login	= @Pnm_login
	WHERE
		fono_img_cd_imagem = @Pcd_imagem
go

