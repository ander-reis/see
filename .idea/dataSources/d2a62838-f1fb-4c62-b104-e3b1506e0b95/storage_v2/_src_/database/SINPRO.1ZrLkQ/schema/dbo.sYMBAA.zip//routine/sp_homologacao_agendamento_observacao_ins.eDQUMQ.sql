/*******************************************************************
Objeto criado: 	 sp_homologacao_agendamento_observacao_ins
Descriçao:	Cadastra Observação para Agendamento de Homologacao
Data da Criaçao: 17/07/2012
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_homologacao_agendamento_observacao_ins
(
@Pdt_agendamento	DATETIME,
@Pdt_horario		NVARCHAR(5),
@Pcd_cnpj		NVARCHAR(18),
@Pds_observacao	NVARCHAR(200),
@Pnm_login		NVARCHAR(30)
)

AS

INSERT INTO Hom_Agendamento_Observacao
	(ago_dt_agendamento, ago_dt_horario, ago_cd_cnpj, ago_ds_obs, ago_ds_cadastrado_por, ago_dt_cadastro) 
	VALUES (@Pdt_agendamento, @Pdt_horario,@Pcd_cnpj, @Pds_observacao, @Pnm_login, GETDATE())
go

