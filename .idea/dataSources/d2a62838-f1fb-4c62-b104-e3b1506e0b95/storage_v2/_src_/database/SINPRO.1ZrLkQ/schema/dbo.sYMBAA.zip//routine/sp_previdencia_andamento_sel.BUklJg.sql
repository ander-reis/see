

/*******************************************************************
Objeto criado: 	 sp_previdencia_andamento_sel
Descriçao:	Seleciona o Andamento de Aposentadoria
Data da Criaçao: 11/09/2007
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_previdencia_andamento_sel
(
@Pfl_andamento	INT,
@Pfl_situacao		INT,
@Pdt_inicio	DATETIME,
@Pdt_fim	DATETIME
)
AS

	IF  @Pfl_situacao=0 --Com Entrada--
		BEGIN
		SELECT     
			PRA.prev_pra_cd_previdencia, 
			PRA.prev_pra_nr_beneficio,
			SCPG.Codigo_Professor, 
			SCPG.Nome, 
			SCPG.Data_Aniversario,
			SCPG. CPF,
			PRA.prev_pra_dt_entrada,
			PRA.prev_pra_dt_concessao,  	
			CASE PRA.prev_pra_fl_situacao 
				WHEN '0' THEN 'Ativo' 
				WHEN '1' THEN 'Cancelado' 
				WHEN '2' THEN 'Finalizado' 
			END AS SITUACAO, 
			CASE PRA.prev_pra_fl_andamento
				WHEN '0' THEN 'Pab'
				WHEN '1' THEN 'Indeferido'
				WHEN '2' THEN 'Concedido'
				WHEN '3' THEN 'Exigência/Pesquisa'
				WHEN '4' THEN 'Andamento'
				WHEN '5' THEN 'Recurso'
				WHEN '6' THEN 'Revisão-Brás'
				WHEN '7' THEN 'Dupl. Ativ.'
				WHEN '8' THEN 'Cancelado'
				WHEN '9' THEN 'Consulta'
				WHEN '10' THEN 'Revisão-Xavier'
			END AS ANDAMENTO,
			PRA.prev_pra_cd_tipoespecie, 
			PAE.prev_pae_ds_especie
		FROM         
			tb_prev_atendimento PRA INNER JOIN    Soc_Cadastro_Professor_Geral SCPG ON PRA.prev_pra_cd_codprofgeral = SCPG.CodProf_Geral INNER JOIN     tb_prev_atendimento_tipoespecie PAE ON PRA.prev_pra_cd_tipoespecie = PAE.prev_pae_cd_tipoespecie
		WHERE     
			(PRA.prev_pra_dt_entrada BETWEEN @Pdt_inicio AND @Pdt_fim) 
			AND PRA.prev_pra_fl_situacao NOT IN (1) 

			AND (PRA.prev_pra_fl_andamento = @Pfl_andamento)
			AND PRA.prev_pra_dt_entrada <>'01/01/1900'
			AND SCPG.Nome <> ''
		ORDER BY 
			SCPG.Nome
		END
	ELSE IF @Pfl_situacao=1 --Sem Entrada--
		BEGIN
		SELECT     
			PRA.prev_pra_cd_previdencia, 
			PRA.prev_pra_nr_beneficio,
			SCPG.Codigo_Professor, 
			SCPG.Nome, 
			SCPG.Data_Aniversario,
			SCPG. CPF,
			PRA.prev_pra_dt_entrada, 
			PRA.prev_pra_dt_concessao,  
			CASE PRA.prev_pra_fl_situacao 
				WHEN '0' THEN 'Ativo' 
				WHEN '1' THEN 'Cancelado' 
				WHEN '2' THEN 'Finalizado' 
			END AS SITUACAO, 
				CASE PRA.prev_pra_fl_andamento
				WHEN '0' THEN 'Pab'
				WHEN '1' THEN 'Indeferido'
				WHEN '2' THEN 'Concedido'
				WHEN '3' THEN 'Exigência/Pesquisa'
				WHEN '4' THEN 'Andamento'
				WHEN '5' THEN 'Recurso'
				WHEN '6' THEN 'Revisão-Brás'
				WHEN '7' THEN 'Dupl. Ativ.'
				WHEN '8' THEN 'Cancelado'
				WHEN '9' THEN 'Consulta'
				WHEN '10' THEN 'Revisão-Xavier'
			END AS ANDAMENTO,
			PRA.prev_pra_cd_tipoespecie, 
			PAE.prev_pae_ds_especie
		FROM         
			tb_prev_atendimento PRA INNER JOIN    Soc_Cadastro_Professor_Geral SCPG ON PRA.prev_pra_cd_codprofgeral = SCPG.CodProf_Geral INNER JOIN     tb_prev_atendimento_tipoespecie PAE ON PRA.prev_pra_cd_tipoespecie = PAE.prev_pae_cd_tipoespecie
		WHERE     
			(PRA.prev_pra_dt_cadastro BETWEEN @Pdt_inicio AND @Pdt_fim) 
			AND PRA.prev_pra_fl_situacao NOT IN (1) 
			AND (PRA.prev_pra_fl_andamento = @Pfl_andamento) 
			AND PRA.prev_pra_dt_entrada='01/01/1900'
			AND SCPG.Nome <> ''
		ORDER BY 
			SCPG.Nome
		END
	ELSE IF @Pfl_situacao=2 --Todas-
		BEGIN
		SELECT     
			PRA.prev_pra_cd_previdencia, 
			PRA.prev_pra_nr_beneficio,
			SCPG.Codigo_Professor, 
			SCPG.Nome, 
			SCPG.Data_Aniversario,
			SCPG. CPF,
			PRA.prev_pra_dt_entrada, 
			PRA.prev_pra_dt_concessao,  
		CASE PRA.prev_pra_fl_situacao 
			WHEN '0' THEN 'Ativo' 
			WHEN '1' THEN 'Cancelado' 
			WHEN '2' THEN 'Finalizado' 
		END AS SITUACAO, 
				CASE PRA.prev_pra_fl_andamento
				WHEN '0' THEN 'Pab'
				WHEN '1' THEN 'Indeferido'
				WHEN '2' THEN 'Concedido'
				WHEN '3' THEN 'Exigência/Pesquisa'
				WHEN '4' THEN 'Andamento'
				WHEN '5' THEN 'Recurso'
				WHEN '6' THEN 'Revisão-Brás'
				WHEN '7' THEN 'Dupl. Ativ.'
				WHEN '8' THEN 'Cancelado'
				WHEN '9' THEN 'Consulta'
				WHEN '10' THEN 'Revisão-Xavier'
		END AS ANDAMENTO,
		PRA.prev_pra_cd_tipoespecie, 
		PAE.prev_pae_ds_especie
		FROM         
			tb_prev_atendimento PRA INNER JOIN    Soc_Cadastro_Professor_Geral SCPG ON PRA.prev_pra_cd_codprofgeral = SCPG.CodProf_Geral INNER JOIN     tb_prev_atendimento_tipoespecie PAE ON PRA.prev_pra_cd_tipoespecie = PAE.prev_pae_cd_tipoespecie
		WHERE     
			(PRA.prev_pra_dt_cadastro BETWEEN @Pdt_inicio AND @Pdt_fim) 
			AND PRA.prev_pra_fl_situacao NOT IN (1) 
			AND (PRA.prev_pra_fl_andamento = @Pfl_andamento) 
			AND SCPG.Nome <> ''
		ORDER BY 
			SCPG.Nome
		END
go

