/*******************************************************************
Objeto criado: 	 sp_posgraduacao_presenca_sel
Descriçao:	Seleciona Presenca dos Alunos
Data da Criaçao: 02/08/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_posgraduacao_presenca_sel
(
@Pcd_cpf		NVARCHAR(18),
@pcd_cd_curso		REAL
)
AS

SELECT DISTINCT PD.pos_cad_cd_disciplina, DAT.pos_dat_cd_curso, PD.pos_cad_ds_disciplina, CASE PDA.pos_dia_fl_tranferido WHEN '0' THEN 'NÃO' WHEN '1' THEN 'SIM' END AS TRANSFERIDO ,POSA.pos_alu_ds_cpf, POSA.pos_alu_ds_nome, DIAS_CURSO.TOTAL AS DIAS_CURSO,
RIGHT('0' + CONVERT(NVARCHAR(3),DATEDIFF(HH,'1900-01-01 00:00:00',DATEADD(HH,CONVERT(INT,SUM((CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_fim)))+(CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_fim))/ 60)) - SUM((CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_inicio)))+(CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_inicio))/ 60))),DATEADD(mi,CONVERT(INT,ROUND(((SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_fim)) / 60)) - SUM( CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_inicio)) / 60))) - CONVERT(INT,(SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_fim)) / 60)) - SUM( CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_inicio)) / 60))))) * 60,0)),'01/01/1900 00:00:00')))),2)
+ ':' +
RIGHT('0' + CONVERT(NVARCHAR(3),DATEPART(MI,DATEADD(MI,CONVERT(INT,ROUND(((SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_fim)) / 60)) - SUM( CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_inicio)) / 60))) - CONVERT(INT,(SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_fim)) / 60)) - SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_inicio)) / 60))))) * 60,0)),'01/01/1900 00:00:00'))),2) AS CARGA_HORARIA,

PERIODO_CURSO.TOTAL AS PERIODO_CURSO,

ISNULL(PRESENCA_ALUNO.PRESENCA_ALUNO,'00:00') AS PRESENCA_ALUNO,

ISNULL(PERIODO_ALUNO.TOTAL,0) AS PERIODO_ALUNO

FROM	tb_pos_disciplina PD
	INNER JOIN tb_pos_disciplina_data DAT ON PD.pos_cad_cd_disciplina = DAT.pos_dat_cd_disciplina
	INNER JOIN tb_pos_disciplina_aluno PDA ON PD.pos_cad_cd_disciplina = PDA.pos_dia_cd_disciplina
	INNER JOIN tb_pos_agendamento PA ON PDA.pos_dia_cd_pos = PA.pos_agt_cd_pos
	INNER JOIN  tb_pos_aluno POSA ON PA.pos_agt_ds_cpf = POSA.pos_alu_ds_cpf
	INNER JOIN (SELECT pos_dat_cd_disciplina, pos_dat_cd_curso, COUNT(DISTINCT pos_dat_dt_data) AS TOTAL FROM tb_pos_disciplina_data  WHERE pos_dat_cd_curso=@pcd_cd_curso GROUP BY pos_dat_cd_disciplina, pos_dat_cd_curso) AS DIAS_CURSO ON DAT.pos_dat_cd_disciplina = DIAS_CURSO.pos_dat_cd_disciplina AND DAT.pos_dat_cd_curso = DIAS_CURSO.pos_dat_cd_curso
	INNER JOIN (SELECT DAT.pos_dat_cd_disciplina, DAT.pos_dat_cd_curso, COUNT(DAT.pos_dat_cd_curso) AS TOTAL FROM tb_pos_disciplina_data DAT WHERE DAT.pos_dat_cd_curso=@pcd_cd_curso GROUP BY DAT.pos_dat_cd_disciplina, DAT.pos_dat_cd_curso) AS PERIODO_CURSO ON  DAT.pos_dat_cd_disciplina = PERIODO_CURSO.pos_dat_cd_disciplina AND DAT.pos_dat_cd_curso = PERIODO_CURSO.pos_dat_cd_curso
	LEFT   JOIN (SELECT PPA.pos_pre_cd_disciplina, PPA.pos_pre_cd_curso, COUNT(PPA.pos_pre_dt_data) AS TOTAL, PA.pos_agt_ds_cpf FROM tb_pos_presenca_aluno PPA INNER JOIN tb_pos_agendamento PA ON PPA.pos_pre_cd_pos = PA.pos_agt_cd_pos WHERE PPA.pos_pre_cd_curso='1' AND PPA.pos_pre_ds_presenca = 'SIM' AND PA.pos_agt_ds_cpf = @Pcd_cpf GROUP BY PPA.pos_pre_cd_disciplina, PPA.pos_pre_cd_curso, PA.pos_agt_ds_cpf) AS PERIODO_ALUNO ON  DAT.pos_dat_cd_disciplina = PERIODO_ALUNO.pos_pre_cd_disciplina AND DAT.pos_dat_cd_curso = PERIODO_ALUNO.pos_pre_cd_curso AND POSA.pos_alu_ds_cpf = PERIODO_ALUNO.pos_agt_ds_cpf
	LEFT   JOIN (SELECT    PPA.pos_pre_cd_disciplina, PPA.pos_pre_cd_curso, PPA.pos_pre_dt_impressao, PA.pos_agt_ds_cpf, 
				RIGHT('0' + CONVERT(NVARCHAR(3),DATEDIFF(HH,'1900-01-01 00:00:00',DATEADD(HH,CONVERT(INT,SUM((CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_fim)))+(CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_fim))/ 60)) - SUM((CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_inicio)))+(CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_inicio))/ 60))),DATEADD(mi,CONVERT(INT,ROUND(((SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_fim)) / 60)) - SUM( CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_inicio)) / 60))) - CONVERT(INT,(SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_fim)) / 60)) - SUM( CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_inicio)) / 60))))) * 60,0)),'01/01/1900 00:00:00')))),2)
				+ ':' +
				RIGHT('0' + CONVERT(NVARCHAR(3),DATEPART(MI,DATEADD(MI,CONVERT(INT,ROUND(((SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_fim)) / 60)) - SUM( CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_inicio)) / 60))) - CONVERT(INT,(SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_fim)) / 60)) - SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_inicio)) / 60))))) * 60,0)),'01/01/1900 00:00:00'))),2) AS PRESENCA_ALUNO
			FROM         tb_pos_presenca_aluno PPA
				INNER JOIN tb_pos_agendamento PA ON PPA.pos_pre_cd_pos = PA.pos_agt_cd_pos
			WHERE PPA.pos_pre_ds_presenca = 'SIM' AND PA.pos_agt_ds_cpf =@Pcd_cpf  AND PPA.pos_pre_cd_curso=@pcd_cd_curso
			GROUP BY PPA.pos_pre_cd_disciplina, PPA.pos_pre_cd_curso,PPA.pos_pre_dt_impressao, PA.pos_agt_ds_cpf) AS PRESENCA_ALUNO ON DAT.pos_dat_cd_disciplina = PRESENCA_ALUNO.pos_pre_cd_disciplina AND DAT.pos_dat_cd_curso = PRESENCA_ALUNO.pos_pre_cd_curso AND POSA.pos_alu_ds_cpf = PRESENCA_ALUNO.pos_agt_ds_cpf
WHERE     (PA.pos_agt_fl_situacao = 0) AND POSA.pos_alu_ds_cpf =@Pcd_cpf  AND DAT.pos_dat_cd_curso=@pcd_cd_curso
GROUP BY PD.pos_cad_ds_disciplina, DAT.pos_dat_cd_curso, POSA.pos_alu_ds_cpf, POSA.pos_alu_ds_nome, PD.pos_cad_cd_disciplina, DIAS_CURSO.TOTAL, PRESENCA_ALUNO.PRESENCA_ALUNO, PERIODO_CURSO.TOTAL, PERIODO_ALUNO.TOTAL,PDA.pos_dia_fl_tranferido
ORDER BY POSA.pos_alu_ds_nome, PD.pos_cad_ds_disciplina


/*

SELECT DISTINCT PD.pos_cad_cd_disciplina, DAT.pos_dat_cd_curso, PD.pos_cad_ds_disciplina, SCPG.CodProf_Geral, SCPG.Nome, DIAS_CURSO.TOTAL AS DIAS_CURSO,
RIGHT('0' + CONVERT(NVARCHAR(3),DATEDIFF(HH,'1900-01-01 00:00:00',DATEADD(HH,CONVERT(INT,SUM((CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_fim)))+(CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_fim))/ 60)) - SUM((CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_inicio)))+(CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_inicio))/ 60))),DATEADD(mi,CONVERT(INT,ROUND(((SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_fim)) / 60)) - SUM( CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_inicio)) / 60))) - CONVERT(INT,(SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_fim)) / 60)) - SUM( CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_inicio)) / 60))))) * 60,0)),'01/01/1900 00:00:00')))),2)
+ ':' +
RIGHT('0' + CONVERT(NVARCHAR(3),DATEPART(MI,DATEADD(MI,CONVERT(INT,ROUND(((SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_fim)) / 60)) - SUM( CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_inicio)) / 60))) - CONVERT(INT,(SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_fim)) / 60)) - SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,DAT.pos_dat_hr_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,DAT.pos_dat_hr_inicio)) / 60))))) * 60,0)),'01/01/1900 00:00:00'))),2) AS CARGA_HORARIA,

PERIODO_CURSO.TOTAL AS PERIODO_CURSO,

ISNULL(PRESENCA_ALUNO.PRESENCA_ALUNO,'00:00') AS PRESENCA_ALUNO,

ISNULL(PERIODO_ALUNO.TOTAL,0) AS PERIODO_ALUNO

FROM	tb_pos_disciplina PD
	INNER JOIN tb_pos_disciplina_data DAT ON PD.pos_cad_cd_disciplina = DAT.pos_dat_cd_disciplina
	INNER JOIN tb_pos_disciplina_aluno PDA ON PD.pos_cad_cd_disciplina = PDA.pos_dia_cd_disciplina
	INNER JOIN tb_pos_agendamento PA ON PDA.pos_dia_cd_pos = PA.pos_agt_cd_pos
	INNER JOIN Soc_Cadastro_Professor_Geral SCPG ON PA.pos_agt_cd_prof_geral = SCPG.CodProf_Geral
	INNER JOIN (SELECT pos_dat_cd_disciplina, pos_dat_cd_curso, COUNT(DISTINCT pos_dat_dt_data) AS TOTAL FROM tb_pos_disciplina_data WHERE CONVERT(NVARCHAR(10),pos_dat_dt_data,111) >= @Pdt_inicio AND CONVERT(NVARCHAR(10),pos_dat_dt_data,111) <= @Pdt_fim GROUP BY pos_dat_cd_disciplina, pos_dat_cd_curso) AS DIAS_CURSO ON DAT.pos_dat_cd_disciplina = DIAS_CURSO.pos_dat_cd_disciplina AND DAT.pos_dat_cd_curso = DIAS_CURSO.pos_dat_cd_curso
	INNER JOIN (SELECT DAT.pos_dat_cd_disciplina, DAT.pos_dat_cd_curso, COUNT(DAT.pos_dat_cd_curso) AS TOTAL FROM tb_pos_disciplina_data DAT GROUP BY DAT.pos_dat_cd_disciplina, DAT.pos_dat_cd_curso) AS PERIODO_CURSO ON  DAT.pos_dat_cd_disciplina = PERIODO_CURSO.pos_dat_cd_disciplina AND DAT.pos_dat_cd_curso = PERIODO_CURSO.pos_dat_cd_curso
	LEFT   JOIN (SELECT PPA.pos_pre_cd_disciplina, PPA.pos_pre_cd_curso, COUNT(PPA.pos_pre_dt_data) AS TOTAL, PA.pos_agt_cd_prof_geral FROM tb_pos_presenca_aluno PPA INNER JOIN tb_pos_agendamento PA ON PPA.pos_pre_cd_pos = PA.pos_agt_cd_pos WHERE PPA.pos_pre_ds_presenca = 'SIM' AND CONVERT(NVARCHAR(10),pos_pre_dt_data,111) >= @Pdt_inicio AND CONVERT(NVARCHAR(10),pos_pre_dt_data,111) <= @Pdt_fim AND PA.pos_agt_cd_prof_geral = @Pcd_prof_geral GROUP BY PPA.pos_pre_cd_disciplina, PPA.pos_pre_cd_curso, PA.pos_agt_cd_prof_geral) AS PERIODO_ALUNO ON  DAT.pos_dat_cd_disciplina = PERIODO_ALUNO.pos_pre_cd_disciplina AND DAT.pos_dat_cd_curso = PERIODO_ALUNO.pos_pre_cd_curso AND SCPG.CodProf_Geral = PERIODO_ALUNO.pos_agt_cd_prof_geral
	LEFT   JOIN (SELECT    PPA.pos_pre_cd_disciplina, PPA.pos_pre_cd_curso, PPA.pos_pre_dt_impressao, PA.pos_agt_cd_prof_geral, 
				RIGHT('0' + CONVERT(NVARCHAR(3),DATEDIFF(HH,'1900-01-01 00:00:00',DATEADD(HH,CONVERT(INT,SUM((CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_fim)))+(CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_fim))/ 60)) - SUM((CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_inicio)))+(CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_inicio))/ 60))),DATEADD(mi,CONVERT(INT,ROUND(((SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_fim)) / 60)) - SUM( CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_inicio)) / 60))) - CONVERT(INT,(SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_fim)) / 60)) - SUM( CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_inicio)) / 60))))) * 60,0)),'01/01/1900 00:00:00')))),2)
				+ ':' +
				RIGHT('0' + CONVERT(NVARCHAR(3),DATEPART(MI,DATEADD(MI,CONVERT(INT,ROUND(((SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_fim)) / 60)) - SUM( CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_inicio)) / 60))) - CONVERT(INT,(SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_fim)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_fim)) / 60)) - SUM(CONVERT(DECIMAL(10,2),DATEPART(hh,PPA.pos_pre_dt_hor_inicio)) + (CONVERT(DECIMAL(10,2),DATEPART(mi,PPA.pos_pre_dt_hor_inicio)) / 60))))) * 60,0)),'01/01/1900 00:00:00'))),2) AS PRESENCA_ALUNO
			FROM         tb_pos_presenca_aluno PPA
				INNER JOIN tb_pos_agendamento PA ON PPA.pos_pre_cd_pos = PA.pos_agt_cd_pos
			WHERE PPA.pos_pre_ds_presenca = 'SIM' AND CONVERT(NVARCHAR(10),pos_pre_dt_data,111) >= @Pdt_inicio AND CONVERT(NVARCHAR(10),pos_pre_dt_data,111) <= @Pdt_fim AND PA.pos_agt_cd_prof_geral = @Pcd_prof_geral
			GROUP BY PPA.pos_pre_cd_disciplina, PPA.pos_pre_cd_curso,PPA.pos_pre_dt_impressao, PA.pos_agt_cd_prof_geral) AS PRESENCA_ALUNO ON DAT.pos_dat_cd_disciplina = PRESENCA_ALUNO.pos_pre_cd_disciplina AND DAT.pos_dat_cd_curso = PRESENCA_ALUNO.pos_pre_cd_curso AND SCPG.CodProf_Geral = PRESENCA_ALUNO.pos_agt_cd_prof_geral
WHERE     (PA.pos_agt_fl_situacao = 0) AND CONVERT(NVARCHAR(10),pos_dat_dt_data,111) >= @Pdt_inicio AND CONVERT(NVARCHAR(10),pos_dat_dt_data,111) <= @Pdt_fim AND SCPG.CodProf_Geral = @Pcd_prof_geral
GROUP BY PD.pos_cad_ds_disciplina, DAT.pos_dat_cd_curso, SCPG.CodProf_Geral, SCPG.Nome, PD.pos_cad_cd_disciplina, DIAS_CURSO.TOTAL, PRESENCA_ALUNO.PRESENCA_ALUNO, PERIODO_CURSO.TOTAL, PERIODO_ALUNO.TOTAL
ORDER BY SCPG.Nome, PD.pos_cad_ds_disciplina
*/
go

