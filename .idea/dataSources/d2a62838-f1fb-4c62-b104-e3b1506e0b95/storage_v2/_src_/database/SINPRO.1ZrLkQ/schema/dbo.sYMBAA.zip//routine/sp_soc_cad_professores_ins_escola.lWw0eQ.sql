
/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_ins_escola
Descriçao:	Inclui Escolas do Professor
Entrada:	@pNvc_professor  -> CPF do Professor
Saída:		
Data da Criaçao: 14/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_ins_escola
(
@pNvc_CPF				NVARCHAR(14),
@pNvc_CNPJ				NVARCHAR(18),
@pNvc_nome				NVARCHAR(50),
@pNvc_nr_registro			NVARCHAR(50),
@pNvc_professor			NVARCHAR(5),
@pDec_salario				DECIMAL(10,2),
@pBit_sindicalizado			BIT,
@pInt_situacao				INT,
@pDt_situacao				DATETIME,
@pBit_cobranca			BIT,
@pSma_pre				SMALLINT,
@pSma_1_4serie			SMALLINT,
@pSma_5_8serie			SMALLINT,
@pSma_medio				SMALLINT,
@pSma_superior			SMALLINT,
@pSma_tecnico				SMALLINT,
@pSma_supletivo			SMALLINT,
@pSma_curso_livre			SMALLINT,
@pDt_cadastro				DATETIME,
@pDt_cobranca				DATETIME,
@pDt_inicio				DATETIME,
@pDt_admissao				DATETIME
)
AS

INSERT INTO Professores_Geral_Escolas (
	CPF,
	CGC_Escola,
	Nome,
	Numero_Registro,
	Codigo_Professor,
	Salario,
	Sindicalizado,
	Situacao,
	Data_Situacao,
	Cobranca,
	Pre,
	[1_4Serie],
	[5_8Serie],
	Ens_Medio,
	Ens_Superior,
	Tecnico,
	Supletivo,
	Curso_Livre,
	Data_Cadastro,
	Ok,
	Status,
	Data_Cobranca,
	status_web,
	Data_Inicio,
	Data_Admissao
	) 
VALUES (
	@pNvc_CPF,
	@pNvc_CNPJ,
	@pNvc_nome,
	@pNvc_nr_registro,
	@pNvc_professor,
	@pDec_salario,
	@pBit_sindicalizado,
	@pInt_situacao,
	CONVERT(DATETIME,@pDt_situacao,101),
	@pBit_cobranca,
	@pSma_pre,
	@pSma_1_4serie,
	@pSma_5_8serie,
	@pSma_medio,
	@pSma_superior,
	@pSma_tecnico,
	@pSma_supletivo,
	@pSma_curso_livre,
	CONVERT(DATETIME,@pDt_cadastro,101),
	'',
	'',
	CONVERT(DATETIME,@pDt_cobranca,101),
	'',
	CONVERT(DATETIME,@pDt_inicio,101),
	CONVERT(DATETIME,@pDt_admissao,101)
	)


go

