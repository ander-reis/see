


/*******************************************************************
Objeto criado: 	 sp_eleicao_func_upd
Descriçao:	Alterar no Cadastro de Funcionário - Eleição
Data da Criaçao: 09/06/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_func_upd
(
@Pcd_funcionario		NVARCHAR(5),
@Pnm_funcionario		VARCHAR(100),
@Pfl_sexo			TINYINT,
@Pdt_nascimento		DATETIME,
@Pds_cpf			NVARCHAR(14),
@Pds_rg			NVARCHAR(12),
@Pnm_mae			VARCHAR(100),
@Pnm_pai			VARCHAR(100),
@Pnm_indicacao		VARCHAR(100),
@Pdt_modificacao		DATETIME,
@Pds_cep			NVARCHAR(9),
@Pds_endereco		NVARCHAR(63),
@Pds_numero			NVARCHAR(6),
@Pds_complemento		NVARCHAR(50),
@Pds_bairro			NVARCHAR(59),
@Pds_cidade			NVARCHAR(21),
@Pds_uf			NVARCHAR(2),
@Pnr_ddd_residencial		NVARCHAR(2),
@Pnr_fone_residencial		NVARCHAR(9),
@Pnr_ddd_celular		NVARCHAR(2),
@Pnr_celular			NVARCHAR(10),
@Pds_email			NVARCHAR(120),
@Pfl_bloqueado			TINYINT = 0,
@Pfl_opcao1			NVARCHAR(6) = '',
@Pfl_opcao2			NVARCHAR(6) = '',
@Pfl_opcao3			NVARCHAR(6) = '',
@Pfl_opcao4			NVARCHAR(6) = '',
@Pfl_opcao5			NVARCHAR(6) = ''
)

AS

UPDATE tb_ele_funcionario SET
	ele_fun_nm_funcionario		= RTRIM(UPPER(@Pnm_funcionario)),
	ele_fun_fl_sexo			= @Pfl_sexo,
	ele_fun_dt_nascimento		= @Pdt_nascimento,
	ele_fun_ds_cpf			= RTRIM(UPPER(@Pds_cpf)),
	ele_fun_ds_rg			= RTRIM(UPPER(@Pds_rg)),
	ele_fun_nm_mae		= RTRIM(UPPER(@Pnm_mae)),
	ele_fun_nm_pai			= RTRIM(UPPER(@Pnm_pai)),
	ele_fun_nm_indicacao		= RTRIM(UPPER(@Pnm_indicacao)),
	ele_fun_dt_modificacao		= @Pdt_modificacao,
	ele_fun_ds_cep			= RTRIM(UPPER(@Pds_cep)),
	ele_fun_ds_endereco		= RTRIM(UPPER(@Pds_endereco)),
	ele_fun_ds_numero		= RTRIM(UPPER(@Pds_numero)),
	ele_fun_ds_complemento	= RTRIM(UPPER(@Pds_complemento)),
	ele_fun_ds_bairro		= RTRIM(UPPER(@Pds_bairro)),
	ele_fun_ds_cidade		= RTRIM(UPPER(@Pds_cidade)),
	ele_fun_ds_uf			= RTRIM(UPPER(@Pds_uf)),
	ele_fun_nr_ddd_fone_residencial	= @Pnr_ddd_residencial,
	ele_fun_nr_fone_residencial	= @Pnr_fone_residencial,
	ele_fun_nr_ddd_celular		= @Pnr_ddd_celular,
	ele_fun_nr_celular		= @Pnr_celular,
	ele_fun_ds_email		= RTRIM(LOWER(@Pds_email)),
	ele_fun_fl_siga			= '',
	ele_fun_fl_bloqueado		= @Pfl_bloqueado,
	ele_fun_fl_opcao1		= @Pfl_opcao1,
	ele_fun_fl_opcao2		= @Pfl_opcao2,
	ele_fun_fl_opcao3		= @Pfl_opcao3,
	ele_fun_fl_opcao4		= @Pfl_opcao4,
	ele_fun_fl_opcao5		= @Pfl_opcao5
WHERE ele_fun_cd_funcionario	= @Pcd_funcionario
go

