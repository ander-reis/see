
/*******************************************************************
Objeto criado: 	 sp_soc_cad_escola_sel_urna
Descriçao:	Seleciona Escola
Data da Criaçao: 02/06/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_escola_sel_urna
(
@pInt_Urna		INT,
@pNvc_CNPJ		NVARCHAR(18)
)
AS

DECLARE	@Vtotal_inscritos	SMALLINT

SELECT 
	@Vtotal_inscritos = COUNT(DISTINCT PGE.CPF)
FROM Cadastro_Escolas CE INNER JOIN 
	Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
	Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
WHERE  CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
	AND CP.Situacao IN (1,5,9,2,10,12,13) 
	AND PGE.CGC_Escola <> '00.000.000/0000-00'
 	AND ( (CE.Categoria IN (1,6)  AND CE.Situacao IN (0,1) ) OR Categoria = 11)
	AND CE.Urna = @pInt_Urna
GROUP BY CE.Urna
HAVING COUNT(PGE.CPF) >= 1

/*
SELECT 
	CE.CGC_Escola, 
	CE.Razao_Social, 
	CE.Nome_Fantasia, 
	COUNT(PGE.CPF) AS Votos, 
	SUBSTRING(CE.CEP,1,5) AS CEP,
	CE.Endereco + ', ' + CE.Numero AS Endereco1,
	CE.Bairro + ' - ' + CE.Cidade + ' - ' + CE.CEP AS Complemento,
	CE.Urna,
	CE.ds_latitude + ',' + CE.ds_longitude AS ds_latitude,
	@Vtotal_inscritos AS nr_total_inscritos
FROM Cadastro_Escolas CE INNER JOIN 
	Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola LEFT JOIN
	Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
WHERE  CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
	AND CP.Situacao IN (1,5,9,2,10) 
	AND PGE.CGC_Escola <> '00.000.000/0000-00'
 	AND CE.Categoria IN (1,6) 
	AND CE.Situacao IN (0,1) 
	AND CE.Urna = @pInt_Urna
GROUP BY CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Situacao, CE.Categoria, CE.CEP, CE.Urna, CE.Endereco, CE.Numero, CE.Bairro, CE.Cidade, CE.ds_latitude, CE.ds_longitude
HAVING COUNT(PGE.CPF) >= 1
ORDER BY SUBSTRING(CE.CEP,1,5) , CE.CGC_Escola
*/

SELECT     CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, COUNT(PGE.CPF) AS Votos, SUBSTRING(CE.CEP, 1, 5) AS CEP, 
                      CE.Endereco + ', ' + CE.Numero AS Endereco1, CE.Bairro + ' - ' + CE.Cidade + ' - ' + CE.CEP AS Complemento, CE.Urna, 
                      CE.ds_latitude + ',' + CE.ds_longitude AS ds_latitude,
	@Vtotal_inscritos AS nr_total_inscritos
FROM         Cadastro_Escolas CE INNER JOIN
                      Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola LEFT OUTER JOIN
                      Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
WHERE     (CP.Data_Inicio <= DATEADD(month, - 6, DATEADD(day, - 1, '10/24/2018'))) AND (CP.Situacao IN (1, 5, 9, 2, 10,12,13)) AND 
                      (PGE.CGC_Escola <> '00.000.000/0000-00') AND ( (CE.Categoria IN (1,6)  AND CE.Situacao IN (0,1) ) OR Categoria = 11) AND (CE.Urna = @pInt_Urna)
GROUP BY CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Situacao, CE.Categoria, CE.CEP, CE.Urna, CE.Endereco, CE.Numero, CE.Bairro, 
                      CE.Cidade, CE.ds_latitude, CE.ds_longitude
HAVING      (COUNT(PGE.CPF) >= 1)
ORDER BY CE.Endereco, CE.Numero, CE.CGC_Escola
/*
--QDO FOR GERAR A LISTA PRECISA DECOMENTAR O UNION ABAIXO


UNION

SELECT     CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, COUNT(PGE.CPF) AS Votos, SUBSTRING(CE.CEP, 1, 5) AS CEP, 
                      CE.Endereco + ', ' + CE.Numero AS Endereco1, CE.Bairro + ' - ' + CE.Cidade + ' - ' + CE.CEP AS Complemento, CE.Urna, 
                      CE.ds_latitude + ',' + CE.ds_longitude AS ds_latitude,
	@Vtotal_inscritos AS nr_total_inscritos
FROM         Cadastro_Escolas_Avulsa CE INNER JOIN
                      Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola LEFT OUTER JOIN
                      Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
WHERE     (CP.Data_Inicio <= DATEADD(month, - 6, DATEADD(day, - 1, '10/24/2018'))) AND (CP.Situacao IN (1, 5, 9, 2, 10,12,13)) AND 
                      (PGE.CGC_Escola <> '00.000.000/0000-00') AND (CE.Urna = @pInt_Urna)
GROUP BY CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.CEP, CE.Urna, CE.Endereco, CE.Numero, CE.Bairro, CE.Cidade, CE.ds_latitude, 
                      CE.ds_longitude
HAVING      (COUNT(PGE.CPF) >= 1)
ORDER BY SUBSTRING(CE.CEP, 1, 5), CE.CGC_Escola
*/
go

