

/*******************************************************************
Objeto criado: 	 sp_juridico_processo_agendameto_ins
Descriçao:	Cadastra os Agendamentos do Processo
Data da Criaçao: 03/07/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_agendamento_ins
(
@Pnr_pasta		NVARCHAR(8),
@Pcd_agendamento	INT,
@Pcd_andamento	INT,
@Pdt_agendamento	DATETIME,
@Phr_agendamento	DATETIME,
@Pfl_concluido		TINYINT,
@Pds_observacao	NVARCHAR(600),
@Pdt_cadastro		DATETIME,
@Pnm_login		NVARCHAR(30)
)

AS

IF @Pcd_agendamento = 0  
	INSERT INTO tb_jur_processo_agendamento
		(jur_pca_nr_pasta,
		jur_pca_cd_andamento,
		jur_pca_dt_agendamento,
		jur_pca_hr_agendamento,
		jur_pca_fl_concluido,
		jur_pca_ds_observacao,
		jur_pca_dt_cadastro, 
		jur_pca_nm_login)
	VALUES
		(@Pnr_pasta,
		@Pcd_andamento,
		@Pdt_agendamento,
		@Phr_agendamento,
		@Pfl_concluido,
		@Pds_observacao,
		@Pdt_cadastro,
		@Pnm_login)
ELSE
	UPDATE tb_jur_processo_agendamento SET
		jur_pca_fl_concluido	= @Pfl_concluido,
		jur_pca_ds_observacao	= @Pds_observacao,
		jur_pca_dt_cadastro	= @Pdt_cadastro, 
		jur_pca_nm_login	= @Pnm_login
	WHERE
		jur_pca_cd_agendamento = @Pcd_agendamento
go

