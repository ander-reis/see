CREATE PROCEDURE sp_pos_imagem_curso_sel
(
@Pcd_curso	REAL
)

AS

SELECT    
	 pos_pci_cd_imagem, 
	pos_pci_cd_curso,
	pos_pci_ds_arquivo, 
	pos_pci_ds_obs, 
	pos_pci_dt_cadastro, 
	pos_pci_ds_login

FROM         
	tb_pos_curso_imagem
WHERE pos_pci_cd_curso=@Pcd_curso
go

