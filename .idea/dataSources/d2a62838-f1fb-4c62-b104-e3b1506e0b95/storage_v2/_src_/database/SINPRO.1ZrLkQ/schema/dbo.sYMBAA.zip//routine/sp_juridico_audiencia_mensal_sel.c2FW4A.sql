
/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_mensal_sel
Descriçao:	Seleciona Audiencias do Mês
Data da Criaçao: 08/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_mensal_sel
(
@Pdt_audiencia		NVARCHAR(7)
)

AS
SELECT    
	AUD.jur_aud_cd_audiencia,
	AUD.jur_aud_nr_pasta,
	PRC.jur_prc_nr_processo AS Numero_Processo,
	CONVERT(CHAR(10),AUD.jur_aud_dt_audiencia,103) AS Data,
	CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia,108) AS Horario,
	CASE AUD.jur_aud_fl_retorno
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS Retorno, 
	CAU.jur_cau_ds_audiencia Audiencia,
	ADV.jur_adv_nm_advogado + SPACE(100) + ' -- ' + ADV.jur_adv_nr_oab AS Advogado,
	FIP.jur_fip_cd_professor AS Codigo_Professor,
	CP.Nome, 
	CE.Nome_Fantasia,
	CVA.jur_cva_ds_vara AS Vara,
	SUBSTRING(CVA.jur_cva_ds_complemento, PATINDEX('%-%', CVA.jur_cva_ds_complemento) + 2, 9) AS Andar,
	AUD.jur_aud_nm_cadastrado,
	CONVERT(CHAR(10),AUD.jur_aud_dt_cadastrado,103) + ' ' + CONVERT(CHAR(10),AUD.jur_aud_dt_cadastrado,108) AS dt_cadastrado, 
	'(' + CP.DDD_Telefone_Residencial + ') ' + CP.Telefone_Residencial AS Residencial, 
	'(' + CP.DDD_Telefone_Comercial + ') ' + CP.Telefone_Comercial AS Comercial, 
	'(' + CP.DDD_Telefone_Celular + ') ' + CP.Telefone_Celular AS Celular,
	AUD.jur_aud_fl_situacao,
	AUD.jur_aud_cd_advogado,
	AUD.jur_aud_fl_audiencia,
	CE.fl_judicial,
	CP.Situacao,
	FIC.jur_fic_fl_processo,
	PRC.jur_prc_fl_greve
FROM
	tb_jur_processo PRC INNER JOIN
	tb_jur_cadastro_vara CVA ON PRC.jur_prc_cd_vara = CVA.jur_cva_cd_vara INNER JOIN
	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_pasta = FIC.jur_fic_nr_pasta INNER JOIN
	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor INNER JOIN
	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
	tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta INNER JOIN
	tb_jur_cadastro_advogado ADV ON AUD.jur_aud_cd_advogado = ADV.jur_adv_cd_advogado INNER JOIN
	tb_jur_cadastro_audiencia CAU ON AUD.jur_aud_fl_audiencia = CAU.jur_cau_fl_audiencia
WHERE     
		MONTH(AUD.jur_aud_dt_audiencia) = CONVERT(INT,LEFT(@Pdt_audiencia ,2))
		AND YEAR(AUD.jur_aud_dt_audiencia) = CONVERT(INT,RIGHT(@Pdt_audiencia ,4))
		AND ((FIC.jur_fic_fl_processo = 1 AND FIP.jur_fip_cd_professor = '00000') OR FIC.jur_fic_fl_processo = 0 OR (FIC.jur_fic_fl_processo = 2 AND FIP.jur_fip_fl_plurima = 1))
ORDER BY 
	CONVERT(CHAR(8),AUD.jur_aud_dt_audiencia,112),
	CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia,108),	
	CVA.jur_cva_ds_vara
go

