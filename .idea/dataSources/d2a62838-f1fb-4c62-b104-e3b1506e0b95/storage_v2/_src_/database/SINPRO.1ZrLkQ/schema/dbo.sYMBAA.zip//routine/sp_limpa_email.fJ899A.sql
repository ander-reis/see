/*******************************************************************
Objeto criado: 	 sp_limpa_email
Descriçao:	Procedure para remover e-mails que retornam com erro do boletim
Data da Criaçao: 03/07/2012
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_limpa_email
(
@Pds_email		NVARCHAR(100) = ''
)
AS
DECLARE @Vcd_professor NVARCHAR(5), @Vds_email1 NVARCHAR(100), @Vds_email2 NVARCHAR(100), @Vds_email3 NVARCHAR(100),
@Vdt_data AS DATETIME, @Vdt_hora AS DATETIME, @Vds_observacao NVARCHAR(150), @Vds_email NVARCHAR(150)

SET @Vcd_professor = ''
SET @Vdt_data         = CONVERT(CHAR(10),GETDATE(),111)
SET @Vdt_hora         = CONVERT(CHAR(8),GETDATE(),108)

SELECT
	@Vcd_professor = pro_ema_cd_professor,
	@Vds_email1      = pro_ema_ds_email1,
	@Vds_email2      = pro_ema_ds_email2,
	@Vds_email3      = pro_ema_ds_email3
FROM 
	tb_professor_email
WHERE
	UPPER(pro_ema_ds_email1) = @Pds_email
	OR UPPER(pro_ema_ds_email2) = @Pds_email
	OR UPPER(pro_ema_ds_email3) = @Pds_email


IF @Vcd_professor <> ''
BEGIN

	SET @Vds_email = ''

	IF @Vds_email1 = LOWER(@Pds_email)
		SET @Vds_email1 = ''
	IF @Vds_email2 = LOWER(@Pds_email)
		SET @Vds_email2 = ''
	IF @Vds_email3 = LOWER(@Pds_email)
		SET @Vds_email3 = ''

	IF @Vds_email1 = ''
	BEGIN
		IF @Vds_email2 <> ''
		BEGIN
			SET @Vds_email1 = @Vds_email2
			SET @Vds_email2 = ''
		END
		ELSE
		BEGIN
			IF @Vds_email3 <> ''
			BEGIN
				SET @Vds_email1 = @Vds_email3
				SET @Vds_email3 = ''
			END
		END
	END

	IF @Vds_email2 = ''
	BEGIN
		IF @Vds_email3 <> ''
		BEGIN
			SET @Vds_email2 = @Vds_email3
			SET @Vds_email3 = ''
		END
	END	
	

	EXEC sp_soc_cad_professores_email_upd @Vcd_professor, @Vds_email1, @Vds_email2, @Vds_email3

	IF @Vds_email1 <> LOWER(@Pds_email) AND @Vds_email1 <> ''
		SET @Vds_email = @Vds_email + ';' + @Vds_email1

	IF @Vds_email2 <> LOWER(@Pds_email) AND @Vds_email2 <> ''
		SET @Vds_email = @Vds_email + ';' + @Vds_email2

	IF @Vds_email3 <> LOWER(@Pds_email) AND @Vds_email3 <> ''
		SET @Vds_email = @Vds_email + ';' + @Vds_email3

	PRINT @Vds_email

	SET @Vds_observacao = 'O E-MAIL ' + @Pds_email + ' É INVÁLIDO E FOI REMOVIDO DA NOSSA BASE.'
	EXEC sp_soc_cad_professores_ins_observacao @Vcd_professor, @Vdt_data, @Vds_observacao, 'SAS', @Vdt_hora
END
ELSE
	DELETE FROM website.dbo.tb_sinpro_email_boletim WHERE ds_email = LOWER(@Pds_email)
go

