


/*******************************************************************
Objeto criado: 	 sp_juridico_vara_ins
Descriçao:	Inclui a Vara
Data da Criaçao: 22/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_vara_ins
(
@Pcd_vara		INT,
@Pcd_advogado	INT,
@Pds_vara		VARCHAR(20),
@Pds_endereco	NVARCHAR(63),
@Pds_numero		NVARCHAR(6),
@Pds_complemento	NVARCHAR(100),
@Pnr_fone		NVARCHAR(9),
@Pfl_dia_semana	TINYINT
)

AS

INSERT INTO    tb_jur_cadastro_vara (
	jur_cva_cd_vara,
	jur_cva_cd_advogado,
	jur_cva_ds_vara,
	jur_cva_ds_endereco,
	jur_cva_ds_numero,
	jur_cva_ds_complemento,
	jur_cva_nr_fone,
	jur_cva_fl_dia_semana)

VALUES (
	@Pcd_vara,
	@Pcd_advogado,
	@Pds_vara,
	@Pds_endereco,
	@Pds_numero,
	@Pds_complemento,
	@Pnr_fone,
	@Pfl_dia_semana)
go

