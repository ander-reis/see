
/*******************************************************************
Objeto criado: 	 sp_eleicao_votos_professor_del
Descriçao:	Apaga Escola em que Professor Votou 
Data da Criaçao: 30/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_votos_professor_del
(
@Pds_eleicao		CHAR(4),
@Pnr_urna		INT = 0,
@Pcd_professor		NVARCHAR(5),
@Pcd_escola		NVARCHAR(18)
)

AS

DECLARE @Vcd_voto INT
DECLARE @Vcd_duplicado BIT

SET @Vcd_voto = 0

SELECT @Vcd_duplicado = ele_evp_fl_duplicado
	FROM tb_eleicao_votos_professor
	WHERE ele_evp_ds_eleicao = @Pds_eleicao
		AND ele_evp_cd_professor = @Pcd_professor

SELECT TOP 1 
	@Vcd_voto = ele_evp_cd_voto
FROM tb_eleicao_votos_professor
WHERE ele_evp_ds_eleicao = @Pds_eleicao
	AND ele_evp_cd_professor = @Pcd_professor
	AND ele_evp_cd_escola = '00.000.000/0000-00'
	AND ele_evp_fl_votou = 1

IF @Vcd_voto <> 0 
	UPDATE tb_eleicao_votos_professor SET
		ele_evp_fl_votou= 0
	WHERE ele_evp_cd_voto = @Vcd_voto
ELSE
BEGIN

	SELECT TOP 1 
		@Vcd_voto = ele_evp_cd_voto
	FROM tb_eleicao_votos_professor
	WHERE ele_evp_ds_eleicao = @Pds_eleicao
		AND ele_evp_cd_professor = @Pcd_professor
		AND ele_evp_cd_escola = @Pcd_escola

	UPDATE tb_eleicao_votos_professor SET
		ele_evp_fl_votou= 0
	WHERE ele_evp_cd_voto = @Vcd_voto
END

IF @Vcd_duplicado >0 
	UPDATE tb_eleicao_votos_professor SET
		ele_evp_fl_duplicado = @Vcd_duplicado -1
	WHERE ele_evp_ds_eleicao = @Pds_eleicao
		AND ele_evp_cd_professor = @Pcd_professor


/*
DELETE FROM   tb_eleicao_votos_professor
WHERE ele_evp_cd_voto = @Vcd_voto
*/
go

