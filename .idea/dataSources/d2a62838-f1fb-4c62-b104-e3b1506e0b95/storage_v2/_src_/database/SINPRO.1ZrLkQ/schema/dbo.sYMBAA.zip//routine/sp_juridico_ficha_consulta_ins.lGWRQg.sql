/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_consulta_ins
Descriçao:	Cadastra a Ficha de Consulta
Data da Criaçao: 28/02/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_consulta_ins
(
@Pdt_cadastro		DATETIME,
@Pnm_login		NVARCHAR(30),
@Pcd_cnpj		NVARCHAR(18),
@Pcd_advogado	INT,
@Pfl_honorario		TINYINT,
@Pfl_status		TINYINT,
@Pnr_ficha		INT OUTPUT
)

AS

DECLARE @Vnr_ficha	INT

EXEC sp_codigo_ins 'codficha', @Vnr_ficha OUTPUT

INSERT INTO    tb_jur_ficha_consulta
	(jur_fic_nr_ficha,
	jur_fic_dt_cadastro,
	jur_fic_nm_login,
	jur_fic_cd_cnpj,
	jur_fic_cd_advogado,
	jur_fic_fl_status,
	jur_fic_fl_honorario,
	jur_fic_fl_email_leitura)
VALUES
	(@Vnr_ficha,
	@Pdt_cadastro,
	@Pnm_login,
	@Pcd_cnpj,
	@Pcd_advogado,
	@Pfl_status,
	@Pfl_honorario,
	0)

SET @Pnr_ficha = @Vnr_ficha
go

