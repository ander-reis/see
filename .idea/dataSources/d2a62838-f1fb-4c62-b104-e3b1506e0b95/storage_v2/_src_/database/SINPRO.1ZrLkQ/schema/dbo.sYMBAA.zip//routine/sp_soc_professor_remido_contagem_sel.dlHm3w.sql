
/*******************************************************************
Objeto criado: 	 sp_soc_professor_remido_contagem_sel
Descriçao:	Conta contribuições de Professor Remido
Data da Criaçao: 17/02/2011
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_professor_remido_contagem_sel
(
@Pds_cpf	NVARCHAR(14),
@Pnm_login	NVARCHAR(30),
@Pfl_remido	INT OUTPUT
)
AS

DECLARE @Vano_sindic	INT
DECLARE @Vfl_retorno		INT

SELECT @Vano_sindic = DATEDIFF(YYYY,Data_Inicio,GetDate()) FROM Cadastro_Professores WHERE CPF = @Pds_cpf

IF @Vano_sindic >= 10
BEGIN
	INSERT INTO tb_professor_remido_contagem  SELECT     PGL.cd_arrecadacao, PGL.cd_escola, PGL.cd_professor, @Pnm_login
	FROM         tb_pagantes_lista PGL INNER JOIN
	                      Cadastro_Arrecadacoes ARR ON PGL.cd_arrecadacao = ARR.cd_arrecadacao
	WHERE     (PGL.cd_professor = @Pds_cpf) AND dt_vencimento > = CONVERT(DATETIME,CONVERT(CHAR(4),YEAR(DATEADD(M,-45,getdate()))) + '/' + CONVERT(NVARCHAR(2),MONTH(DATEADD(M,-45,getdate()))) + '/01') AND ARR.cd_tipo_boleto = 3
			AND PGL.cd_situacao <> 3
	ORDER BY PGL.cd_arrecadacao
	
	INSERT INTO tb_professor_remido_contagem  SELECT     PGL.cd_arrecadacao, PGL.cd_escola, PGL.cd_professor, @Pnm_login
	FROM         Pagantes_Boletos PGL INNER JOIN
	                      Cadastro_Arrecadacoes ARR ON PGL.cd_arrecadacao = ARR.cd_arrecadacao
	WHERE     (PGL.cd_professor = @Pds_cpf) AND dt_vencimento > = CONVERT(DATETIME,CONVERT(CHAR(4),YEAR(DATEADD(M,-45,getdate()))) + '/' + CONVERT(NVARCHAR(2),MONTH(DATEADD(M,-45,getdate()))) + '/01') AND ARR.cd_tipo_boleto = 3
	ORDER BY PGL.cd_arrecadacao

	SELECT @Pfl_remido = COUNT(DISTINCT cd_arrecadacao)  FROM tb_professor_remido_contagem
	WHERE nm_login = @Pnm_login

	DELETE FROM tb_professor_remido_contagem
	WHERE nm_login =  @Pnm_login

	
END
ELSE
	SELECT  @Pfl_remido = 0

RETURN @Pfl_remido
go

