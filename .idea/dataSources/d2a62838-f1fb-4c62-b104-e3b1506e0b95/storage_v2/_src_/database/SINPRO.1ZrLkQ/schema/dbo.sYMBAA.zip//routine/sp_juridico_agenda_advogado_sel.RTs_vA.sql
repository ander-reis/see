
/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_advogado_sel
Descriçao:	Seleciona advogado
Data da Criaçao: 11/01/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_agenda_advogado_sel
AS

SELECT 
	jur_adv_cd_advogado,
	jur_adv_nm_advogado, 
	jur_adv_nr_oab,
	jur_adv_ds_cpf
FROM tb_jur_cadastro_advogado
WHERE jur_adv_fl_ativo = 1 and jur_adv_fl_sinpro = 1 and jur_adv_fl_atendimento = 1
ORDER BY jur_adv_nm_advogado
go

