/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_email_upd
Descriçao:	Atualiza o Envio do Email da Audiência
Data da Criaçao: 24/11/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_email_upd
(
@Pcd_audiencia	INT,
@Pfl_email		TINYINT
)

AS

UPDATE    tb_jur_audiencia SET
	jur_aud_fl_email = @Pfl_email
WHERE jur_aud_cd_audiencia = @Pcd_audiencia
go

