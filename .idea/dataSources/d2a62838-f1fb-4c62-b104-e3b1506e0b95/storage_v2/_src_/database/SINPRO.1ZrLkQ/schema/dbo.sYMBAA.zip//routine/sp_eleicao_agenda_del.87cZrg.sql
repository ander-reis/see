

/*******************************************************************
Objeto criado: 	 sp_eleicao_agenda_del
Descriçao:	Deleta Distribuição de Agendas
Data da Criaçao: 25/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_agenda_del
(
@Pcd_agenda		INT
)
AS

DELETE
	FROM tb_ele_agenda 
	WHERE ele_eag_cd_agenda = @Pcd_agenda
go

