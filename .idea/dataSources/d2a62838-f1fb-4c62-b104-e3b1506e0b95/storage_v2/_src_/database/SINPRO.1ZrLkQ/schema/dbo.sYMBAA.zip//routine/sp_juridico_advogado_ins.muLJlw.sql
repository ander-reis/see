
/*******************************************************************
Objeto criado: 	 sp_juridico_advogado_ins
Descriçao:	Inclui no Cadastro de Advogados
Data da Criaçao: 22/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_advogado_ins
(
@Pcd_advogado		NVARCHAR(5),
@Pnm_advogado		VARCHAR(70),
@Pfl_sexo			TINYINT,
@Pds_cpf			NVARCHAR(14),
@Pds_rg			NVARCHAR(12),
@Pfl_civil			TINYINT, 
@Pnr_oab			VARCHAR(10),
@Pds_oab			CHAR(2),
@Pds_cep			NVARCHAR(9),
@Pds_endereco		NVARCHAR(63),
@Pds_numero			NVARCHAR(6),
@Pds_complemento		NVARCHAR(50),
@Pds_bairro			NVARCHAR(59),
@Pds_cidade			NVARCHAR(21),
@Pds_uf			NVARCHAR(2),
@Pnr_ddd_residencial		NVARCHAR(2),
@Pnr_fone_residencial		NVARCHAR(9),
@Pnr_ddd_celular		NVARCHAR(2),
@Pnr_celular			NVARCHAR(10),
@Pds_email			NVARCHAR(120),
@Pfl_ativo			TINYINT,
@Pfl_sinpro			TINYINT,
@Pfl_cargo			TINYINT,
@Pfl_procuracao		TINYINT,
@Pfl_atendimento		TINYINT,
@Pfl_doe			TINYINT = 1
)
AS

INSERT INTO tb_jur_cadastro_advogado (
	jur_adv_cd_advogado,
	jur_adv_nm_advogado,
	jur_adv_fl_sexo,
	jur_adv_ds_cpf,
	jur_adv_ds_rg,
	jur_adv_fl_civil,
	jur_adv_nr_oab,
	jur_adv_ds_uf_oab,
	jur_adv_ds_cep,
	jur_adv_ds_endereco,
	jur_adv_ds_numero,
	jur_adv_ds_complemento,
	jur_adv_ds_bairro,
	jur_adv_ds_cidade,
	jur_adv_ds_uf,
	jur_adv_nr_ddd_fone_residencial,
	jur_adv_nr_fone_residencial,
	jur_adv_nr_ddd_celular,
	jur_adv_nr_celular,
	jur_adv_ds_email,
	jur_adv_fl_ativo,
	jur_adv_fl_sinpro,
	jur_adv_fl_cargo,
	jur_adv_fl_procuracao,
	jur_adv_fl_atendimento,
	jur_adv_fl_doe)
VALUES     (
	@Pcd_advogado,
	RTRIM(UPPER(@Pnm_advogado)),
	@Pfl_sexo,
	RTRIM(UPPER(@Pds_cpf)),
	RTRIM(UPPER(@Pds_rg)),
	@Pfl_civil,
	RTRIM(UPPER(@Pnr_oab)),
	RTRIM(UPPER(@Pds_oab)),
	RTRIM(UPPER(@Pds_cep)),
	RTRIM(UPPER(@Pds_endereco)),
	RTRIM(UPPER(@Pds_numero)),
	RTRIM(UPPER(@Pds_complemento)),
	RTRIM(UPPER(@Pds_bairro)),
	RTRIM(UPPER(@Pds_cidade)),
	RTRIM(UPPER(@Pds_uf)),
	@Pnr_ddd_residencial,
	@Pnr_fone_residencial,
	@Pnr_ddd_celular,
	@Pnr_celular,
	RTRIM(LOWER(@Pds_email)),
	@Pfl_ativo,
	@Pfl_sinpro,
	@Pfl_cargo,
	@Pfl_procuracao,
	@Pfl_atendimento,
	@Pfl_doe)
go

