

/*******************************************************************
Objeto criado: 	 sp_juridico_processo_ficha_sel
Descriçao:	Seleciona a Ficha de Consulta para o Processo
Data da Criaçao: 25/06/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_ficha_sel
(
@Pnr_ficha		INT
)
AS

-- Dados do Professor / Escola
SELECT
	FIP.jur_fip_cd_fic_pro,
	FIP.jur_fip_cd_professor,
	CP.Nome,
	'(' + CP.DDD_Telefone_Residencial + ')' + CP.Telefone_Residencial AS Residencial,
	'(' + CP.DDD_Telefone_Celular + ')' + CP.Telefone_Celular AS Celular,

	LEFT(CASE   WHEN ISNULL(pro_ema_ds_email1,'') <> '' THEN ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END 
	             + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
	             + CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END,
	             LEN(CASE   WHEN  ISNULL(pro_ema_ds_email1,'') <> '' THEN  ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END
	             + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
		+ CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END) -1) AS pro_ema_ds_email,
	
	CASE 	FIP.jur_fip_fl_receber
		WHEN 0 THEN 'NÃO'	
		ELSE 'SIM'
	END AS jur_fip_fl_receber,
	FIC.jur_fic_cd_cnpj,
	CE.Razao_Social,
	CE.Nome_Fantasia,
	CE.Telefone1,
	CE.Telefone1_Ramal,
	CE.Contato,
	FIC.jur_fic_nr_pasta,
	CASE CP.Banco
		WHEN '000' THEN ''
		ELSE CP.Banco
	END AS Banco,

	CASE CP.Banco
		WHEN '000' THEN ''
		ELSE CB.Banco
	END  AS pro_ban_ds_banco,

	CP.Agencia,
	CP.Conta,
	CASE CP.Poupanca
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS Poupanca,
	CASE CP.Conjunta
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS Conjunta,
	CASE FIC.jur_fic_fl_honorario
		WHEN 0 THEN '5%'
		WHEN 1 THEN '10%'
		ELSE '15%'
	END AS jur_fic_fl_honorario,	
	CP.CPF,
	ADV.jur_adv_nm_advogado,
	FIP.jur_fip_nm_inventariante,
	FIP.jur_fip_ds_cpf_inventariante,
	FIC.jur_fic_fl_status,
	CP.Sexo,
	CONVERT(DECIMAL(10,2),FIC.jur_fic_vl_causa) AS jur_fic_vl_causa,
	CE.fl_judicial,
	CASE FIC.jur_fic_fl_processo
		WHEN 0 THEN 'INVIDIDUAL'
		WHEN 1 THEN 'COLETIVO'
		ELSE 'PLÚRIMA'
	END AS jur_fic_fl_processo	,
	CE.CEP
FROM
	tb_jur_ficha_professor FIP 
	INNER JOIN Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	LEFT JOIN tb_professor_email EMA ON EMA.pro_ema_cd_professor = CP.Codigo_Professor
	INNER JOIN tb_jur_ficha_consulta FIC
	INNER JOIN Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha
	INNER JOIN Cadastro_Banco CB ON CP.Banco = CB.CodBanco
	INNER JOIN tb_jur_cadastro_advogado ADV ON FIC.jur_fic_cd_advogado = ADV.jur_adv_cd_advogado
WHERE
	FIC.jur_fic_nr_ficha = @Pnr_ficha
ORDER BY
	CP.Nome

-- causa do Processo
SELECT
	FCA.jur_fca_cd_causa,
	CAU.jur_cau_ds_causa,
	CASE FCA.jur_fca_fl_vara
		WHEN 0 THEN 'NÃO'
		WHEN 1 THEN 'SIM'
		WHEN 2 THEN 'EMBARGOS'
		ELSE ''
	END  AS jur_fca_fl_vara,

	CASE FCA.jur_fca_fl_trt
		WHEN 0 THEN 'NÃO'
		WHEN 1 THEN 'SIM'
		WHEN 2 THEN 'EMBARGOS'
		ELSE ''
	END  AS jur_fca_fl_trt,

	CASE FCA.jur_fca_fl_tst
		WHEN 0 THEN 'NÃO'
		WHEN 1 THEN 'SIM'
		WHEN 2 THEN 'EMBARGOS'
		ELSE ''
	END  AS jur_fca_fl_tst,

	CASE FCA.jur_fca_fl_stf
		WHEN 0 THEN 'NÃO'
		WHEN 1 THEN 'SIM'
		WHEN 2 THEN 'EMBARGOS'
		ELSE ''
	END  AS jur_fca_fl_stf
FROM
	tb_jur_ficha_causa FCA
	INNER JOIN tb_jur_cadastro_causa CAU ON FCA.jur_fca_cd_causa = CAU.jur_cau_cd_causa
WHERE
	FCA.jur_fca_nr_ficha = @Pnr_ficha
ORDER BY CAU.jur_cau_ds_causa
go

