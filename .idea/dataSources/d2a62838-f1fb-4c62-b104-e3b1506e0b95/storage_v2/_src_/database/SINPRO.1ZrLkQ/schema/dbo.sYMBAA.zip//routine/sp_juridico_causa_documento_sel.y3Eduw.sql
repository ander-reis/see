

/*******************************************************************
Objeto criado: 	 sp_juridico_causa_documento_sel
Descriçao:	Seleciona Cadastro de Documentos
Data da Criaçao: 28/02/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_causa_documento_sel (
@Pnr_ficha	INT
)
AS

SELECT DISTINCT 
	DOC.jur_doc_cd_documento, 
	DOC.jur_doc_ds_documento
FROM         
	tb_jur_ficha_causa FCA INNER JOIN
	tb_jur_cadastro_causa CAU ON FCA.jur_fca_cd_causa = CAU.jur_cau_cd_causa INNER JOIN
	tb_jur_cadastro_causa_documento CAD ON CAU.jur_cau_cd_causa = CAD.jur_cad_cd_causa INNER JOIN
	tb_jur_cadastro_documento DOC ON CAD.jur_cad_cd_documento = DOC.jur_doc_cd_documento
WHERE    
	FCA.jur_fca_nr_ficha = @Pnr_ficha
ORDER BY 
	DOC.jur_doc_ds_documento

go

