

/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_carta_upd
Descriçao:	Atualiza o Envio da Carta da Audiência
Data da Criaçao: 24/11/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_carta_upd
(
@Pcd_audiencia	INT,
@Pfl_carta		TINYINT
)

AS

UPDATE    tb_jur_audiencia SET
	jur_aud_fl_carta = @Pfl_carta
WHERE jur_aud_cd_audiencia = @Pcd_audiencia
go

