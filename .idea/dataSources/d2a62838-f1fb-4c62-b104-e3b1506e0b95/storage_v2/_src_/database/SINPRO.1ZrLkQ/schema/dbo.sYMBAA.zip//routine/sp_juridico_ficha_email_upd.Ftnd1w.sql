/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_email_upd
Descriçao:	 Atualiza o Flag de Email da Ficha de Consulta
Data da Criaçao: 22/03/2007
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_email_upd
(
@Pnr_ficha 		INT,
@Pfl_email		TINYINT
)
AS

DECLARE @Vfl_email	TINYINT
SET @Vfl_email = 0
SELECT @Vfl_email = 1 FROM tb_jur_ficha_consulta WHERE jur_fic_nr_ficha = @Pnr_ficha AND jur_fic_fl_email = 9

IF @Vfl_email = 0
	UPDATE tb_jur_ficha_consulta SET
		jur_fic_fl_email = @Pfl_email
	WHERE jur_fic_nr_ficha = @Pnr_ficha
go

