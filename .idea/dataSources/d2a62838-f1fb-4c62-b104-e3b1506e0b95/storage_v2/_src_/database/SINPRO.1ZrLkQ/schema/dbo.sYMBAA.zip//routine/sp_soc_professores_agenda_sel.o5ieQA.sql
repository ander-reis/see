/*******************************************************************
Objeto criado: 	 sp_soc_professores_agenda_sel
Descriçao:	Seleciona E-mail dos Professores que enviaremos a Agenda
Data da Criaçao: 08/10/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_professores_agenda_sel
(
@Pdt_envio	DATETIME
)
AS

SELECT
	CP.Nome, 
	CASE CP.Sexo 
		WHEN 1 THEN 'PREZADA PROFESSORA' 
		ELSE 'PREZADO PROFESSOR' 
	END AS Tratamento, 
	
	LEFT(CASE   WHEN ISNULL(pro_ema_ds_email1,'') <> '' THEN ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END 
	+ CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
	+ CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END,
	LEN(CASE   WHEN  ISNULL(pro_ema_ds_email1,'') <> '' THEN  ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END
	+ CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
	+ CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END) -1) AS Email,
	CP.Sexo
FROM
	 Cadastro_Professores CP
	INNER JOIN tb_professor_agenda AGE ON CP.Codigo_Professor = AGE.pro_age_cd_professor
	INNER JOIN tb_professor_email EMA ON AGE.pro_age_cd_professor = EMA.pro_ema_cd_professor
WHERE
	CONVERT(CHAR(10),AGE.pro_age_dt_envio,111) = CONVERT(CHAR(10),@Pdt_envio,111)
ORDER BY
	AGE.pro_age_cd_professor
go

