
/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_observacoes
Descriçao:	Seleciona Observações do Professor
Entrada:	@pNvc_professor  -> Codigo do Professor
Saída:		
Data da Criaçao: 14/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_sel_observacoes
(
@pNvc_professor		NVARCHAR(5)
)
AS


SELECT 
	CONVERT(CHAR(10),Data,103) AS Data, 
	Observacao,
	RTRIM(ISNULL(Login,'')) AS Login,
	RTRIM(ISNULL(CONVERT(CHAR(8),Hora,108),'')) AS Hora 
FROM Professor_Observacoes 
WHERE Codigo_Professor = @pNvc_professor  -- AND CONVERT(CHAR(8),Data,112) >= CONVERT(CHAR(8),DATEADD(yyyy,-5,GETDATE()),112)
ORDER BY CONVERT(CHAR(10),Data,111) DESC,
	CONVERT(CHAR(8),Hora,108) DESC
go

