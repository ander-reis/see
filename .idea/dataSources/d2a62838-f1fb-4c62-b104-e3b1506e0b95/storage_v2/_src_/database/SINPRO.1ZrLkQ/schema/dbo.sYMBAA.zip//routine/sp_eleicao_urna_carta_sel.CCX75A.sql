
/*******************************************************************
Objeto criado: 	 sp_eleicao_urna_carta_sel
Descriçao:	Seleciona os Funcionários / Urnas da Eleição
Data da Criaçao: 18/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_urna_carta_sel
(
@Pds_urna		INT = 0
)
AS

IF @Pds_urna <> 0
	SELECT
		fun.ele_fun_cd_funcionario, fun.ele_fun_nm_funcionario, 
		CASE fun.ele_fun_fl_sexo WHEN 0 THEN 'PREZADO' ELSE 'PREZADA' END + ' ' + fun.ele_fun_nm_funcionario AS Nome,  
		fun.ele_fun_ds_cpf, 
	        CASE fda.ele_dad_ds_cargo WHEN 0 THEN 'Presidente' WHEN 1 THEN 'Mesário' WHEN 2 THEN 'Suplente' END AS ds_cargo, 
		'(' + fun.ele_fun_nr_ddd_fone_residencial + ') ' + fun.ele_fun_nr_fone_residencial + ' / ' + '(' + fun.ele_fun_nr_ddd_celular + ') ' + fun.ele_fun_nr_celular AS Fone, 
		fda.ele_dad_nr_urna, CE.Nome_Fantasia, CE.Endereco, CE.Complemento, fda.ele_dad_ds_cargo, 
		REPLICATE(' ',200) AS Contato, REPLICATE(' ',200) AS Contato1, REPLICATE(' ',200) AS Contato2, REPLICATE(' ',200) AS Contato3
	INTO #Carta_Urna
	FROM	tb_ele_funcionario fun INNER JOIN
		tb_ele_func_dados fda ON fun.ele_fun_cd_funcionario = fda.ele_dad_cd_funcionario  INNER JOIN (
			SELECT CE.CGC_Escola, CE.Nome_Fantasia, CE.Endereco + ', ' + CE.Numero AS Endereco,
				CE.Bairro + ' - ' + CE.Cidade + ' - ' + CE.CEP AS Complemento,	CE.Urna
			FROM	Cadastro_Escolas CE INNER JOIN 
				Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
				Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
			WHERE CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
				AND CP.Situacao IN (1,5,9,2,10,12,13) 
				AND PGE.CGC_Escola <> '00.000.000/0000-00'
			 	AND CE.Categoria IN (1,6) 
				AND CE.Situacao IN (0,1) 
				AND CE.Urna NOT IN(0,1) 
			GROUP BY CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Situacao, 
				 CE.Categoria, CE.CEP, CE.Urna, CE.Endereco, CE.Numero, CE.Bairro, CE.Cidade
			HAVING COUNT(PGE.CPF) >= 1
			UNION
			SELECT CE.CGC_Escola, CE.Nome_Fantasia, CE.Endereco + ', ' + CE.Numero AS Endereco, CE.Bairro + ' - ' + CE.Cidade + ' - ' + CE.CEP AS Complemento,	CE.Urna
			FROM Cadastro_Escolas_Avulsa CE 
		) AS CE ON fda.ele_dad_nr_urna = CE.Urna
	WHERE fda.ele_dad_ds_eleicao = '2018' 
		AND fda.ele_dad_fl_aprovado = 1 
		AND fda.ele_dad_nr_urna NOT IN (0, 1) 
		AND fda.ele_dad_nr_urna IN (@Pds_urna)
	ORDER BY fda.ele_dad_nr_urna, CE.Nome_Fantasia DESC

ELSE
	SELECT
		fun.ele_fun_cd_funcionario, fun.ele_fun_nm_funcionario, 
		CASE fun.ele_fun_fl_sexo WHEN 0 THEN 'PREZADO' ELSE 'PREZADA' END + ' ' + fun.ele_fun_nm_funcionario AS Nome,  
		fun.ele_fun_ds_cpf, 
	        CASE fda.ele_dad_ds_cargo WHEN 0 THEN 'Presidente' WHEN 1 THEN 'Mesário' WHEN 2 THEN 'Suplente' END AS ds_cargo, 
		'(' + fun.ele_fun_nr_ddd_fone_residencial + ') ' + fun.ele_fun_nr_fone_residencial + ' / ' + '(' + fun.ele_fun_nr_ddd_celular + ') ' + fun.ele_fun_nr_celular AS Fone, 
		fda.ele_dad_nr_urna, CE.Nome_Fantasia, CE.Endereco, CE.Complemento, fda.ele_dad_ds_cargo, 
		REPLICATE(' ',200) AS Contato, REPLICATE(' ',200) AS Contato1, REPLICATE(' ',200) AS Contato2, REPLICATE(' ',200) AS Contato3
	INTO #Carta_Urna1
	FROM	tb_ele_funcionario fun INNER JOIN
		tb_ele_func_dados fda ON fun.ele_fun_cd_funcionario = fda.ele_dad_cd_funcionario  INNER JOIN (
			SELECT CE.CGC_Escola, CE.Nome_Fantasia, CE.Endereco + ', ' + CE.Numero AS Endereco,
				CE.Bairro + ' - ' + CE.Cidade + ' - ' + CE.CEP AS Complemento,	CE.Urna
			FROM	Cadastro_Escolas CE INNER JOIN 
				Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
				Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
			WHERE CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
				AND CP.Situacao IN (1,5,9,2,10,12,13) 
				AND PGE.CGC_Escola <> '00.000.000/0000-00'
			 	AND CE.Categoria IN (1,6) 
				AND CE.Situacao IN (0,1) 
				AND CE.Urna NOT IN(0,1) 
			GROUP BY CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Situacao, 
				 CE.Categoria, CE.CEP, CE.Urna, CE.Endereco, CE.Numero, CE.Bairro, CE.Cidade
			HAVING COUNT(PGE.CPF) >= 1
			UNION
			SELECT CE.CGC_Escola, CE.Nome_Fantasia, CE.Endereco + ', ' + CE.Numero AS Endereco, CE.Bairro + ' - ' + CE.Cidade + ' - ' + CE.CEP AS Complemento,	CE.Urna
			FROM Cadastro_Escolas_Avulsa CE
		) AS CE ON fda.ele_dad_nr_urna = CE.Urna
	WHERE fda.ele_dad_ds_eleicao = '2018' 
		AND fda.ele_dad_fl_aprovado = 1 
		AND fda.ele_dad_nr_urna NOT IN (0, 1) 
		AND fda.ele_dad_nr_urna > 110
	ORDER BY fda.ele_dad_nr_urna, CE.Nome_Fantasia DESC

DECLARE @Vnr_urna	INT
DECLARE @Vds_nome	NVARCHAR(200)
DECLARE @Vnr_linha	INT

IF @Pds_urna <> 0
	DECLARE CurUrna CURSOR FAST_FORWARD FOR
		SELECT DISTINCT ele_dad_nr_urna AS ele_dad_nr_urna 
		FROM #Carta_Urna
		ORDER BY ele_dad_nr_urna
ELSE
	DECLARE CurUrna CURSOR FAST_FORWARD FOR
		SELECT DISTINCT ele_dad_nr_urna AS ele_dad_nr_urna 
		FROM #Carta_Urna1
		ORDER BY ele_dad_nr_urna

OPEN CurUrna
	FETCH NEXT FROM CurUrna INTO @Vnr_urna
	WHILE @@FETCH_STATUS = 0
	BEGIN

		SET @Vnr_linha = 0

		DECLARE CurContato CURSOR FAST_FORWARD FOR
			SELECT '- ' + CASE FDA.ele_dad_ds_cargo WHEN 0 THEN 'PRESIDENTE: ' WHEN 1 THEN 'MESÁRIO: ' ELSE 'SUPLENTE: ' END + FUN.ele_fun_nm_funcionario + ' - ' +  '(' + FUN.ele_fun_nr_ddd_fone_residencial + ') ' + FUN.ele_fun_nr_fone_residencial + ' / ' + '(' + FUN.ele_fun_nr_ddd_celular + ') ' + FUN.ele_fun_nr_celular AS Nome
			FROM	tb_ele_funcionario FUN INNER JOIN
	                       		tb_ele_func_dados FDA ON FUN.ele_fun_cd_funcionario = FDA.ele_dad_cd_funcionario
			WHERE FDA.ele_dad_ds_eleicao = '2018' 
				AND FDA.ele_dad_fl_aprovado = 1 
				AND FDA.ele_dad_nr_urna = @Vnr_urna
			ORDER BY FDA.ele_dad_nr_urna, FDA.ele_dad_ds_cargo, ele_fun_nm_funcionario

		OPEN CurContato
			FETCH NEXT FROM CurContato INTO @Vds_nome
			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF @Vnr_linha = 0 	
				BEGIN				
					IF @Pds_urna <> 0
						UPDATE #Carta_Urna SET Contato = @Vds_nome
						WHERE ele_dad_nr_urna = @Vnr_urna
					ELSE
						UPDATE #Carta_Urna1 SET Contato = @Vds_nome
						WHERE ele_dad_nr_urna = @Vnr_urna

					SET @Vnr_linha = 1
				END

				ELSE IF @Vnr_linha = 1					
				BEGIN
					IF @Pds_urna <> 0
						UPDATE #Carta_Urna SET Contato1 = @Vds_nome
						WHERE ele_dad_nr_urna = @Vnr_urna
					ELSE
						UPDATE #Carta_Urna1 SET Contato1 = @Vds_nome
						WHERE ele_dad_nr_urna = @Vnr_urna

					SET @Vnr_linha = 2
				END

				ELSE IF @Vnr_linha = 2					
				BEGIN
					IF @Pds_urna <> 0
						UPDATE #Carta_Urna SET Contato2 = @Vds_nome
						WHERE ele_dad_nr_urna = @Vnr_urna
					ELSE
						UPDATE #Carta_Urna1 SET Contato2 = @Vds_nome
						WHERE ele_dad_nr_urna = @Vnr_urna

					SET @Vnr_linha = 3
				END

				ELSE IF @Vnr_linha = 3					
				BEGIN
					IF @Pds_urna <> 0
						UPDATE #Carta_Urna SET Contato3 = @Vds_nome
						WHERE ele_dad_nr_urna = @Vnr_urna
					ELSE
						UPDATE #Carta_Urna1 SET Contato3 = @Vds_nome
						WHERE ele_dad_nr_urna = @Vnr_urna

					SET @Vnr_linha = 4		
				END
				
				FETCH NEXT FROM CurContato INTO @Vds_nome
			END
		CLOSE CurContato
		DEALLOCATE CurContato
			
		FETCH NEXT FROM CurUrna INTO @Vnr_urna
	END
CLOSE CurUrna
DEALLOCATE CurUrna

IF @Pds_urna <> 0
	SELECT * 
	FROM #Carta_Urna 
	ORDER BY ele_dad_nr_urna, ele_dad_ds_cargo
ELSE
	SELECT * 
	FROM #Carta_Urna1 
	ORDER BY ele_dad_nr_urna, ele_dad_ds_cargo

