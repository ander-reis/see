--*******************************************************************
--Objeto criado: 	 sp_juridico_processo_recurso_sel
--**Descriçao:	Seleciona os recursos do jurídico
--Data da Criaçao: 20/02/20088
--Autor:		Adriana - SinproSP
--*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_recurso_sel
(
@Pdt_inicio		DATETIME,
@Pdt_fim		DATETIME,
@Pfl_situacao		INT,
@Pfl_recurso		INT,
@Pfl_encerramento	INT
)

AS

IF @Pfl_situacao=0 AND @Pfl_encerramento<>'2'   -- Especifico E Selecionando encerramento
BEGIN
	SELECT    
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao,
		jur_prc_nr_processo,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN 'VARA' 
			WHEN '1' THEN 'T.R.T' 
			WHEN '2' THEN 'T.S.T' 
			WHEN '3' THEN 'S.T.F' 
			WHEN '4' THEN 'VARA' 
			ELSE 'VARA'
			END AS TIPO_RECURSO,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN  PRC.jur_prc_nr_processo
			WHEN '1' THEN PRC.jur_prc_nr_trt 
			WHEN '2' THEN PRC.jur_prc_nr_tst 
			WHEN '3' THEN PRC.jur_prc_nr_stf  
			WHEN '4' THEN PRC.jur_prc_nr_processo 
			ELSE PRC.jur_prc_nr_processo 
			END AS RECURSO,
		CASE 
			PRC.jur_prc_fl_encerrado WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Encerrado' 
			END AS ENCERRADO,
		PRC.jur_prc_dt_final                      
	FROM         
		tb_jur_processo PRC INNER JOIN
                      	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE    
	 	PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim 
		AND  FIP.jur_fip_cd_professor <> N'00000'
		AND FIC.jur_fic_fl_processo = 0
		 AND  PRC.jur_prc_fl_recurso = @Pfl_recurso
		AND PRC.jur_prc_fl_encerrado=@Pfl_encerramento
	UNION
	SELECT     
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao,
		jur_prc_nr_processo,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN 'VARA' 
			WHEN '1' THEN 'T.R.T' 
			WHEN '2' THEN 'T.S.T' 
			WHEN '3' THEN 'S.T.F' 
			WHEN '4' THEN 'VARA' 
			ELSE 'VARA'
			END AS TIPO_RECURSO,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN  PRC.jur_prc_nr_processo
			WHEN '1' THEN PRC.jur_prc_nr_trt 
			WHEN '2' THEN PRC.jur_prc_nr_tst 
			WHEN '3' THEN PRC.jur_prc_nr_stf  
			WHEN '4' THEN PRC.jur_prc_nr_processo 
			ELSE PRC.jur_prc_nr_processo 
			END AS RECURSO,
		CASE 
			PRC.jur_prc_fl_encerrado WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Encerrado' 
			END AS ENCERRADO,	
		PRC.jur_prc_dt_final         
	FROM         
		tb_jur_processo PRC INNER JOIN
                      	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE     
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim
		AND   FIP.jur_fip_cd_professor = '00000'
		AND FIC.jur_fic_fl_processo = 1
		AND  PRC.jur_prc_fl_recurso = @Pfl_recurso
		AND PRC.jur_prc_fl_encerrado=@Pfl_encerramento
END
ELSE IF  @Pfl_situacao=1 AND @Pfl_encerramento<>'2'   -- Especifico E Selecionando encerramento
BEGIN
	SELECT    
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao,
		jur_prc_nr_processo,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN 'VARA' 
			WHEN '1' THEN 'T.R.T' 
			WHEN '2' THEN 'T.S.T' 
			WHEN '3' THEN 'S.T.F' 
			WHEN '4' THEN 'VARA' 
			ELSE 'VARA'
			END AS TIPO_RECURSO,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN  PRC.jur_prc_nr_processo
			WHEN '1' THEN PRC.jur_prc_nr_trt 
			WHEN '2' THEN PRC.jur_prc_nr_tst 
			WHEN '3' THEN PRC.jur_prc_nr_stf  
			WHEN '4' THEN PRC.jur_prc_nr_processo 
			ELSE PRC.jur_prc_nr_processo 
			END AS RECURSO,
		CASE 
			PRC.jur_prc_fl_encerrado WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Encerrado' 
			END AS ENCERRADO,
		PRC.jur_prc_dt_final                      
	FROM         
		tb_jur_processo PRC INNER JOIN
                      	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE    
	 	PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim 
		AND  FIP.jur_fip_cd_professor <> N'00000'
		AND FIC.jur_fic_fl_processo = 0
		AND PRC.jur_prc_fl_encerrado=@Pfl_encerramento
	UNION
	SELECT     
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao,
		jur_prc_nr_processo,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN 'VARA' 
			WHEN '1' THEN 'T.R.T' 
			WHEN '2' THEN 'T.S.T' 
			WHEN '3' THEN 'S.T.F' 
			WHEN '4' THEN 'VARA' 
			ELSE 'VARA'
			END AS TIPO_RECURSO,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN  PRC.jur_prc_nr_processo
			WHEN '1' THEN PRC.jur_prc_nr_trt 
			WHEN '2' THEN PRC.jur_prc_nr_tst 
			WHEN '3' THEN PRC.jur_prc_nr_stf  
			WHEN '4' THEN PRC.jur_prc_nr_processo 
			ELSE PRC.jur_prc_nr_processo 
			END AS RECURSO,
		CASE 
			PRC.jur_prc_fl_encerrado WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Encerrado' 
			END AS ENCERRADO,
		PRC.jur_prc_dt_final         
	FROM         
		tb_jur_processo PRC INNER JOIN
                      	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE     
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim
		AND   FIP.jur_fip_cd_professor = '00000'
		AND FIC.jur_fic_fl_processo = 1
		AND PRC.jur_prc_fl_encerrado=@Pfl_encerramento
END
ELSE IF @Pfl_situacao=0 AND @Pfl_encerramento='2'   -- Especifico E Selecionando encerramento
BEGIN
	SELECT    
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao,
		jur_prc_nr_processo,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN 'VARA' 
			WHEN '1' THEN 'T.R.T' 
			WHEN '2' THEN 'T.S.T' 
			WHEN '3' THEN 'S.T.F' 
			WHEN '4' THEN 'VARA' 
			ELSE 'VARA'
			END AS TIPO_RECURSO,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN  PRC.jur_prc_nr_processo
			WHEN '1' THEN PRC.jur_prc_nr_trt 
			WHEN '2' THEN PRC.jur_prc_nr_tst 
			WHEN '3' THEN PRC.jur_prc_nr_stf  
			WHEN '4' THEN PRC.jur_prc_nr_processo 
			ELSE PRC.jur_prc_nr_processo 
			END AS RECURSO,
		CASE 
			PRC.jur_prc_fl_encerrado WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Encerrado' 
			END AS ENCERRADO,
		PRC.jur_prc_dt_final                      
	FROM         
		tb_jur_processo PRC INNER JOIN
                      	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE    
	 	PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim 
		AND  FIP.jur_fip_cd_professor <> N'00000'
		AND FIC.jur_fic_fl_processo = 0
		 AND  PRC.jur_prc_fl_recurso = @Pfl_recurso
	UNION
	SELECT     
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao,
		jur_prc_nr_processo,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN 'VARA' 
			WHEN '1' THEN 'T.R.T' 
			WHEN '2' THEN 'T.S.T' 
			WHEN '3' THEN 'S.T.F' 
			WHEN '4' THEN 'VARA' 
			ELSE 'VARA'
			END AS TIPO_RECURSO,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN  PRC.jur_prc_nr_processo
			WHEN '1' THEN PRC.jur_prc_nr_trt 
			WHEN '2' THEN PRC.jur_prc_nr_tst 
			WHEN '3' THEN PRC.jur_prc_nr_stf  
			WHEN '4' THEN PRC.jur_prc_nr_processo 
			ELSE PRC.jur_prc_nr_processo 
			END AS RECURSO,
		CASE 
			PRC.jur_prc_fl_encerrado WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Encerrado' 
			END AS ENCERRADO,
		PRC.jur_prc_dt_final         
	FROM         
		tb_jur_processo PRC INNER JOIN
                      	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE     
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim
		AND   FIP.jur_fip_cd_professor = '00000'
		AND FIC.jur_fic_fl_processo = 1
		AND  PRC.jur_prc_fl_recurso = @Pfl_recurso
END
ELSE IF  @Pfl_situacao=1 AND @Pfl_encerramento='2'   -- Especifico E Selecionando encerramento
BEGIN
	SELECT    
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao,
		jur_prc_nr_processo,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN 'VARA' 
			WHEN '1' THEN 'T.R.T' 
			WHEN '2' THEN 'T.S.T' 
			WHEN '3' THEN 'S.T.F' 
			WHEN '4' THEN 'VARA' 
			ELSE 'VARA'
			END AS TIPO_RECURSO,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN  PRC.jur_prc_nr_processo
			WHEN '1' THEN PRC.jur_prc_nr_trt 
			WHEN '2' THEN PRC.jur_prc_nr_tst 
			WHEN '3' THEN PRC.jur_prc_nr_stf  
			WHEN '4' THEN PRC.jur_prc_nr_processo 
			ELSE PRC.jur_prc_nr_processo 
			END AS RECURSO,
		CASE 
			PRC.jur_prc_fl_encerrado WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Encerrado' 
			END AS ENCERRADO,
		PRC.jur_prc_dt_final                      
	FROM         
		tb_jur_processo PRC INNER JOIN
                      	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE    
	 	PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim 
		AND  FIP.jur_fip_cd_professor <> N'00000'
		AND FIC.jur_fic_fl_processo = 0
	UNION
	SELECT     
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao,
		jur_prc_nr_processo,
			CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN 'VARA' 
			WHEN '1' THEN 'T.R.T' 
			WHEN '2' THEN 'T.S.T' 
			WHEN '3' THEN 'S.T.F' 
			WHEN '4' THEN 'VARA' 
			ELSE 'VARA'
			END AS TIPO_RECURSO,
		CASE 
			PRC.jur_prc_fl_recurso WHEN '0' THEN  PRC.jur_prc_nr_processo
			WHEN '1' THEN PRC.jur_prc_nr_trt 
			WHEN '2' THEN PRC.jur_prc_nr_tst 
			WHEN '3' THEN PRC.jur_prc_nr_stf  
			WHEN '4' THEN PRC.jur_prc_nr_processo 
			ELSE PRC.jur_prc_nr_processo 
			END AS RECURSO,
		CASE 
			PRC.jur_prc_fl_encerrado WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Encerrado' 
			END AS ENCERRADO,
		PRC.jur_prc_dt_final         
	FROM         
		tb_jur_processo PRC INNER JOIN
                      	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE     
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim
		AND   FIP.jur_fip_cd_professor = '00000'
		AND FIC.jur_fic_fl_processo = 1
END
go

