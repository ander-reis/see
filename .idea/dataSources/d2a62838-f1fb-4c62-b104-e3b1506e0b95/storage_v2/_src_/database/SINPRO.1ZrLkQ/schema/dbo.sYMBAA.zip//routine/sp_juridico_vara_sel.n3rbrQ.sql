


/*******************************************************************
Objeto criado: 	 sp_juridico_vara_sel
Descriçao:	Seleciona vara
Data da Criaçao: 22/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_vara_sel

AS

SELECT
	 JCV.jur_cva_cd_vara,
	 JCV.jur_cva_cd_advogado,
	 JCV.jur_cva_ds_vara,
	 JCV.jur_cva_ds_endereco,
	 JCV.jur_cva_ds_numero,
	 JCV.jur_cva_ds_complemento,
	 JCV.jur_cva_nr_fone, 
	JCV.jur_cva_fl_dia_semana,
	CASE  JCV.jur_cva_fl_dia_semana
		WHEN '0' THEN '2ª - Feira'  WHEN '1' THEN '3ª - Feira'  WHEN '2' THEN '4ª - Feira'  WHEN '3' THEN '5ª - Feira'  WHEN '4' THEN '6ª - Feira' END AS SEMANA,
	JCA.jur_adv_nm_advogado
FROM  tb_jur_cadastro_vara JCV INNER JOIN tb_jur_cadastro_advogado JCA ON JCV.jur_cva_cd_advogado = JCA.jur_adv_cd_advogado
ORDER BY JCV.jur_cva_ds_vara

go

