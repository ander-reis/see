/*******************************************************************
Objeto criado: 	 sp_altera_campo
Descriçao:	Altera o Tamanho do Campo criado por User Data Field
Data da Criaçao: 21/05/2015
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_altera_campo
(
@Pds_campo	NVARCHAR(50),
@Psi_tamanho	SMALLINT
)

AS

DECLARE @Vsi_xusertype	SMALLINT

SELECT @Vsi_xusertype = xusertype FROM systypes WHERE name = @Pds_campo


SELECT OBJ.name AS Tabela, COL.name AS Coluna, TYP.name AS Tipo, COL.length / 2 AS Tamanho
FROM systypes TYP
	INNER JOIN syscolumns COL ON TYP.xusertype = COL.xusertype
	INNER JOIN sysobjects OBJ ON COL.id = OBJ.id
WHERE     TYP.name =  @Pds_campo
ORDER BY OBJ.name

UPDATE systypes     SET length = @Psi_tamanho * 2 WHERE xusertype = @Vsi_xusertype

UPDATE syscolumns SET length = @Psi_tamanho * 2 WHERE xusertype = @Vsi_xusertype

/*
		NOME		TIPO		NULO
sp_addtype	 'vl_boleto',	 'decimal(10,2)',	'NOT NULL'
*/
go

