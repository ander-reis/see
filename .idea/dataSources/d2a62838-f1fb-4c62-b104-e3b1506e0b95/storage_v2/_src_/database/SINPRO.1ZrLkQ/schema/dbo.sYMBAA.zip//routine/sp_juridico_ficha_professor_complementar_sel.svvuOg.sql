

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_professor_complementar_sel
Descriçao:	Seleciona Dados Complementares do Professores na Ficha de Consulta 
Data da Criaçao: 02/03/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_professor_complementar_sel
(
@Pnr_ficha		INT,
@Pcd_professor		NVARCHAR(6)
)
AS

SELECT
	CONVERT(CHAR(10),jur_fip_dt_admissao,103) AS jur_fip_dt_admissao,
	CONVERT(CHAR(10),jur_fip_dt_demissao,103) AS jur_fip_dt_demissao,
	jur_fip_ds_ctps,
	jur_fip_ds_ctps_serie,
	jur_fip_ds_funcao,
	CONVERT(DECIMAL(10,2),jur_fip_vl_salario) AS jur_fip_vl_salario,
	jur_fip_fl_pre_escola,
	jur_fip_fl_aulas_14,
	jur_fip_nr_aulas_14,
	jur_fip_fl_aulas_58,
	jur_fip_nr_aulas_58,
	jur_fip_fl_aulas_ens_medio,
	jur_fip_nr_aulas_ens_medio,
	jur_fip_fl_aulas_ens_superior,
	jur_fip_nr_aulas_ens_superior,
	jur_fip_fl_aulas_tecnico,
	jur_fip_nr_aulas_tecnico,
	jur_fip_fl_aulas_supletivo,
	jur_fip_nr_aulas_supletivo,
	jur_fip_fl_aulas_curso_livre,
	jur_fip_nr_aulas_curso_livre
FROM
	tb_jur_ficha_professor
WHERE
	jur_fip_nr_ficha = @Pnr_ficha
	AND jur_fip_cd_professor = @Pcd_professor

go

