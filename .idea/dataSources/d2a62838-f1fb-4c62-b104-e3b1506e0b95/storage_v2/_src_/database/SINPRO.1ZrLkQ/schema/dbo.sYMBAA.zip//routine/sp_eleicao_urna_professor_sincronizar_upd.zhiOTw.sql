/*******************************************************************
Objeto criado: 	 sp_eleicao_urna_professor_sincronizar_upd
Descriçao:	Sincroniza os professores que já votaram
Data da Criaçao: 04/07/2014
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_urna_professor_sincronizar_upd
(
@Pnr_urna		SMALLINT = 0,
@Pds_cnpj		VARCHAR(8000) = ';',
@Pcd_professor		VARCHAR(8000) = ';',
@Pfl_votar		VARCHAR(6000) = ';'
)
AS

DECLARE @Vds_matricula	VARCHAR(10)
DECLARE @Vnr_posicao	INT
DECLARE @Vnr_tamanho	INT
DECLARE @Vfl_achou	 	TINYINT


DECLARE @Vnr_posicao_cnpj	INT
DECLARE @Vnr_tamanho_cnpj	INT
DECLARE @Vds_cnpj		VARCHAR(18)

DECLARE @Vnr_posicao_votar	INT
DECLARE @Vnr_tamanho_votar	INT
DECLARE @Vfl_votar		VARCHAR(1)

BEGIN 
	WHILE NOT LTRIM(RTRIM(@Pcd_professor)) = ''
	BEGIN
		
		SET @Vnr_posicao = CHARINDEX(';', @Pcd_professor)
		IF @Vnr_posicao <> 0
		BEGIN

			SET @Vnr_tamanho = LEN(@Pcd_professor)
			SET @Vds_matricula = SUBSTRING(@Pcd_professor, 1, @Vnr_posicao - 1)

			SET @Vnr_posicao_cnpj = CHARINDEX(';', @Pds_cnpj)
			SET @Vnr_tamanho_cnpj = LEN(@Pds_cnpj)
			
			SET @Vnr_posicao_votar = CHARINDEX(';', @Pfl_votar)
			SET @Vnr_tamanho_votar = LEN(@Pfl_votar)
			SET @Vfl_votar = SUBSTRING(@Pfl_votar, 1, @Vnr_posicao_votar - 1)
			
			IF SUBSTRING(@Pds_cnpj, 1, @Vnr_posicao_cnpj - 1) <> ''
			BEGIN
				SET @Vds_cnpj = SUBSTRING(@Pds_cnpj, 1, @Vnr_posicao_cnpj - 1)
			END

			IF @Vds_matricula <> ''
			BEGIN
				SET @Vds_matricula = RIGHT('00000' + @Vds_matricula,5)

				SET @Vfl_achou = 0

				SELECT @Vfl_achou = 1 FROM  tb_eleicao_urna_professor_sincronizar WHERE ele_ups_cd_professor =  @Vds_matricula AND ele_ups_nr_urna = @Pnr_urna AND ele_ups_ds_eleicao = '2018'
				
				IF @Vfl_achou <> 1
					INSERT INTO tb_eleicao_urna_professor_sincronizar (ele_ups_ds_eleicao, ele_ups_cd_professor, ele_ups_nr_urna, ele_ups_ds_cnpj, ele_ups_fl_votar) VALUES ('2018', @Vds_matricula,@Pnr_urna, @Vds_cnpj, CONVERT(TINYINT,@Vfl_votar))
			END
			
			--Recorta string
			SET @Pcd_professor = SUBSTRING(@Pcd_professor, @Vnr_posicao+1, @Vnr_tamanho - (@Vnr_posicao))
			SET @Pds_cnpj         = SUBSTRING(@Pds_cnpj, @Vnr_posicao_cnpj+1, @Vnr_tamanho_cnpj - (@Vnr_posicao_cnpj))
			SET @Pfl_votar          = SUBSTRING(@Pfl_votar, @Vnr_posicao_votar+1, @Vnr_tamanho_votar - (@Vnr_posicao_votar))
		END								
	END

	SELECT ele_ups_cd_professor AS mt FROM tb_eleicao_urna_professor_sincronizar WHERE  ele_ups_nr_urna <> @Pnr_urna AND ele_ups_dt_voto > (SELECT ele_urs_dt_atual FROM tb_eleicao_urna_status_sinc WHERE ele_urs_nr_urna = @Pnr_urna)

	UPDATE tb_eleicao_urna_status_sinc SET ele_urs_dt_atual = GETDATE() WHERE ele_urs_nr_urna = @Pnr_urna
END
go

