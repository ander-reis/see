/*******************************************************************
Objeto criado: 	 sp_homologacao_imagem_ins
Descriçao:	Cadastra as Imagens do Cadatro do homologacao
Data da Criaçao: 16/10/2008
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_homologacao_imagem_ins
(
@Pcd_imagem		INT,
@Pcd_homologacao		NVARCHAR(6),
@Pds_arquivo		NVARCHAR(300),
@Pds_observacao	NVARCHAR(600),
@Pdt_cadastro		DATETIME,
@Pnm_login		NVARCHAR(30)
)

AS

IF @Pcd_imagem = 0  
	INSERT INTO tb_homologacao_imagem
		(hom_img_cd_homologacao,
		hom_img_ds_arquivo,
		hom_img_ds_observacao,
		hom_img_dt_cadastro,
		hom_img_nm_login)
	VALUES
		(@Pcd_homologacao,
		@Pds_arquivo,
		@Pds_observacao,
		@Pdt_cadastro,
		@Pnm_login)
ELSE
	UPDATE tb_homologacao_imagem SET
		hom_img_ds_arquivo	= @Pds_arquivo,
		hom_img_ds_observacao	= @Pds_observacao,
		hom_img_dt_cadastro	= @Pdt_cadastro, 
		hom_img_nm_login	= @Pnm_login
	WHERE
		hom_img_cd_imagem = @Pcd_imagem
go

