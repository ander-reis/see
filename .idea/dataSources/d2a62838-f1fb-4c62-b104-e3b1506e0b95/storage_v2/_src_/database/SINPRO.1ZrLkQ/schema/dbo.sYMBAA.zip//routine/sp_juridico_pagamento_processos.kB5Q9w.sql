/*******************************************************************
Objeto criado: 	 sp_juridico_pagamento_processos
Descriçao:	Seleciona Todos os Processos que tiveram problema em serem enviados para o Financeiro
Data da Criaçao: 15/09/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_pagamento_processos
AS
SELECT     jur_pcf_nr_pagamento, jur_pcf_nr_pasta, jur_pcf_dt_vencimento, jur_pcf_fl_siga
FROM         tb_jur_processo_financeiro
WHERE     (jur_pcf_fl_siga IN (N'', N'1', N'3', N'4', N'6')) AND (jur_pcf_ds_titulo <> N'HONORARIOS')

/*
 SELECT 
	JPP.nr_pagamento, JPP.Codigo_Processo, 
	'REP ' + 
	CASE WHEN LEN(RTRIM(JCP.Numero_Processo)) < 9 THEN JCP.Numero_Processo ELSE SUBSTRING(JCP.Numero_Processo, 1, 5) + '/' + SUBSTRING(JCP.Numero_Processo, 8, 2) END + ' PARC ' + JPP.nr_parcelas  + ' ' + CE.Nome_Fantasia AS Historico,
	CASE WHEN LEN(RTRIM(JCP.Numero_Processo)) < 9 THEN JCP.Numero_Processo ELSE SUBSTRING(JCP.Numero_Processo, 1, 5) + '/' + SUBSTRING(JCP.Numero_Processo, 8, 2) END AS nr_processo, 
	JPP1.PARCELAS, JPP.nr_parcelas, CONVERT(CHAR(8),JPP.dt_vencimento,112) dt_vencimento, 
	JPP.vl_parcelas, JPP.vl_honorario, JPP.vl_taxa, JPP.nr_taxa, JPP.Titulo, 
	JPP.Observacao, JPP.fl_situacao, CONVERT(CHAR(8), GETDATE(), 112) AS dt_emissao,
	CP.Nome, CP.Banco, CP.Agencia, CP.Conta, CP.Poupanca, CP.Conjunta, CP.CPF, CE.Nome_Fantasia
FROM SINPRO.dbo.JCadastro_Ficha_Processo JCFP 
	INNER JOIN SINPRO.dbo.JCadastro_Processos JCP ON JCFP.Codigo_Processo = JCP.Codigo_Processo 
	INNER JOIN SINPRO.dbo.JCadastro_Ficha_Consulta JCFC ON JCFP.Numero_Ficha = JCFC.Numero_Ficha 
	INNER JOIN SINPRO.dbo.Cadastro_Professores CP ON JCFC.Codigo_Professor = CP.Codigo_Professor 
	INNER JOIN SINPRO.dbo.JProcesso_Pagamento JPP ON JCP.Codigo_Processo = JPP.Codigo_Processo 
	INNER JOIN SINPRO.dbo.Cadastro_Escolas CE ON JCFC.CNPJ_Escola = CE.CGC_Escola 
	INNER JOIN  (SELECT JPP.Codigo_Processo, Count(1) AS PARCELAS 
			FROM SINPRO.dbo.JCadastro_Processos JCP 
				INNER JOIN SINPRO.dbo.JProcesso_Pagamento JPP ON JCP.Codigo_Processo = JPP.Codigo_Processo 
				WHERE JCP.fl_financeiro = ' '  AND JPP.fl_situacao <> 5 AND JPP.Titulo = '' 
				GROUP BY JPP.Codigo_Processo ) AS JPP1 ON JPP.Codigo_Processo = JPP1.Codigo_Processo 
WHERE
	JCP.fl_financeiro IN ('',1) AND JPP.fl_situacao <> 5 AND JPP.Titulo = ''
ORDER BY JPP.Codigo_Processo, CONVERT(CHAR(8), dt_vencimento, 112)
*/
go

