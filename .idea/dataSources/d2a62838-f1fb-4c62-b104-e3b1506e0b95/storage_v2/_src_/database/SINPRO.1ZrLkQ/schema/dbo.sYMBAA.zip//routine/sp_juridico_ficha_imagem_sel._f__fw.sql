/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_imagem_sel
Descriçao:	Seleciona as Imagens da Ficha de Consulta
Data da Criaçao: 13/03/2014
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_imagem_sel
(
@Pnr_ficha	INT
)
AS


SELECT
	IMG.jur_img_cd_imagem,
	IMG.jur_img_ds_arquivo,
	IMG.jur_img_ds_observacao,
	CONVERT(NVARCHAR(10), IMG.jur_img_dt_cadastro,103) AS jur_img_dt_cadastro,
	IMG.jur_img_nm_login,
	CONVERT(NVARCHAR(8),IMG.jur_img_dt_cadastro,108) AS jur_img_hr_cadastro
FROM
	tb_jur_ficha_imagem IMG
WHERE
	IMG.jur_img_nr_ficha = @Pnr_ficha
ORDER BY
	CONVERT(CHAR(10),IMG.jur_img_dt_cadastro,111) DESC,
	CONVERT(NVARCHAR(8),IMG.jur_img_dt_cadastro,108) DESC
go

