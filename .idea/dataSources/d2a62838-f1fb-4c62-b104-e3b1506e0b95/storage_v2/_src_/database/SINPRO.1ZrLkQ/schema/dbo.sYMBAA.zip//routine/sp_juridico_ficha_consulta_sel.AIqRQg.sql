/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_consulta_sel
Descriçao:	Seleciona a Ficha de Consulta
Data da Criaçao: 02/03/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_consulta_sel
(
@Pnr_ficha		INT
)
AS

SELECT
	CONVERT(CHAR(10),FIC.jur_fic_dt_cadastro,103) AS jur_fic_dt_cadastro,
	FIC.jur_fic_nm_login,
	FIC.jur_fic_cd_cnpj,
	FIC.jur_fic_cd_advogado,
	ISNULL(ADV.jur_adv_nm_advogado,'') AS jur_adv_nm_advogado,
	FIC.jur_fic_fl_honorario,
	FIC.jur_fic_fl_status,
	FIC.jur_fic_ds_01,
	FIC.jur_fic_ds_02,
	FIC.jur_fic_ds_03,
	FIC.jur_fic_ds_04,
	FIC.jur_fic_ds_05,
	FIC.jur_fic_fl_categoria,
	FIC.jur_fic_fl_testemunha,
	FIC.jur_fic_fl_ctps,
	FIC.jur_fic_fl_fgts,
	FIC.jur_fic_fl_desemprego,
	FIC.jur_fic_fl_processo,
	FIC.jur_fic_nr_pasta,
	FIC.jur_fic_ds_testemunha,
	CONVERT(DECIMAL(10,2),FIC.jur_fic_vl_causa) AS jur_fic_vl_causa,
	ISNULL(IRJ.coddenuncia, '') AS coddenuncia
FROM
	tb_jur_ficha_consulta AS FIC
	LEFT OUTER JOIN Irr_Juridico IRJ ON FIC.jur_fic_nr_ficha = IRJ.nr_ficha
	LEFT OUTER JOIN tb_jur_cadastro_advogado AS ADV ON FIC.jur_fic_cd_advogado = ADV.jur_adv_cd_advogado
WHERE
	FIC.jur_fic_nr_ficha = @Pnr_ficha
go

