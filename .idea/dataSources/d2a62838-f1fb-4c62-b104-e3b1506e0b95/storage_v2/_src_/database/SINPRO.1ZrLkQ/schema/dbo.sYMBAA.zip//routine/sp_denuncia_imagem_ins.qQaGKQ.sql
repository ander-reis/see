/*******************************************************************
Objeto criado: 	 sp_denuncia_imagem_ins
Descriçao:	Cadastra as Imagens da Denuncia
Data da Criaçao: 09/08/2011
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_denuncia_imagem_ins
(
@Pcd_imagem		INT,
@Pcd_denuncia	NVARCHAR(10),
@Pds_arquivo		NVARCHAR(300),
@Pds_observacao	NVARCHAR(600),
@Pdt_cadastro		DATETIME,
@Pnm_login		NVARCHAR(30)
)

AS

IF @Pcd_imagem = 0  
	INSERT INTO tb_denuncia_imagem
		(den_img_cd_denuncia,
		den_img_ds_arquivo,
		den_img_ds_observacao,
		den_img_dt_cadastro,
		den_img_nm_login)
	VALUES
		(@Pcd_denuncia,
		@Pds_arquivo,
		@Pds_observacao,
		@Pdt_cadastro,
		@Pnm_login)
ELSE
	UPDATE tb_denuncia_imagem SET
		den_img_ds_arquivo	= @Pds_arquivo,
		den_img_ds_observacao	= @Pds_observacao,
		den_img_dt_cadastro	= @Pdt_cadastro, 
		den_img_nm_login	= @Pnm_login
	WHERE
		den_img_cd_imagem = @Pcd_imagem
go

