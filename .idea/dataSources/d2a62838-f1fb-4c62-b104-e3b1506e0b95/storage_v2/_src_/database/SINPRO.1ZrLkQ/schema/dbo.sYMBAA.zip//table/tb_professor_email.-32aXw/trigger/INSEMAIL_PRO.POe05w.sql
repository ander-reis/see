

CREATE TRIGGER [INSEMAIL_PRO] ON [dbo].[tb_professor_email] 
FOR INSERT

AS
DECLARE @Vcd_professor 		VARCHAR(5)
DECLARE @Vnm_professor 		VARCHAR(150)
DECLARE @Vds_cpf	 		VARCHAR(14)
DECLARE @Vds_email1 		VARCHAR(120)
DECLARE @Vds_email2 		VARCHAR(120)
DECLARE @Vds_email3 		VARCHAR(120)
DECLARE @Vds_email_achou 		VARCHAR(120)
DECLARE @Vfl_achou	 		INT
DECLARE @Vcd_situacao	INT

DECLARE CurEmail_SAS_INS CURSOR LOCAL FAST_FORWARD FOR
SELECT INS.pro_ema_cd_professor, Nome, CPF, Situacao, INS.pro_ema_ds_email1, INS.pro_ema_ds_email2, INS.pro_ema_ds_email3
	FROM Inserted INS INNER JOIN Cadastro_Professores CP ON INS.pro_ema_cd_professor = CP.Codigo_Professor
	WHERE SUBSTRING(INS.pro_ema_cd_professor,1,1) <> 'N'

--Abrindo cursor
OPEN CurEmail_SAS_INS

--Buscando registro
FETCH NEXT FROM CurEmail_SAS_INS INTO @Vcd_professor, @Vnm_professor, @Vds_cpf, @Vcd_situacao, @Vds_email1, @Vds_email2, @Vds_email3

--Laço do cursor
WHILE @@FETCH_STATUS = 0
BEGIN
	IF @Vcd_situacao = 4 OR @Vcd_situacao = 8
	BEGIN	
		SET @Vcd_professor = '00000'
		SET @Vcd_situacao = 0
	END
	ELSE
	BEGIN
		SET @Vcd_situacao = 1
	END

	-- Email 1
	SET @Vfl_achou = 0
	SELECT @Vfl_achou = id_email, @Vds_email_achou = ds_email FROM website.dbo.tb_sinpro_email_boletim 
		WHERE ds_email = @Vds_email1 

	IF @Vfl_achou <> 0 
	BEGIN
		UPDATE website.dbo.tb_sinpro_email_boletim SET 
			num_matricula = '0' + @Vcd_professor, num_cpf = @Vds_cpf, ds_nome = @Vnm_professor, opt_perg_a = 0, opt_perg_b = 0, opt_perg_c = 1, opt_resp_c = 'SAS' ,fl_tipo = @Vcd_situacao 
		WHERE id_email = @Vfl_achou
	END
	ELSE
	BEGIN
		INSERT INTO website.dbo.tb_sinpro_email_boletim (num_matricula, num_cpf,ds_nome,ds_email,opt_perg_a, opt_perg_b, opt_perg_c, opt_resp_c, dt_cadastro, dt_alteracao, fl_tipo, fl_status, num_ip) VALUES (
                    		'0' + @Vcd_professor, @Vds_cpf, @Vnm_professor, @Vds_email1, 0,0,1,'SAS', GETDATE(), GETDATE(), @Vcd_situacao,1,'192.168.0.0')
	END

	--Email2
	IF @Vds_email2 <> ''
	BEGIN
		SET @Vfl_achou = 0
		SELECT @Vfl_achou = id_email, @Vds_email_achou = ds_email FROM website.dbo.tb_sinpro_email_boletim 
			WHERE ds_email = @Vds_email2

		IF @Vfl_achou <> 0 
		BEGIN
			UPDATE website.dbo.tb_sinpro_email_boletim SET 
				num_matricula = '0' + @Vcd_professor, num_cpf = @Vds_cpf, ds_nome = @Vnm_professor, opt_perg_a = 0, opt_perg_b = 0, opt_perg_c = 1, opt_resp_c = 'SAS' ,fl_tipo = @Vcd_situacao 
			WHERE id_email = @Vfl_achou
		END
		ELSE
		BEGIN
			INSERT INTO website.dbo.tb_sinpro_email_boletim (num_matricula, num_cpf,ds_nome,ds_email,opt_perg_a, opt_perg_b, opt_perg_c, opt_resp_c, dt_cadastro, dt_alteracao, fl_tipo, fl_status, num_ip) VALUES (
             	       			'0' + @Vcd_professor, @Vds_cpf, @Vnm_professor, @Vds_email2, 0,0,1,'SAS', GETDATE(), GETDATE(), @Vcd_situacao,1,'192.168.0.0')
		END
	END

	--Email3
	IF @Vds_email3 <> ''
	BEGIN
		SET @Vfl_achou = 0
		SELECT @Vfl_achou = id_email, @Vds_email_achou = ds_email FROM website.dbo.tb_sinpro_email_boletim 
			WHERE ds_email = @Vds_email3

		IF @Vfl_achou <> 0 
		BEGIN
			UPDATE website.dbo.tb_sinpro_email_boletim SET 
				num_matricula = '0' + @Vcd_professor, num_cpf = @Vds_cpf, ds_nome = @Vnm_professor, opt_perg_a = 0, opt_perg_b = 0, opt_perg_c = 1, opt_resp_c = 'SAS' ,fl_tipo = @Vcd_situacao 
			WHERE id_email = @Vfl_achou
		END
		ELSE
		BEGIN
			INSERT INTO website.dbo.tb_sinpro_email_boletim (num_matricula, num_cpf,ds_nome,ds_email,opt_perg_a, opt_perg_b, opt_perg_c, opt_resp_c, dt_cadastro, dt_alteracao, fl_tipo, fl_status, num_ip) VALUES (
                    			'0' + @Vcd_professor, @Vds_cpf, @Vnm_professor, @Vds_email2, 0,0,1,'SAS', GETDATE(), GETDATE(), @Vcd_situacao,1,'192.168.0.0')
		END
	END

FETCH NEXT FROM CurEmail_SAS_INS INTO @Vcd_professor, @Vnm_professor, @Vds_cpf, @Vcd_situacao, @Vds_email1, @Vds_email2, @Vds_email3
END

--Fechando e desalocando cursor
CLOSE CurEmail_SAS_INS
DEALLOCATE CurEmail_SAS_INS



go

