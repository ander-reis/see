/*******************************************************************
Objeto criado: 	 sp_materia_sel
Descriçao:	Seleciona as Materias
Data da Criaçao: 30/11/2015
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_materia_sel
AS

SELECT     Codigo_Materia, Materia
FROM         Materia
ORDER BY Materia
go

