

/*******************************************************************
Objeto criado: 	 sp_eleicao_data_sel
Descriçao:	Seleciona Votos na Eleicao
Data da Criaçao: 03/07/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_data_sel
(
@Pds_eleicao		CHAR(4)
)
AS

SELECT 
	CONVERT(CHAR(10),ele_edt_dt_eleicao1,103) AS ele_edt_dt_eleicao1, 
	CONVERT(CHAR(10),ele_edt_dt_eleicao2,103) AS ele_edt_dt_eleicao2, 
	CONVERT(CHAR(10),ele_edt_dt_eleicao3,103) AS ele_edt_dt_eleicao3
FROM tb_ele_datas
WHERE ele_edt_ds_eleicao = @Pds_eleicao


go

