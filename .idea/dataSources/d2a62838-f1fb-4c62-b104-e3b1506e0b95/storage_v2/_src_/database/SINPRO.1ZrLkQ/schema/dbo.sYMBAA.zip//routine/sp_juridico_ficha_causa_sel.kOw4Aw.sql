

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_causa_sel
Descriçao:	Seleciona causa da Ficha de Consulta
Data da Criaçao: 02/03/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_causa_sel
(
@Pnr_ficha 	INT
)
AS

SELECT     
	FCA.jur_fca_cd_causa,
	CAU.jur_cau_ds_causa,
	FCA.jur_fca_nm_login,
	CONVERT(CHAR(10),FCA.jur_fca_dt_cadastro,103) AS jur_fca_dt_cadastro,
	CASE CAU.jur_cau_fl_testemunha
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS jur_cau_fl_testemunha
FROM
	tb_jur_ficha_causa FCA INNER JOIN
	tb_jur_cadastro_causa CAU ON FCA.jur_fca_cd_causa = CAU.jur_cau_cd_causa
WHERE     
	FCA.jur_fca_nr_ficha = @Pnr_ficha
ORDER BY 
	CAU.jur_cau_ds_causa
go

