
/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_email_sel
Descriçao:	Seleciona os EMails do Professor
Data da Criaçao: 28/05/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_email_sel
(
@Pcd_professor		NVARCHAR(6)
)
AS

SELECT 
CASE   WHEN LEN(ISNULL(pro_ema_ds_email1,'')) <> 0 THEN pro_ema_ds_email1 + ';' ELSE '' END 
	         + CASE WHEN  LEN(ISNULL(pro_ema_ds_email2,'')) <> 0 THEN  pro_ema_ds_email2 + ';' ELSE '' END
	         + CASE WHEN  LEN(ISNULL(pro_ema_ds_email3,'')) <> 0 THEN  pro_ema_ds_email3 + ';' ELSE '' END AS Email
FROM tb_professor_email
WHERE pro_ema_cd_professor = @Pcd_professor


/*SELECT 
LEFT(CASE   WHEN LEN(ISNULL(pro_ema_ds_email1,'')) <> 0 THEN pro_ema_ds_email1 + ';' ELSE '' END 
	         + CASE WHEN  LEN(ISNULL(pro_ema_ds_email2,'')) <> 0 THEN  pro_ema_ds_email2 + ';' ELSE '' END
	         + CASE WHEN  LEN(ISNULL(pro_ema_ds_email3,'')) <> 0 THEN  pro_ema_ds_email3 + ';' ELSE '' END,
	         LEN(CASE   WHEN  LEN(ISNULL(pro_ema_ds_email1,'')) <> 0 THEN  pro_ema_ds_email1 + ';' ELSE '' END
	         + CASE WHEN  LEN(ISNULL(pro_ema_ds_email2,'')) <> 0 THEN  pro_ema_ds_email2 + ';' ELSE '' END
	         + CASE WHEN  LEN(ISNULL(pro_ema_ds_email3,'')) <> 0 THEN  pro_ema_ds_email3 + ';' ELSE '' END) -1) AS Email
FROM tb_professor_email
WHERE pro_ema_cd_professor = @Pcd_professor
*/





/*
SELECT 
	LEFT(CASE   WHEN RTRIM(ISNULL(pro_ema_ds_email1,'')) <> '' THEN RTRIM(ISNULL(pro_ema_ds_email1,'')) + ';' ELSE ';' END 
	         + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
	         + CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END,
	         LEN(CASE   WHEN  RTRIM(ISNULL(pro_ema_ds_email1,'')) <> '' THEN  RTRIM(ISNULL(pro_ema_ds_email1,'')) + ';' ELSE ';' END
	         + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
	         + CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END) -1) AS Email
FROM tb_professor_email
WHERE pro_ema_cd_professor = @Pcd_professor
*/
go

