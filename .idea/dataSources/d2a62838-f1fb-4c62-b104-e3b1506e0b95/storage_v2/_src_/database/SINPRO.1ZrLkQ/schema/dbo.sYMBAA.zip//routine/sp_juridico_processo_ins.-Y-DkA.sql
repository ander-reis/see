

/*******************************************************************
Objeto criado: 	 sp_juridico_processo_ins
Descriçao:	Cadastra o Processo
Data da Criaçao: 04/07/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_ins
(
@Pnr_pasta		NVARCHAR(8) OUTPUT,
@Pcd_vara		INT,
@Pcd_advogado	INT,
@Pnr_ficha		INT,
@Pnr_processo		NVARCHAR(20),
@Pnr_trt		NVARCHAR(20),
@Pnr_tst		NVARCHAR(30),
@Pnr_stf		NVARCHAR(20),
@Pfl_situacao		TINYINT,
@Pfl_recurso		TINYINT,
@Pfl_rec_execucao	TINYINT = 0,
@Pfl_execucao		TINYINT,
@Pfl_exe_contador	TINYINT,
@Pfl_encerrado		TINYINT,
@Pfl_procedente	TINYINT,
@Pdt_distribuicao	DATETIME,
@Pdt_final		DATETIME,
@Pnr_morto		NVARCHAR(9),
@Pnm_login		NVARCHAR(30),
@Pcd_terceiro		INT,
@Pfl_rescisoria		TINYINT = 0,
@Pnr_trt_rescisoria	NVARCHAR(17) = '',
@Pfl_desarquivado	TINYINT = 0,
@Pvl_homologado	DECIMAL(10,2) = 0,
@Pfl_embargos		TINYINT = 0,
@Pfl_darf		TINYINT = 0,
@Pfl_greve		TINYINT = 0,
@Pfl_pje		TINYINT = 0
)

AS

IF @Pnr_pasta = ''
BEGIN
	DECLARE @Vcd_pasta		INT

	EXEC sp_codigo_ins 'codprocesso', @Vcd_pasta OUTPUT

	SET @Pnr_pasta = REPLICATE('0', 3 - LEN(CONVERT(NVARCHAR(3),@Vcd_pasta))) + CONVERT(NVARCHAR(3),@Vcd_pasta) + '/' + CONVERT(NVARCHAR(4),YEAR(GETDATE()))

	INSERT INTO tb_jur_processo
		(jur_prc_nr_pasta,
		jur_prc_cd_vara,
		jur_prc_cd_advogado,
		jur_prc_nr_ficha,
		jur_prc_nr_processo,
		jur_prc_nr_trt,
		jur_prc_nr_tst,
		jur_prc_nr_stf,
		jur_prc_fl_situacao, 
		jur_prc_fl_recurso,
		jur_prc_fl_rec_execucao,
		jur_prc_fl_execucao,
		jur_prc_fl_exe_contador,
		jur_prc_fl_encerrado,
		jur_prc_fl_procedente,
		jur_prc_dt_distribuicao, 
		jur_prc_dt_final,
		jur_prc_nr_morto,
		jur_prc_dt_cadastro,
		jur_prc_nm_login,
		jur_prc_cd_terceiro,
		jur_prc_fl_rescisoria,
		jur_prc_nr_trt_rescisoria,
		jur_prc_fl_desarquivado,
		jur_prc_vl_homologado,
		jur_prc_fl_embargos,
		jur_prc_fl_darf,
		jur_prc_fl_greve,
		jur_prc_fl_pje)
	VALUES     (
		@Pnr_pasta,
		@Pcd_vara,
		@Pcd_advogado,
		@Pnr_ficha,
		@Pnr_processo,
		@Pnr_trt,
		@Pnr_tst,
		@Pnr_stf,
		@Pfl_situacao,
		@Pfl_recurso,
		@Pfl_rec_execucao,
		@Pfl_execucao,
		@Pfl_exe_contador,
		@Pfl_encerrado,
		@Pfl_procedente,
		@Pdt_distribuicao,
		@Pdt_final,
		@Pnr_morto,
		GETDATE(),
		@Pnm_login,
		@Pcd_terceiro,
		@Pfl_rescisoria,
		@Pnr_trt_rescisoria,
		@Pfl_desarquivado,
		@Pvl_homologado,
		@Pfl_embargos,
		@Pfl_darf,
		@Pfl_greve,
		@Pfl_pje)

	-- Atualizar o Status na Ficha de Consulta
	UPDATE tb_jur_ficha_consulta SET
		jur_fic_fl_status = 10,
		jur_fic_nr_pasta = @Pnr_pasta
	WHERE 
		jur_fic_nr_ficha = @Pnr_ficha

	DECLARE @Vdt_cadastro	DATETIME
	SET @Vdt_cadastro = GETDATE()
	-- Atualizar a Data de Alteração do Status da Ficha de Consulta
	EXEC  sp_juridico_ficha_status_upd
		@Pnr_ficha,
		@Vdt_cadastro,
		10
	-- Gravar a Observação na Ficha de Consulta
	DECLARE @Vhr_cadastro	DATETIME
	SET @Vhr_cadastro = CONVERT(NVARCHAR(8),GETDATE(),108)
	EXEC sp_juridico_ficha_observacao_ins
 		@Pnr_ficha,
		@Vdt_cadastro,
		@Vhr_cadastro,
		@Pnm_login,
		'ALTERADO O STATUS DA FICHA PARA: PROCESSO INICIADO'

	--Atualizar dados da Denúncia que gerou o Processo
	UPDATE Irr_Juridico SET
		nr_pasta = @Pnr_pasta,
		data_pasta = GETDATE(),
		fl_email = 1
	WHERE
		nr_ficha = @Pnr_ficha

	DECLARE @Vnm_advogado NVARCHAR(100)
	SELECT @Vnm_advogado = jur_adv_nm_advogado FROM tb_jur_cadastro_advogado WHERE jur_adv_cd_advogado = @Pcd_advogado

	DECLARE @Vcd_denuncia NVARCHAR(9)
	SELECT @Vcd_denuncia = coddenuncia FROM Irr_Juridico WHERE nr_ficha = @Pnr_ficha
	
	DECLARE @VOBS NVarchar(500)
	SET @VOBS = 'PROCESSO INICIADO EM: ' + CONVERT(CHAR(10),GETDATE(),111) + '. PASTA Nº ' + @Pnr_pasta + ' - ADVOGADO RESPONSÁVEL: ' + @Vnm_advogado
	INSERT INTO Irr_Observacao (CodDenuncia,Data,Hora,Login,Observacao) VALUES(@Vcd_denuncia, CONVERT(CHAR(10),GETDATE(),111),CONVERT(CHAR(8),GETDATE(),108),@Pnm_login, @VOBS)

END
ELSE
	UPDATE    tb_jur_processo SET
		jur_prc_cd_vara		= @Pcd_vara,
		jur_prc_cd_advogado	= @Pcd_advogado,
		jur_prc_nr_ficha		= @Pnr_ficha,
		jur_prc_nr_processo	= @Pnr_processo,
		jur_prc_nr_trt		= @Pnr_trt,
		jur_prc_nr_tst		= @Pnr_tst,
		jur_prc_nr_stf		= @Pnr_stf,
		jur_prc_fl_situacao	= @Pfl_situacao,
		jur_prc_fl_recurso	= @Pfl_recurso,
		jur_prc_fl_rec_execucao	= @Pfl_rec_execucao,
		jur_prc_fl_execucao	= @Pfl_execucao,
		jur_prc_fl_exe_contador	= @Pfl_exe_contador,
		jur_prc_fl_encerrado	= @Pfl_encerrado,
		jur_prc_fl_procedente	= @Pfl_procedente,
		jur_prc_dt_distribuicao	= @Pdt_distribuicao,
		jur_prc_dt_final		= @Pdt_final,
		jur_prc_nr_morto		= @Pnr_morto,
		jur_prc_cd_terceiro	= @Pcd_terceiro,
		jur_prc_fl_rescisoria	= @Pfl_rescisoria,
		jur_prc_nr_trt_rescisoria	= @Pnr_trt_rescisoria,
		jur_prc_fl_desarquivado  = @Pfl_desarquivado,
		jur_prc_vl_homologado	= @Pvl_homologado,
		jur_prc_fl_embargos	= @Pfl_embargos,
		jur_prc_fl_darf		= @Pfl_darf,
		jur_prc_fl_greve		= @Pfl_greve,
		jur_prc_fl_pje		= @Pfl_pje
	WHERE
		jur_prc_nr_pasta		= @Pnr_pasta
go

