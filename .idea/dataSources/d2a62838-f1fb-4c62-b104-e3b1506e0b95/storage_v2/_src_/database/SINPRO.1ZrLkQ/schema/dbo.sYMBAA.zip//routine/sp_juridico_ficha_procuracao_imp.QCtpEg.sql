

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_procuracao_imp
Descriçao:	Seleciona os advogado para Impressão da Procuração
Data da Criaçao: 03/04/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_procuracao_imp

AS

SELECT
	jur_adv_nm_advogado AS advogado, 

	CASE jur_adv_fl_sexo 
		WHEN 0 THEN 'brasileiro'
		ELSE 'brasileira'
	END + ', ' +

	CASE jur_adv_fl_civil
		WHEN 0 THEN CASE jur_adv_fl_sexo WHEN 0 THEN 'casado'     ELSE 'casada'     END
		WHEN 1 THEN CASE jur_adv_fl_sexo WHEN 0 THEN 'divorciado' ELSE 'divorciada' END
		WHEN 2 THEN CASE jur_adv_fl_sexo WHEN 0 THEN 'separado'   ELSE 'separada'   END
		WHEN 3 THEN CASE jur_adv_fl_sexo WHEN 0 THEN 'solteiro'   ELSE 'solteira'   END
		WHEN 4 THEN CASE jur_adv_fl_sexo WHEN 0 THEN 'viúvo'      ELSE 'viúva'      END
		ELSE 'outros'
	END + ', ' +

	CASE jur_adv_fl_cargo
		WHEN 0 THEN CASE jur_adv_fl_sexo WHEN 0 THEN 'estagiário'	ELSE 'estagiária' END
		WHEN 1 THEN CASE jur_adv_fl_sexo WHEN 0 THEN 'advogado'		ELSE 'advogada'   END
	END + ', ' +

	CASE jur_adv_fl_sexo 
		WHEN 0 THEN 'inscrito na OAB/' + jur_adv_ds_uf_oab + ' sob nº ' + jur_adv_nr_oab
		ELSE 'inscrita na OAB/' + jur_adv_ds_uf_oab + ' sob nº ' + jur_adv_nr_oab
	END + ' e ' +

	'CPF nº ' + jur_adv_ds_cpf AS detalhe

FROM
	tb_jur_cadastro_advogado
WHERE
	jur_adv_fl_procuracao = 1
ORDER BY
	jur_adv_cd_advogado

go

