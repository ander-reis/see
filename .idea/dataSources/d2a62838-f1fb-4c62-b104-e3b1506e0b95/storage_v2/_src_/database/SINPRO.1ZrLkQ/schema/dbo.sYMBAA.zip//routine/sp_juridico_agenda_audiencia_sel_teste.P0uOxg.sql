/*******************************************************************
Objeto criado: 	 sp_juridico_agenda_audiencia_sel
Descriçao:	Seleciona Agenda e Audiencias do Dia
Data da Criaçao: 05/09/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_agenda_audiencia_sel_teste
(
@Pdt_de		VARCHAR(8),
@Pdt_ate		VARCHAR(8),
--@Pds_cpf		NVARCHAR(14)
@Pcd_tipo		INT,
@Pcd_advogado	INT
)
AS

IF @Pcd_advogado <> 99 --Especifico
BEGIN
	IF @Pcd_tipo=0  -- Audiência
		SELECT     
			AUD.jur_aud_cd_audiencia AS CodAdvAgenda, 
			CONVERT(CHAR(5), AUD.jur_aud_hr_audiencia, 108)  AS Hora_Agenda, 
			'NÃO' AS Compareceu, 
			CONVERT(CHAR(10), AUD.jur_aud_dt_audiencia, 103) AS Data_Agenda, 
			AUD.jur_aud_nr_pasta + ' - ' + PRC.jur_prc_nr_processo AS Observacao, 
			CONVERT(CHAR(10), AUD.jur_aud_dt_cadastrado, 103) AS Agendado_Em, 
			CP.Nome, 0 AS CodProf_Geral, 
			'AUDIÊNCIA' AS Tipo, ADV.jur_adv_nm_advogado,
			CONVERT(CHAR(8), AUD.jur_aud_dt_audiencia, 112) AS ORDER_DATA,
			 AUD.jur_aud_fl_situacao
		FROM         tb_jur_processo PRC INNER JOIN
	                      Cadastro_Professores CP INNER JOIN
	                      tb_jur_ficha_professor FIP INNER JOIN
             		         tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha ON CP.Codigo_Professor = FIP.jur_fip_cd_professor ON 
             		         PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
             		         tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta INNER JOIN 
                 	         tb_jur_cadastro_advogado ADV ON AUD.jur_aud_cd_advogado = ADV.jur_adv_cd_advogado


		WHERE    
			(CONVERT(CHAR(8),AUD.jur_aud_dt_audiencia, 112) BETWEEN @Pdt_de AND @Pdt_ate) 
			AND (AUD.jur_aud_cd_advogado = @Pcd_advogado)  AND  AUD.jur_aud_fl_situacao<>'2'
		ORDER BY 
			AUD.jur_aud_dt_audiencia , 
			CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia, 108)
	ELSE IF  @Pcd_tipo=1  --Agenda
		SELECT    
			 AA.jur_aag_cd_agenda AS CodAdvAgenda, 
			CONVERT(CHAR(5), AA.jur_aag_hr_agenda, 108) AS Hora_Agenda, 
			CASE	AA.jur_aag_fl_compareceu
				WHEN 1 THEN 'SIM'
				ELSE 'NÃO'
			END AS Compareceu,
			CONVERT(CHAR(10), AA.jur_aag_dt_agenda, 103) AS Data_Agenda, 
			ISNULL(AA.jur_aag_ds_observacao, '') AS Observacao, 
			CASE CONVERT(CHAR(10),AA.jur_aag_dt_agendado,103)
				WHEN '01/01/1900' THEN ''
				ELSE	CONVERT(CHAR(10), AA.jur_aag_dt_agendado, 103)
				END AS Agendado_Em, 
			ISNULL(SCPG.Nome,'') AS Nome, 
			AA.jur_aag_cd_prof_geral AS CodProf_Geral, 
			'AGENDA' AS Tipo, 
			CONVERT(CHAR(8), AA.jur_aag_dt_agenda, 112) AS ORDER_DATA,
			0 AS jur_aud_fl_situacao, ADV.jur_adv_nm_advogado
		FROM  tb_jur_agenda_advogado AA INNER JOIN
                     	 	Soc_Cadastro_Professor_Geral SCPG ON AA.jur_aag_cd_prof_geral = SCPG.CodProf_Geral INNER JOIN
                      		tb_jur_cadastro_advogado ADV ON AA.jur_aag_cd_advogado = ADV.jur_adv_cd_advogado
		WHERE     (CONVERT(CHAR(8), AA.jur_aag_dt_agenda, 112) BETWEEN @Pdt_de AND @Pdt_ate) 
			AND (AA.jur_aag_cd_advogado = @Pcd_advogado)
			AND (SCPG.Nome <> '')
		ORDER BY 
			AA.jur_aag_dt_agenda , 
			CONVERT(CHAR(5),AA.jur_aag_hr_agenda, 108)
	ELSE IF @Pcd_tipo=2  -- Audiência Cancelado
		SELECT     
			AUD.jur_aud_cd_audiencia AS CodAdvAgenda, 
			CONVERT(CHAR(5), AUD.jur_aud_hr_audiencia, 108)  AS Hora_Agenda, 
			'NÃO' AS Compareceu, 
			CONVERT(CHAR(10), AUD.jur_aud_dt_audiencia, 103) AS Data_Agenda, 
			AUD.jur_aud_nr_pasta + ' - ' + PRC.jur_prc_nr_processo AS Observacao, 
			CONVERT(CHAR(10), AUD.jur_aud_dt_cadastrado, 103) AS Agendado_Em, 
			CP.Nome, 0 AS CodProf_Geral, 
			'AUDIÊNCIA' AS Tipo, ADV.jur_adv_nm_advogado,
			CONVERT(CHAR(8), AUD.jur_aud_dt_audiencia, 112) AS ORDER_DATA,
			 AUD.jur_aud_fl_situacao
		FROM         tb_jur_processo PRC INNER JOIN
	                      Cadastro_Professores CP INNER JOIN
	                      tb_jur_ficha_professor FIP INNER JOIN
             		         tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha ON CP.Codigo_Professor = FIP.jur_fip_cd_professor ON 
             		         PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
             		         tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta INNER JOIN 
                 	         tb_jur_cadastro_advogado ADV ON AUD.jur_aud_cd_advogado = ADV.jur_adv_cd_advogado

		WHERE    
			(CONVERT(CHAR(8),AUD.jur_aud_dt_audiencia, 112) BETWEEN @Pdt_de AND @Pdt_ate) 
			AND (AUD.jur_aud_cd_advogado = @Pcd_advogado)  AND  AUD.jur_aud_fl_situacao='2'
		ORDER BY 
			AUD.jur_aud_dt_audiencia , 
			CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia, 108)
	ELSE IF @Pcd_tipo=3  --TODOS
		SELECT    
		 	AA.jur_aag_cd_agenda AS CodAdvAgenda, 
			CONVERT(CHAR(5), AA.jur_aag_hr_agenda, 108) AS Hora_Agenda, 
			CASE	AA.jur_aag_fl_compareceu
				WHEN 1 THEN 'SIM'
				ELSE 'NÃO'
				END AS Compareceu,
			CONVERT(CHAR(10), AA.jur_aag_dt_agenda, 103) AS Data_Agenda, 
			ISNULL(AA.jur_aag_ds_observacao, '') AS Observacao, 
			CASE CONVERT(CHAR(10),AA.jur_aag_dt_agendado,103)
				WHEN '01/01/1900' THEN ''
				ELSE	CONVERT(CHAR(10), AA.jur_aag_dt_agendado, 103)
				END AS Agendado_Em, 
			ISNULL(SCPG.Nome,'') AS Nome, 
			AA.jur_aag_cd_prof_geral AS CodProf_Geral, 
			'AGENDA' AS Tipo, 
			CONVERT(CHAR(8), AA.jur_aag_dt_agenda, 112) AS ORDER_DATA,
			0 AS jur_aud_fl_situacao,ADV.jur_adv_nm_advogado
		FROM         tb_jur_agenda_advogado AA INNER JOIN
                      		Soc_Cadastro_Professor_Geral SCPG ON AA.jur_aag_cd_prof_geral = SCPG.CodProf_Geral INNER JOIN
                     		 tb_jur_cadastro_advogado ADV ON AA.jur_aag_cd_advogado = ADV.jur_adv_cd_advogado
		WHERE     (CONVERT(CHAR(8), AA.jur_aag_dt_agenda, 112) BETWEEN @Pdt_de AND @Pdt_ate) 
			AND (AA.jur_aag_cd_advogado = @Pcd_advogado)
			AND (SCPG.Nome <> '')
		UNION
		SELECT     
			AUD.jur_aud_cd_audiencia, 
			CONVERT(CHAR(5), AUD.jur_aud_hr_audiencia, 108), 
			'NÃO' AS Compareceu, 
			CONVERT(CHAR(10), AUD.jur_aud_dt_audiencia, 103) AS Data_Agenda, 
			AUD.jur_aud_nr_pasta + ' - ' + PRC.jur_prc_nr_processo AS Observacao, 
			CONVERT(CHAR(10), AUD.jur_aud_dt_cadastrado, 103), 
			CP.Nome, 0 AS CodProf_Geral, 
			'AUDIÊNCIA' AS Tipo, 
			CONVERT(CHAR(8), AUD.jur_aud_dt_audiencia, 112) AS ORDER_DATA,
			AUD.jur_aud_fl_situacao,ADV.jur_adv_nm_advogado
		FROM         tb_jur_processo PRC INNER JOIN
	                      Cadastro_Professores CP INNER JOIN
	                      tb_jur_ficha_professor FIP INNER JOIN
             		         tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha ON CP.Codigo_Professor = FIP.jur_fip_cd_professor ON 
             		         PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
             		         tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta INNER JOIN 
                 	         tb_jur_cadastro_advogado ADV ON AUD.jur_aud_cd_advogado = ADV.jur_adv_cd_advogado

		WHERE    
			(CONVERT(CHAR(8),AUD.jur_aud_dt_audiencia, 112) BETWEEN @Pdt_de AND @Pdt_ate) 
			AND (AUD.jur_aud_cd_advogado = @Pcd_advogado) 
		ORDER BY 
			ORDER_DATA , 
			CONVERT(CHAR(5), AA.jur_aag_hr_agenda, 108)
END
ELSE
BEGIN
	IF @Pcd_tipo=0  -- Audiência
		SELECT     
			AUD.jur_aud_cd_audiencia AS CodAdvAgenda, 
			CONVERT(CHAR(5), AUD.jur_aud_hr_audiencia, 108)  AS Hora_Agenda, 
			'NÃO' AS Compareceu, 
			CONVERT(CHAR(10), AUD.jur_aud_dt_audiencia, 103) AS Data_Agenda, 
			AUD.jur_aud_nr_pasta + ' - ' + PRC.jur_prc_nr_processo AS Observacao, 
			CONVERT(CHAR(10), AUD.jur_aud_dt_cadastrado, 103) AS Agendado_Em, 
			CP.Nome, 0 AS CodProf_Geral, 
			'AUDIÊNCIA' AS Tipo, 
			CONVERT(CHAR(8), AUD.jur_aud_dt_audiencia, 112) AS ORDER_DATA,
			 AUD.jur_aud_fl_situacao,ADV.jur_adv_nm_advogado
		FROM         tb_jur_processo PRC INNER JOIN
	                      Cadastro_Professores CP INNER JOIN
	                      tb_jur_ficha_professor FIP INNER JOIN
             		         tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha ON CP.Codigo_Professor = FIP.jur_fip_cd_professor ON 
             		         PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
             		         tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta INNER JOIN 
                 	         tb_jur_cadastro_advogado ADV ON AUD.jur_aud_cd_advogado = ADV.jur_adv_cd_advogado

		WHERE    
			(CONVERT(CHAR(8),AUD.jur_aud_dt_audiencia, 112) BETWEEN @Pdt_de AND @Pdt_ate)  
			 AND  AUD.jur_aud_fl_situacao<>'2'
		ORDER BY 
			AUD.jur_aud_dt_audiencia , 
			CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia, 108)
	ELSE IF  @Pcd_tipo=1  --Agenda
		SELECT    
			 AA.jur_aag_cd_agenda AS CodAdvAgenda, 
			CONVERT(CHAR(5), AA.jur_aag_hr_agenda, 108) AS Hora_Agenda, 
			CASE	AA.jur_aag_fl_compareceu
				WHEN 1 THEN 'SIM'
				ELSE 'NÃO'
			END AS Compareceu,
			CONVERT(CHAR(10), AA.jur_aag_dt_agenda, 103) AS Data_Agenda, 
			ISNULL(AA.jur_aag_ds_observacao, '') AS Observacao, 
			CASE CONVERT(CHAR(10),AA.jur_aag_dt_agendado,103)
				WHEN '01/01/1900' THEN ''
				ELSE	CONVERT(CHAR(10), AA.jur_aag_dt_agendado, 103)
				END AS Agendado_Em, 
			ISNULL(SCPG.Nome,'') AS Nome, 
			AA.jur_aag_cd_prof_geral AS CodProf_Geral, 
			'AGENDA' AS Tipo, 
			CONVERT(CHAR(8), AA.jur_aag_dt_agenda, 112) AS ORDER_DATA,
			0 AS jur_aud_fl_situacao,ADV.jur_adv_nm_advogado
		FROM  tb_jur_agenda_advogado AA INNER JOIN
                     	 	Soc_Cadastro_Professor_Geral SCPG ON AA.jur_aag_cd_prof_geral = SCPG.CodProf_Geral INNER JOIN
                      		tb_jur_cadastro_advogado ADV ON AA.jur_aag_cd_advogado = ADV.jur_adv_cd_advogado
		WHERE     (CONVERT(CHAR(8), AA.jur_aag_dt_agenda, 112) BETWEEN @Pdt_de AND @Pdt_ate) 			
			AND (SCPG.Nome <> '')
		ORDER BY 
			AA.jur_aag_dt_agenda , 
			CONVERT(CHAR(5),AA.jur_aag_hr_agenda, 108)
	ELSE IF @Pcd_tipo=2  -- Audiência Cancelado
		SELECT     
			AUD.jur_aud_cd_audiencia AS CodAdvAgenda, 
			CONVERT(CHAR(5), AUD.jur_aud_hr_audiencia, 108)  AS Hora_Agenda, 
			'NÃO' AS Compareceu, 
			CONVERT(CHAR(10), AUD.jur_aud_dt_audiencia, 103) AS Data_Agenda, 
			AUD.jur_aud_nr_pasta + ' - ' + PRC.jur_prc_nr_processo AS Observacao, 
			CONVERT(CHAR(10), AUD.jur_aud_dt_cadastrado, 103) AS Agendado_Em, 
			CP.Nome, 0 AS CodProf_Geral, 
			'AUDIÊNCIA' AS Tipo, ADV.jur_adv_nm_advogado,
			CONVERT(CHAR(8), AUD.jur_aud_dt_audiencia, 112) AS ORDER_DATA,
			 AUD.jur_aud_fl_situacao
		FROM         tb_jur_processo PRC INNER JOIN
	                      Cadastro_Professores CP INNER JOIN
	                      tb_jur_ficha_professor FIP INNER JOIN
             		         tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha ON CP.Codigo_Professor = FIP.jur_fip_cd_professor ON 
             		         PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
             		         tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta INNER JOIN 
                 	         tb_jur_cadastro_advogado ADV ON AUD.jur_aud_cd_advogado = ADV.jur_adv_cd_advogado

		WHERE    
			(CONVERT(CHAR(8),AUD.jur_aud_dt_audiencia, 112) BETWEEN @Pdt_de AND @Pdt_ate) 
			AND (AUD.jur_aud_cd_advogado = @Pcd_advogado)  AND  AUD.jur_aud_fl_situacao='2'
		ORDER BY 
			AUD.jur_aud_dt_audiencia , 
			CONVERT(CHAR(5),AUD.jur_aud_hr_audiencia, 108)
	ELSE IF @Pcd_tipo=3  --TODOS
		SELECT    
		 	AA.jur_aag_cd_agenda AS CodAdvAgenda, 
			CONVERT(CHAR(5), AA.jur_aag_hr_agenda, 108) AS Hora_Agenda, 
			CASE	AA.jur_aag_fl_compareceu
				WHEN 1 THEN 'SIM'
				ELSE 'NÃO'
				END AS Compareceu,
			CONVERT(CHAR(10), AA.jur_aag_dt_agenda, 103) AS Data_Agenda, 
			ISNULL(AA.jur_aag_ds_observacao, '') AS Observacao, 
			CASE CONVERT(CHAR(10),AA.jur_aag_dt_agendado,103)
				WHEN '01/01/1900' THEN ''
				ELSE	CONVERT(CHAR(10), AA.jur_aag_dt_agendado, 103)
				END AS Agendado_Em, 
			ISNULL(SCPG.Nome,'') AS Nome, 
			AA.jur_aag_cd_prof_geral AS CodProf_Geral, 
			'AGENDA' AS Tipo, 
			CONVERT(CHAR(8), AA.jur_aag_dt_agenda, 112) AS ORDER_DATA,
			0 AS jur_aud_fl_situacao,ADV.jur_adv_nm_advogado
		FROM         tb_jur_agenda_advogado AA INNER JOIN
                      		Soc_Cadastro_Professor_Geral SCPG ON AA.jur_aag_cd_prof_geral = SCPG.CodProf_Geral INNER JOIN
                     		 tb_jur_cadastro_advogado ADV ON AA.jur_aag_cd_advogado = ADV.jur_adv_cd_advogado
		WHERE     (CONVERT(CHAR(8), AA.jur_aag_dt_agenda, 112) BETWEEN @Pdt_de AND @Pdt_ate) 			
			AND (SCPG.Nome <> '')
		UNION
		SELECT     
			AUD.jur_aud_cd_audiencia, 
			CONVERT(CHAR(5), AUD.jur_aud_hr_audiencia, 108), 
			'NÃO' AS Compareceu, 
			CONVERT(CHAR(10), AUD.jur_aud_dt_audiencia, 103) AS Data_Agenda, 
			AUD.jur_aud_nr_pasta + ' - ' + PRC.jur_prc_nr_processo AS Observacao, 
			CONVERT(CHAR(10), AUD.jur_aud_dt_cadastrado, 103), 
			CP.Nome, 0 AS CodProf_Geral, 
			'AUDIÊNCIA' AS Tipo, 
			CONVERT(CHAR(8), AUD.jur_aud_dt_audiencia, 112) AS ORDER_DATA,
			AUD.jur_aud_fl_situacao,ADV.jur_adv_nm_advogado
		FROM         tb_jur_processo PRC INNER JOIN
	                      Cadastro_Professores CP INNER JOIN
	                      tb_jur_ficha_professor FIP INNER JOIN
             		         tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha ON CP.Codigo_Professor = FIP.jur_fip_cd_professor ON 
             		         PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
             		         tb_jur_audiencia AUD ON PRC.jur_prc_nr_pasta = AUD.jur_aud_nr_pasta INNER JOIN 
                 	         tb_jur_cadastro_advogado ADV ON AUD.jur_aud_cd_advogado = ADV.jur_adv_cd_advogado

		WHERE    
			(CONVERT(CHAR(8),AUD.jur_aud_dt_audiencia, 112) BETWEEN @Pdt_de AND @Pdt_ate) 	
		ORDER BY 
			ORDER_DATA , 
			CONVERT(CHAR(5), AA.jur_aag_hr_agenda, 108)
END
go

