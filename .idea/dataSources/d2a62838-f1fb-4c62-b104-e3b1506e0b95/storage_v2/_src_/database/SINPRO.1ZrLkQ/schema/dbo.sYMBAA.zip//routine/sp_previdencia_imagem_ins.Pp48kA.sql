/*******************************************************************
Objeto criado: 	 sp_previdencia_imagem_ins
Descriçao:	Cadastra as Imagens do Cadatro da Previdência
Data da Criaçao: 18/08/2010
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_previdencia_imagem_ins
(
@Pcd_imagem		INT,
@Pcd_professor 	NVARCHAR(6),
@Pds_arquivo		NVARCHAR(300),
@Pds_observacao	NVARCHAR(600),
@Pdt_cadastro		DATETIME,
@Pnm_login		NVARCHAR(30)
)

AS

IF @Pcd_imagem = 0  
	INSERT INTO tb_prev_atendimento_imagem
		( prev_img_cd_professor, 
		 prev_img_ds_arquivo, 
		 prev_img_ds_observacao, 
		 prev_img_dt_cadastro, 
		 prev_img_nm_login)
	VALUES
		(@Pcd_professor,
		@Pds_arquivo,
		@Pds_observacao,
		@Pdt_cadastro,
		@Pnm_login)
ELSE
	UPDATE tb_prev_atendimento_imagem SET
		prev_img_ds_arquivo	= @Pds_arquivo,
		prev_img_ds_observacao = @Pds_observacao,
		prev_img_dt_cadastro	= @Pdt_cadastro, 
		prev_img_nm_login	= @Pnm_login
	WHERE
		prev_img_cd_imagem = @Pcd_imagem
go

