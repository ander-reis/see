

/*******************************************************************
Objeto criado: 	 sp_juridico_processo_observacao_sel
Descriçao:	Seleciona as OBservações do Processo
Data da Criaçao: 26/06/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_observacao_sel
(
@Pnr_pasta	NVARCHAR(8)
)
AS

SELECT
	jur_pco_cd_observacao,
	CONVERT(CHAR(10),jur_pco_dt_observacao,103) AS jur_pco_dt_observacao,
	CONVERT(CHAR(8),jur_pco_hr_observacao,108) AS jur_pco_hr_observacao,
	jur_pco_nm_login,
	jur_pco_ds_observacao
FROM
	tb_jur_processo_observacao
WHERE
	jur_pco_nr_pasta = @Pnr_pasta
	AND SUBSTRING(jur_pco_ds_observacao,1,1) <> '*'
ORDER BY
	CONVERT(CHAR(10),jur_pco_dt_observacao,111) DESC,
	CONVERT(CHAR(8),jur_pco_hr_observacao,108) DESC

go

