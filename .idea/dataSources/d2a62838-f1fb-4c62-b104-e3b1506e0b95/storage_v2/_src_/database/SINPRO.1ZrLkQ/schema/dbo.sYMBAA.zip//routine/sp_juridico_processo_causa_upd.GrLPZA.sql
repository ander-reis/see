

/*******************************************************************
Objeto criado: 	 sp_juridico_processo_causa_upd
Descriçao:	 Atualizar a Procedência das causa do Processo
Data da Criaçao: 28/02/2007
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_causa_upd
(
@Pnr_ficha		INT,
@Pcd_causa		INT,
@Pfl_vara		SMALLINT,
@Pfl_trt			SMALLINT,
@Pfl_tst		SMALLINT,
@Pfl_stf		SMALLINT
)
AS	

UPDATE    tb_jur_ficha_causa SET
	 jur_fca_fl_vara = @Pfl_vara,
	 jur_fca_fl_trt = @Pfl_trt,
	 jur_fca_fl_tst = @Pfl_tst,
	 jur_fca_fl_stf = @Pfl_stf
WHERE
	jur_fca_nr_ficha 		= @Pnr_ficha
	AND jur_fca_cd_causa 	= @Pcd_causa
go

