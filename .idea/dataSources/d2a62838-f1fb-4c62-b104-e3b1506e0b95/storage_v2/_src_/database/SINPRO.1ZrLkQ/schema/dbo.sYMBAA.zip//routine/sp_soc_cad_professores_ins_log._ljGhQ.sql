
/*******************************************************************
Objeto criado: 	sp_soc_cad_professores_ins_log
Descriçao:	Inclui Log's do Cadastro de Professores
Entrada:	
Saída:		
Data da Criaçao: 14/11/2005
Autor:		Ronaldo Araujo (SinproSP)
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_ins_log
(
@pNvc_professor			NVARCHAR(5),
@pNvc_user				VARCHAR(30),
@pDt_data				DATETIME
)
AS

INSERT INTO Log_Professor (
	Codigo_Professor,
	User_Professor,
	Data_Professor) 
VALUES (
	@pNvc_professor,
	@pNvc_user,
	@pDt_data)


go

