

/*******************************************************************
Objeto criado: 	 sp_codigo_ins
Descriçao:	Adiciona mais um nº na Tabela MCodigos
Data da Criaçao: 28/02/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_codigo_ins (

@Pds_campo	NVARCHAR(30),
@Vcd_codigo	INT OUTPUT
)

AS
 
DECLARE  @Vcd_contador	INT
DECLARE @Vnr_ano		INT

IF LOWER(@Pds_campo) = 'codficha'
BEGIN
	SELECT @Vcd_contador = CodFicha FROM MCodigos
	UPDATE MCodigos SET CodFicha = @Vcd_contador  + 1
END
ELSE IF LOWER(@Pds_campo) = 'codprocesso'
BEGIN
	SELECT @Vcd_contador = CodProcesso FROM MCodigos	
	UPDATE MCodigos SET CodProcesso = @Vcd_contador  + 1
END

SET @Vcd_codigo	=  @Vcd_contador  + 1
go

