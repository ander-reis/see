

/*******************************************************************
Objeto criado: 	 sp_eleicao_upd_eleitor
Descriçao:	Atualiza Voto do Eleitor
Data da Criaçao: 22/06/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_upd_eleitor
(
@Pcodigo_professor		NVARCHAR(5),
@Pvotou			TINYINT,
@Pobservacao			NVARCHAR(200) = '',
@Plogin			NVARCHAR(30) = '',
@Pds_eleicao			CHAR(4) = ''
)
AS
DECLARE @Vdata	DATETIME

SET @Vdata = GETDATE()



IF @Pvotou = 1    --Professor Votou e Recebeu a Agenda
BEGIN
	UPDATE Cadastro_Professores SET
		Votou = 1,
		Rec_Agenda = 1
	WHERE Codigo_Professor = @Pcodigo_professor

	EXEC sp_soc_cad_professores_ins_observacao
 		@Pcodigo_professor,
		@Vdata,
		@Pobservacao	, 
		@Plogin,
		@Vdata

	UPDATE tb_ele_datas SET
		ele_edt_nr_votos = ele_edt_nr_votos + 1
	WHERE ele_edt_ds_eleicao = @Pds_eleicao
END
ELSE IF @Pvotou = 0	--Professor não Votou
BEGIN
	DELETE FROM Professor_Observacoes	
		WHERE Codigo_Professor = @Pcodigo_professor AND Observacao LIKE @Pobservacao

	UPDATE Cadastro_Professores SET
		Votou = 0,
		Rec_Agenda = 0
	WHERE Codigo_Professor = @Pcodigo_professor

	UPDATE tb_ele_datas SET
		ele_edt_nr_votos = ele_edt_nr_votos - 1
	WHERE ele_edt_ds_eleicao = @Pds_eleicao
END
ELSE IF @Pvotou = 2	--Professor só recebeu a agenda
BEGIN
	UPDATE Cadastro_Professores SET
		Rec_Agenda = 1
	WHERE Codigo_Professor = @Pcodigo_professor

	EXEC sp_soc_cad_professores_ins_observacao
 		@Pcodigo_professor,
		@Vdata,
		@Pobservacao	, 
		@Plogin,
		@Vdata
END
ELSE IF @Pvotou = 3	--Professor não recebeu a agenda
BEGIN
	UPDATE Cadastro_Professores SET
		Rec_Agenda = 0
	WHERE Codigo_Professor = @Pcodigo_professor

	DELETE FROM Professor_Observacoes	
		WHERE Codigo_Professor = @Pcodigo_professor AND Observacao LIKE @Pobservacao
END

go

