
/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_log
Descriçao:	Seleciona Log's do Professor
Entrada:	@pNvc_professor  -> Codigo do Professor
Saída:		
Data da Criaçao: 14/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_sel_log
(
@pNvc_professor		NVARCHAR(5)
)
AS


SELECT 
	Codigo_Professor,
	User_Professor,
	CONVERT(CHAR(10),Data_Professor,103)  AS Data_Professor,
	CONVERT(CHAR(8),Data_Professor,108) AS Hora_Professor
FROM Log_Professor
WHERE Codigo_Professor = @pNvc_professor  
ORDER BY CONVERT(DATETIME,Data_Professor,120) DESC


go

