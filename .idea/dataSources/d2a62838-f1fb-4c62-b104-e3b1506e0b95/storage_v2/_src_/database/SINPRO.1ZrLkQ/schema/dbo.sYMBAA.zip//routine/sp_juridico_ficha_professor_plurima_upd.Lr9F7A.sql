/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_professor_plurima_upd
Descriçao:	 Atualizar Plurima do Professor na Ficha de Consulta
Data da Criaçao: 24/04/2008
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_professor_plurima_upd
(
@Pcd_fic_pro 			INT,
@Pfl_plurima			TINYINT
)
AS

UPDATE tb_jur_ficha_professor SET 
	jur_fip_fl_plurima		= @Pfl_plurima
WHERE jur_fip_cd_fic_pro = @Pcd_fic_pro
go

