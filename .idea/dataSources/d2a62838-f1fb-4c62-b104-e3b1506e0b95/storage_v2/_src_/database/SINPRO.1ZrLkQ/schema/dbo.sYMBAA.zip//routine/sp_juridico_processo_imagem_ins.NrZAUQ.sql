

/*******************************************************************
Objeto criado: 	 sp_juridico_processo_imagem_ins
Descriçao:	Cadastra as Imagens do Processo
Data da Criaçao: 03/07/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_imagem_ins
(
@Pcd_imagem		INT,
@Pnr_pasta		NVARCHAR(8),
@Pds_arquivo		NVARCHAR(300),
@Pds_observacao	NVARCHAR(600),
@Pdt_cadastro		DATETIME,
@Pnm_login		NVARCHAR(30)
)

AS

IF @Pcd_imagem = 0  
	INSERT INTO tb_jur_processo_imagem
		(jur_img_nr_pasta,
		jur_img_ds_arquivo,
		jur_img_ds_observacao,
		jur_img_dt_cadastro,
		jur_img_nm_login)
	VALUES
		(@Pnr_pasta,
		@Pds_arquivo,
		@Pds_observacao,
		@Pdt_cadastro,
		@Pnm_login)
ELSE
	UPDATE tb_jur_processo_imagem SET
		jur_img_ds_arquivo	= @Pds_arquivo,
		jur_img_ds_observacao	= @Pds_observacao,
		jur_img_dt_cadastro	= @Pdt_cadastro, 
		jur_img_nm_login	= @Pnm_login
	WHERE
		jur_img_cd_imagem = @Pcd_imagem
go

