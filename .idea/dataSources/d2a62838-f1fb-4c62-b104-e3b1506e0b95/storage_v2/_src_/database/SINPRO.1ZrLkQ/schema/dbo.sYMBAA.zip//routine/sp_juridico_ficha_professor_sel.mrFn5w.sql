

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_professor_sel
Descriçao:	Seleciona Professores da Ficha de Consulta 
Data da Criaçao: 01/03/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_professor_sel
(
@Pnr_ficha	INT
)
AS

SELECT
	FIP.jur_fip_cd_fic_pro,
	FIP.jur_fip_cd_professor,
	CP.Nome,
	 CASE 
		WHEN ENT.Doc_Ent = TOT.Doc_Tot THEN 'TODOS'  
		WHEN ENT.Doc_Ent <> TOT.Doc_Tot THEN 'FALTA' 
		ELSE '' 
	END AS Status,
	CASE FIP.jur_fip_fl_receber
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS jur_fip_fl_receber,
	CASE FIP.jur_fip_fl_plurima
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS jur_fip_fl_plurima
		
FROM
	tb_jur_ficha_professor FIP
	INNER JOIN Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	LEFT JOIN (SELECT COUNT(1) AS Doc_Ent, jur_fpd_cd_fic_pro FROM tb_jur_ficha_professor_documento FPD LEFT JOIN tb_jur_ficha_professor FIP ON FPD.jur_fpd_cd_fic_pro = FIP.jur_fip_cd_fic_pro WHERE CONVERT(CHAR(8),jur_fpd_dt_entrega,112) <> '19000101' GROUP BY jur_fpd_cd_fic_pro) AS ENT ON FIP.jur_fip_cd_fic_pro = ENT.jur_fpd_cd_fic_pro
	LEFT JOIN (SELECT COUNT(1) AS Doc_Tot, jur_fpd_cd_fic_pro FROM tb_jur_ficha_professor_documento FPD LEFT JOIN tb_jur_ficha_professor FIP ON FPD.jur_fpd_cd_fic_pro = FIP.jur_fip_cd_fic_pro  GROUP BY jur_fpd_cd_fic_pro) AS TOT ON FIP.jur_fip_cd_fic_pro = TOT.jur_fpd_cd_fic_pro
WHERE
	jur_fip_nr_ficha = @Pnr_ficha
ORDER BY
	CP.Nome
go

