



/*******************************************************************
Objeto criado: 	 sp_eleicao_func_sel
Descriçao:	Seleciona Cadastro de Funcionário - Eleição
Entrada:	@pNvc_professor  -> Codigo ou CPF do Professor
		@pTin_tipo -> 0 = Codigo ou 1 = CPF
Saída:		
Data da Criaçao: 08/06/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_func_sel
(
@Pcd_funcionario		NVARCHAR(14),
@Pfl_tipo				BIT
)
AS

DECLARE @Vcd_funcionario	CHAR(5)

IF @Pfl_tipo = 0
BEGIN
	SET @Vcd_funcionario = @Pcd_funcionario

	SELECT     
		RTRIM(ele_fun_cd_funcionario)			AS ele_fun_cd_funcionario, 
		RTRIM(ele_fun_nm_funcionario)			AS ele_fun_nm_funcionario, 
		ele_fun_fl_sexo, 

		RTRIM(CASE CONVERT(CHAR(10),ele_fun_dt_nascimento,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),ele_fun_dt_nascimento,103)
		END)						AS ele_fun_dt_nascimento, 

                      	RTRIM(ele_fun_ds_cpf)				AS ele_fun_ds_cpf, 
		RTRIM(ele_fun_ds_rg)				AS ele_fun_ds_rg, 
		RTRIM(ele_fun_nm_mae)			AS ele_fun_nm_mae, 
		RTRIM(ele_fun_nm_pai)				AS ele_fun_nm_pai, 
		RTRIM(ele_fun_nm_indicacao) 			AS ele_fun_nm_indicacao, 

		RTRIM(CASE CONVERT(CHAR(10),ele_fun_dt_modificacao,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),ele_fun_dt_modificacao,103)
		END)  						AS ele_fun_dt_modificacao, 

		RTRIM(ele_fun_ds_cep)				AS ele_fun_ds_cep, 
		RTRIM(ele_fun_ds_endereco)			AS ele_fun_ds_endereco, 
		RTRIM(ele_fun_ds_numero)			AS ele_fun_ds_numero, 
		RTRIM(ele_fun_ds_complemento)		AS ele_fun_ds_complemento, 
		RTRIM(ele_fun_ds_bairro)			AS ele_fun_ds_bairro, 
                      	RTRIM(ele_fun_ds_cidade)			AS ele_fun_ds_cidade, 
		RTRIM(ele_fun_ds_uf)				AS ele_fun_ds_uf, 
		RTRIM(ele_fun_nr_ddd_fone_residencial) 	AS ele_fun_nr_ddd_fone_residencial, 
		RTRIM(ele_fun_nr_fone_residencial)		AS ele_fun_nr_fone_residencial, 
		RTRIM(ele_fun_nr_ddd_celular)			AS ele_fun_nr_ddd_celular, 
		RTRIM(ele_fun_nr_celular)			AS ele_fun_nr_celular, 
                      	RTRIM(ele_fun_ds_email)			AS ele_fun_ds_email, 

		RTRIM(CASE CONVERT(CHAR(10),ele_fun_dt_cadastro,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),ele_fun_dt_cadastro,103)
		END)						AS ele_fun_dt_cadastro,

		ele_fun_fl_bloqueado,
		ele_fun_fl_opcao1,
		ele_fun_fl_opcao2,
		ele_fun_fl_opcao3,
		ele_fun_fl_opcao4,
		ele_fun_fl_opcao5

	FROM	tb_ele_funcionario
	WHERE ele_fun_cd_funcionario = @Pcd_funcionario
END
ELSE
BEGIN
	SELECT     
		@Vcd_funcionario = ele_fun_cd_funcionario
	FROM	tb_ele_funcionario
	WHERE ele_fun_ds_cpf = @Pcd_funcionario

	SELECT     
		RTRIM(ele_fun_cd_funcionario)			AS ele_fun_cd_funcionario, 
		RTRIM(ele_fun_nm_funcionario)			AS ele_fun_nm_funcionario, 
		ele_fun_fl_sexo, 

		RTRIM(CASE CONVERT(CHAR(10),ele_fun_dt_nascimento,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),ele_fun_dt_nascimento,103)
		END)						AS ele_fun_dt_nascimento, 

                      	RTRIM(ele_fun_ds_cpf)				AS ele_fun_ds_cpf, 
		RTRIM(ele_fun_ds_rg)				AS ele_fun_ds_rg, 
		RTRIM(ele_fun_nm_mae)			AS ele_fun_nm_mae, 
		RTRIM(ele_fun_nm_pai)				AS ele_fun_nm_pai, 
		RTRIM(ele_fun_nm_indicacao) 			AS ele_fun_nm_indicacao, 

		RTRIM(CASE CONVERT(CHAR(10),ele_fun_dt_modificacao,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),ele_fun_dt_modificacao,103)
		END)  						AS ele_fun_dt_modificacao, 

		RTRIM(ele_fun_ds_cep)				AS ele_fun_ds_cep, 
		RTRIM(ele_fun_ds_endereco)			AS ele_fun_ds_endereco, 
		RTRIM(ele_fun_ds_numero)			AS ele_fun_ds_numero, 
		RTRIM(ele_fun_ds_complemento)		AS ele_fun_ds_complemento, 
		RTRIM(ele_fun_ds_bairro)			AS ele_fun_ds_bairro, 
                      	RTRIM(ele_fun_ds_cidade)			AS ele_fun_ds_cidade, 
		RTRIM(ele_fun_ds_uf)				AS ele_fun_ds_uf, 
		RTRIM(ele_fun_nr_ddd_fone_residencial) 	AS ele_fun_nr_ddd_fone_residencial, 
		RTRIM(ele_fun_nr_fone_residencial)		AS ele_fun_nr_fone_residencial, 
		RTRIM(ele_fun_nr_ddd_celular)			AS ele_fun_nr_ddd_celular, 
		RTRIM(ele_fun_nr_celular)			AS ele_fun_nr_celular, 
                      	RTRIM(ele_fun_ds_email)			AS ele_fun_ds_email, 

		RTRIM(CASE CONVERT(CHAR(10),ele_fun_dt_cadastro,103)
			WHEN '01/01/1900' THEN ''
			ELSE	CONVERT(CHAR(10),ele_fun_dt_cadastro,103)
		END)						AS ele_fun_dt_cadastro,

		ele_fun_fl_bloqueado,
		ele_fun_fl_opcao1,
		ele_fun_fl_opcao2,
		ele_fun_fl_opcao3,
		ele_fun_fl_opcao4,
		ele_fun_fl_opcao5


	FROM	tb_ele_funcionario
	WHERE ele_fun_ds_cpf = @Pcd_funcionario
END

SELECT
	ele_dad_ds_eleicao, 
	ele_dad_cd_dados,

	CASE ele_dad_ds_cargo
		WHEN 0 THEN 'PRESIDENTE'
		WHEN 1 THEN 'MESÁRIO'
		WHEN 2 THEN 'SUPLENTE'
	END 				AS ele_dad_ds_cargo,

	CASE ele_dad_fl_carro
		WHEN 0 THEN 'CARRO'
		WHEN 1 THEN 'MOTO'
		WHEN 2 THEN 'NÃO'
	END 				AS ele_dad_fl_carro,

	RTRIM(ele_dad_ds_placa)	AS ele_dad_ds_placa, 

	CASE CONVERT(CHAR(3),ele_dad_nr_urna)
		WHEN 0 THEN ''
		ELSE RTRIM(CONVERT(CHAR(3),ele_dad_nr_urna))
	END 				AS ele_dad_nr_urna,

	CASE ele_dad_fl_aprovado
		WHEN 0 THEN 'NÃO'
		WHEN 1 THEN 'SIM'
	END 				AS ele_dad_fl_aprovado
FROM	tb_ele_func_dados
WHERE ele_dad_cd_funcionario = @Vcd_funcionario
ORDER BY ele_dad_ds_eleicao DESC

SELECT 
	RTRIM(CASE CONVERT(CHAR(10),ele_obs_dt_observacao,103)
		WHEN '01/01/1900' THEN ''
		ELSE	CONVERT(CHAR(10),ele_obs_dt_observacao,103)
	END)					AS ele_obs_dt_observacao,

	ele_obs_ds_observacao,

	RTRIM(ISNULL(ele_obs_nm_login,''))	AS ele_obs_nm_login,

	RTRIM(CASE CONVERT(CHAR(10),ele_obs_dt_hora,108)
		WHEN '00:00:00' THEN ''
		ELSE	CONVERT(CHAR(10),ele_obs_dt_hora,108)
	END) 					 AS ele_obs_dt_hora
FROM tb_ele_func_observacao
WHERE ele_obs_cd_funcionario = @Vcd_funcionario
ORDER BY CONVERT(CHAR(10),ele_obs_dt_observacao,111) DESC, CONVERT(CHAR(8),ele_obs_dt_hora,108) DESC
go

