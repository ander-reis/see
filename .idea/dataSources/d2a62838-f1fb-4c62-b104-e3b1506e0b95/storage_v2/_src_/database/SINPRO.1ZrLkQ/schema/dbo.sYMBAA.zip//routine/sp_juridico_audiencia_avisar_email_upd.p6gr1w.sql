/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_avisar_email_upd
Descriçao:	Seleciona Audiencias que deverão Ser enviados por e-mail
Data da Criaçao: 24/11/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_avisar_email_upd
(
@Pnr_nada INT =  0
)
AS

UPDATE tb_jur_audiencia SET
	jur_aud_fl_email = 0
WHERE jur_aud_cd_audiencia IN (
	SELECT     jur_aud_cd_audiencia
		FROM         tb_jur_audiencia
		WHERE     (CONVERT(CHAR(8),jur_aud_dt_audiencia,112) = CONVERT(CHAR(8),DATEADD(day, 10, GETDATE()),112) 
			OR CONVERT(CHAR(8),jur_aud_dt_audiencia,112) = CONVERT(CHAR(8),DATEADD(day, 05, GETDATE()),112))
			AND jur_aud_fl_situacao <> 2 and jur_aud_cd_audiencia <> 544
			AND jur_aud_nr_pasta NOT IN  ('094/2006', '085/2006', '395/2006', '248/2006', '154/2003', '259/2008', '181/2006', '050/2007', '036/2004', '189/2005', '302/2006', '210/2003', '017/2004', '310/2006', '243/2007', '042/2006', '245/2006', '039/2006', '064/2009', '170/2004', '218/2003', '035/2004', '125/2003','160/2003','261/2003','002/2003','175/2004','123/1998','034/2004')
	)
go

