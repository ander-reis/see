/*******************************************************************
Objeto criado: 	 sp_email_see_sel
Descriçao:	Carrega os e-mails cadastrados para envio
Data da Criaçao: 19/09/2015
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_email_see_sel

AS

SELECT
	ema_see_cd_observacao,
	ema_see_ds_email,
	ema_see_ds_de,
	ema_see_ds_exibir,
	ema_see_ds_assunto,
	CASE ema_see_ds_tipo
		WHEN 'Boletim' THEN ''
		ELSE ema_see_ds_copia
	END AS ema_see_ds_copia,
	ema_see_ds_para,
	ema_see_ds_lista,
	ema_see_ds_tipo, 
	ema_see_dt_envio,
	ema_see_fl_status
FROM
	 tb_email_see
WHERE
	ema_see_fl_status IN(0,1)
	AND CONVERT(CHAR(19), CONVERT(CHAR(10), ema_see_dt_envio, 111) + ' ' + CONVERT(CHAR(8), ema_see_dt_envio, 108)) <= CONVERT(CHAR(19), CONVERT(CHAR(10), GETDATE(), 111) + ' ' + CONVERT(CHAR(8), GETDATE(), 108))
ORDER BY ema_see_fl_status DESC, 
	 CONVERT(CHAR(19), CONVERT(CHAR(10), ema_see_dt_envio, 111) + ' ' + CONVERT(CHAR(8), ema_see_dt_envio, 108))
go

