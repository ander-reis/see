

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_professor_documento_sel
Descriçao:	Seleciona os Documentos da Ficha de Consulta
Data da Criaçao: 05/03/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_professor_documento_sel
(
@Pcd_fic_pro		INT,
@Pnr_ficha		INT
)
AS

DECLARE @Vfl_achou	TINYINT

SELECT TOP 1 @Vfl_achou = 1
	FROM
		tb_jur_ficha_professor_documento FPD
	WHERE
		FPD.jur_fpd_cd_fic_pro = @Pcd_fic_pro

IF @Vfl_achou = 1  --Documentos já Cadastrados
	SELECT
		FPD.jur_fpd_cd_doc_pro,
		FPD.jur_fpd_cd_documento,
		FPD.jur_fpd_cd_fic_pro,
		DOC.jur_doc_ds_documento,
		FPD.jur_fpd_nm_login,

		CASE CONVERT(NVARCHAR(10),FPD.jur_fpd_dt_entrega,103)
			WHEN '01/01/1900' THEN ''
			ELSE CONVERT(NVARCHAR(10),FPD.jur_fpd_dt_entrega,103) 
		END AS jur_fpd_dt_entrega,
	
		CASE CONVERT(NVARCHAR(5),FPD.jur_fpd_dt_entrega,108)
			WHEN '00:00' THEN ''
			ELSE CONVERT(NVARCHAR(5),FPD.jur_fpd_dt_entrega,108) 
		END AS jur_fpd_hr_entrega,
	
		FPD.jur_fpd_nm_entrega,
		FPD.jur_fpd_ds_complemento
	FROM
		tb_jur_ficha_professor_documento FPD INNER JOIN
		tb_jur_cadastro_documento DOC ON FPD.jur_fpd_cd_documento = DOC.jur_doc_cd_documento
	WHERE
		FPD.jur_fpd_cd_fic_pro = @Pcd_fic_pro
	ORDER BY DOC.jur_doc_ds_documento
ELSE
	SELECT DISTINCT 
		0 AS jur_fpd_cd_fic_pro,
		DOC.jur_doc_cd_documento, 
		DOC.jur_doc_ds_documento
	FROM         
		tb_jur_ficha_causa FCA INNER JOIN
		tb_jur_cadastro_causa CAU ON FCA.jur_fca_cd_causa = CAU.jur_cau_cd_causa INNER JOIN
		tb_jur_cadastro_causa_documento CAD ON CAU.jur_cau_cd_causa = CAD.jur_cad_cd_causa INNER JOIN
		tb_jur_cadastro_documento DOC ON CAD.jur_cad_cd_documento = DOC.jur_doc_cd_documento
	WHERE    
		FCA.jur_fca_nr_ficha = @Pnr_ficha
	ORDER BY 
		DOC.jur_doc_ds_documento
go

