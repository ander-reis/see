/*******************************************************************
Objeto criado: 	 sp_fono_imagem_sel
Descriçao:	Seleciona as Imagens do Cadastro da Previdencia
Data da Criaçao: 18/08/2010
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_fono_imagem_sel
(
@Pcd_cod_prof_geral		NVARCHAR(6)
)
AS


SELECT
	fono_img_cd_imagem,
	fono_img_ds_arquivo,
	fono_img_ds_observacao,
	CONVERT(NVARCHAR(10), fono_img_dt_data,103) AS Dt,
	fono_img_ds_login,
	CONVERT(NVARCHAR(8),fono_img_dt_data,108) AS Hr
FROM
	tb_fono_cad_imagem
WHERE
	fono_img_cd_cod_prof_geral = @Pcd_cod_prof_geral
ORDER BY
	CONVERT(CHAR(10),fono_img_dt_data,111) DESC,
	CONVERT(NVARCHAR(8),fono_img_dt_data,108) DESC
go

