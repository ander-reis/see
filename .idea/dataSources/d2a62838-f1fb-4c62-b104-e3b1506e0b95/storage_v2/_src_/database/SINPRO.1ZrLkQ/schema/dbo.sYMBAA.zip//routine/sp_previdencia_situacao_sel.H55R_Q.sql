


/*******************************************************************
Objeto criado: 	 sp_previdencia_situacao_sel
Descriçao:	Seleciona as Situacoes de Aposentadoria
Data da Criaçao: 11/09/2007
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_previdencia_situacao_sel
(
@Pfl_situacao	INT,
@Pdt_Inicio	DATETIME,
@Pdt_Fim	DATETIME

)
AS

	SELECT     
		PRA.prev_pra_cd_previdencia, 
		SCPG.Codigo_Professor, 
		SCPG.Nome, 
		PAE.prev_pae_ds_especie, 
		PRA.prev_pra_dt_entrada, 
		PRA.prev_pra_dt_concessao, 
		CASE PRA.prev_pra_fl_situacao WHEN '0' THEN 'Ativo' WHEN '1' THEN 'Cancelado' WHEN '2' THEN 'Finalizado' END  AS SITUACAO,
		CASE PRA.prev_pra_fl_andamento WHEN '0' THEN 'Pab'  WHEN '1' THEN 'Indeferido'  WHEN '2' THEN 'Concedido' WHEN '3' THEN 'Exigência' WHEN '4' THEN 'Andamento'  WHEN '5' THEN 'Recurso' WHEN '6' THEN 'Revisão' WHEN '7' THEN 'Dupl. Ativ.'  WHEN '8' THEN 'Cancelado' WHEN'9' THEN 'Consulta'  END AS ANDAMENTO
	FROM         
		tb_prev_atendimento PRA INNER JOIN  tb_prev_atendimento_tipoespecie PAE ON PRA.prev_pra_cd_tipoespecie = PAE.prev_pae_cd_tipoespecie INNER JOIN
	             Soc_Cadastro_Professor_Geral SCPG ON PRA.prev_pra_cd_codprofgeral = SCPG.CodProf_Geral
	WHERE 
		PRA.prev_pra_dt_entrada BETWEEN @Pdt_Inicio  AND @Pdt_Fim AND PRA.prev_pra_fl_situacao<>1  AND PRA.prev_pra_fl_situacao=@Pfl_situacao and PRA.prev_pra_dt_entrada<>'01/01/1900' AND PRA.prev_pra_fl_situacao<>9
	ORDER BY  SCPG.Nome
go

