
/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_avisar_carta_sel
Descriçao:	Seleciona Audiencias que deverão Ser Impressas
Data da Criaçao: 24/11/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_avisar_carta_sel

AS

SELECT     jur_aud_nr_pasta, CONVERT(CHAR(10),jur_aud_dt_audiencia,103) AS jur_aud_dt_audiencia, CONVERT(CHAR(5),jur_aud_hr_audiencia,108) AS jur_aud_hr_audiencia
	FROM         tb_jur_audiencia
	WHERE     CONVERT(CHAR(8),jur_aud_dt_audiencia,112) = CONVERT(CHAR(8),DATEADD(day, 10, GETDATE()),112) AND jur_aud_fl_situacao <> 2
	ORDER BY jur_aud_hr_audiencia


UPDATE tb_jur_audiencia SET
	jur_aud_fl_carta = 0
WHERE jur_aud_cd_audiencia IN (
	SELECT     jur_aud_cd_audiencia
		FROM         tb_jur_audiencia
		WHERE     CONVERT(CHAR(8),jur_aud_dt_audiencia,112) = CONVERT(CHAR(8),DATEADD(day, 10, GETDATE()),112) AND jur_aud_fl_situacao <> 2
	)
go

