/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_documentos_imp
Descriçao:	Seleciona a Ficha de Consulta / Documentos para Impressão
Data da Criaçao: 22/03/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_documentos_imp
(
@Pnr_ficha		INT
)

AS
SELECT
	FIC.jur_fic_nr_ficha,
	FIP.jur_fip_cd_fic_pro,
	CASE CP.Sexo
		WHEN 1 THEN 'Prezada Professora'
		ELSE 'Prezado Professor'
	END AS tratamento,
	CP.Nome,
	ADV.jur_adv_fl_sexo,
	ADV.jur_adv_nm_advogado,
	CE.Razao_Social,
             DOC.jur_doc_ds_documento,
	CONVERT(NVARCHAR(10),FIC.jur_fic_dt_cadastro,103) AS jur_fic_dt_cadastro,
	CONVERT(NVARCHAR(10),FIP.jur_fip_dt_demissao,103) AS jur_fip_dt_demissao,
	CONVERT(NVARCHAR(10),FPD.jur_fpd_dt_entrega,103) AS jur_fpd_dt_entrega,
	FPD.jur_fpd_ds_complemento
FROM
	tb_jur_ficha_professor_documento FPD 
	INNER JOIN tb_jur_cadastro_documento DOC ON FPD.jur_fpd_cd_documento = DOC.jur_doc_cd_documento
	INNER JOIN tb_jur_ficha_professor FIP
	INNER JOIN tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha
	INNER JOIN Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	INNER JOIN Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola ON FPD.jur_fpd_cd_fic_pro = FIP.jur_fip_cd_fic_pro
	INNER JOIN tb_jur_cadastro_advogado ADV ON FIC.jur_fic_cd_advogado = ADV.jur_adv_cd_advogado
WHERE     
	(FIC.jur_fic_nr_ficha = @Pnr_ficha  AND FIC.jur_fic_fl_processo = 0) OR (FIC.jur_fic_nr_ficha = @Pnr_ficha AND FIP.jur_fip_cd_professor = '00000')
ORDER BY
	FIP.jur_fip_cd_fic_pro,
	DOC.jur_doc_ds_documento
go

