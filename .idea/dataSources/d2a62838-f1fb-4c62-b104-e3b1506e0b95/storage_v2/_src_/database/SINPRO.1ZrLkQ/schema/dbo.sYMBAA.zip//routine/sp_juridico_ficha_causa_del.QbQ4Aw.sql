

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_causa_del
Descriçao:	Apaga causa
Data da Criaçao: 15/09/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_causa_del
(
@Pnr_ficha 	INT,
@Pcd_causa 	INT
)
AS

DELETE
FROM
	tb_jur_ficha_causa
WHERE     
	jur_fca_nr_ficha = @Pnr_ficha
	AND jur_fca_cd_causa =@Pcd_causa

go

