/*******************************************************************
Objeto criado: 	 sp_eleicao_cand_lista_sel
Descriçao:	Seleciona Candidatos
Data da Criaçao: 12/09/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_cand_lista_sel
(
@Pds_eleicao		CHAR(4),
@Pds_chapa		CHAR(2),
@Pfl_tipo		TINYINT = 0
)
AS

if @Pfl_tipo = 0
	SELECT     
		CDA.ele_cda_cd_candidato, 
		CP.Nome, 
		CAR.ele_car_ds_cargo,
		'(' + CP.DDD_Telefone_Celular + ') ' + CP.Telefone_Celular AS Celular
	
	FROM         
		tb_ele_cand_dados CDA INNER JOIN
		Cadastro_Professores CP ON CDA.ele_cda_cd_candidato = CP.Codigo_Professor
		INNER JOIN tb_eleicao_cargo CAR ON CDA.ele_cda_nr_cargo = CAR.ele_car_nr_cargo
	WHERE     
		CDA.ele_cda_ds_eleicao = @Pds_eleicao 
		AND CDA.ele_cda_ds_chapa = @Pds_chapa
	ORDER BY
		 CDA.ele_cda_nr_cargo, CDA.ele_cda_ds_posicao, CP.Nome
ELSE
	SELECT     
		CP.Nome +
		CASE CDA.ele_cda_nr_cargo
			WHEN 0   THEN ' - Presidente'
			WHEN 1   THEN ' - 1º Vice-Presidente'
			WHEN 2   THEN ' - 2º Vice-Presidente'
			WHEN 3   THEN ' - 3º Vice-Presidente'
			WHEN 4   THEN ' - Secretário Geral'
			WHEN 5   THEN ' - 1º Secretário'
			WHEN 6   THEN ' - Tesoureiro Geral'
			WHEN 7   THEN ' - 1º Tesoureiro'
			WHEN 8   THEN ' - Procurador'
			ELSE ''
		END AS ele_cda_ds_nome,
		ele_cda_nr_cargo,
		'(' + CP.DDD_Telefone_Celular + ') ' + CP.Telefone_Celular AS Celular
	
	FROM         
		tb_ele_cand_dados CDA INNER JOIN
		Cadastro_Professores CP ON CDA.ele_cda_cd_candidato = CP.Codigo_Professor
	WHERE     
		CDA.ele_cda_ds_eleicao = @Pds_eleicao 
		AND CDA.ele_cda_ds_chapa = @Pds_chapa
	ORDER BY
		 CDA.ele_cda_nr_cargo, CDA.ele_cda_ds_posicao, CP.Nome
go

