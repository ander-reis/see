

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_professor_ins
Descriçao:	 Inserir Professor na Ficha de Consulta
Data da Criaçao: 28/02/2007
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_professor_ins
(
@Pnr_ficha 			INT,
@Pcd_professor 		NVARCHAR(6),
@Pdt_admissao			DATETIME,
@Pdt_demissao			DATETIME,
@Pds_ctps			NVARCHAR(10),
@Pds_ctps_serie		NVARCHAR(7),
@Pds_funcao			NVARCHAR(20),
@Pvl_salario			DECIMAL(10,2),
@Pfl_pre_escola		TINYINT,
@Pfl_aulas_14			TINYINT,
@Pnr_aulas_14			TINYINT,
@Pfl_aulas_58			TINYINT,
@Pnr_aulas_58			TINYINT,
@Pfl_aulas_ens_medio		TINYINT,
@Pnr_aulas_ens_medio		TINYINT,
@Pfl_aulas_ens_superior	TINYINT,
@Pnr_aulas_ens_superior	TINYINT,
@Pfl_aulas_tecnico		TINYINT,
@Pnr_aulas_tecnico		TINYINT,
@Pfl_aulas_supletivo		TINYINT,
@Pnr_aulas_supletivo		TINYINT,
@Pfl_aulas_curso_livre		TINYINT,
@Pnr_aulas_curso_livre		TINYINT,
@Pds_rg			NVARCHAR(12),
@Pds_expedidor		NVARCHAR(6),
@Pnr_pis			NVARCHAR(15),
@Pnm_mae			NVARCHAR(100),
@Pfl_estado_civil		TINYINT,
@Pds_nacionalidade		NVARCHAR(20),
@Pnr_banco			NVARCHAR(3),
@Pnr_agencia			NVARCHAR(8),
@Pnr_conta			NVARCHAR(18),
@Pfl_poupanca			TINYINT,
@Pfl_conjunta			TINYINT,
@Pfl_receber			TINYINT,
@Pnm_inventariante		NVARCHAR(100),
@Pds_cpf_inventariante		NVARCHAR(14)
)
AS

UPDATE Cadastro_Professores SET
	RG			= @Pds_rg,
	Orgao_Expedidor	= @Pds_expedidor,
	PIS			= @Pnr_pis,
	Nome_Mae		= @Pnm_mae,
	Estado_Civil		= @Pfl_estado_civil,
	Naturalidade		= @Pds_nacionalidade,
	Banco			= @Pnr_banco,
	Agencia			= @Pnr_agencia,
	Conta			= @Pnr_conta,
	Poupanca		= @Pfl_poupanca,
	Conjunta		= @Pfl_conjunta
WHERE Codigo_Professor = @Pcd_professor

INSERT INTO tb_jur_ficha_professor
	(jur_fip_nr_ficha,
	jur_fip_cd_professor,
	jur_fip_dt_admissao,
	jur_fip_dt_demissao,
	jur_fip_ds_ctps,
	jur_fip_ds_ctps_serie,
	jur_fip_ds_funcao, 
	jur_fip_vl_salario,
	jur_fip_fl_pre_escola,
	jur_fip_fl_aulas_14,
	jur_fip_nr_aulas_14,
	jur_fip_fl_aulas_58,
	jur_fip_nr_aulas_58, 
	jur_fip_fl_aulas_ens_medio,
	jur_fip_nr_aulas_ens_medio,
	jur_fip_fl_aulas_ens_superior,
	jur_fip_nr_aulas_ens_superior,
	jur_fip_fl_aulas_tecnico, 
	jur_fip_nr_aulas_tecnico,
	jur_fip_fl_aulas_supletivo,
	jur_fip_nr_aulas_supletivo,
	jur_fip_fl_aulas_curso_livre,
	jur_fip_nr_aulas_curso_livre,
	jur_fip_fl_receber,
	jur_fip_nm_inventariante,
	jur_fip_ds_cpf_inventariante)
VALUES
	(@Pnr_ficha,
	@Pcd_professor,
	@Pdt_admissao,
	@Pdt_demissao,
	@Pds_ctps,
	@Pds_ctps_serie,
	@Pds_funcao,
	@Pvl_salario,
	@Pfl_pre_escola,
	@Pfl_aulas_14,
	@Pnr_aulas_14,
	@Pfl_aulas_58,
	@Pnr_aulas_58,
	@Pfl_aulas_ens_medio,
	@Pnr_aulas_ens_medio,
	@Pfl_aulas_ens_superior,
	@Pnr_aulas_ens_superior,
	@Pfl_aulas_tecnico,
	@Pnr_aulas_tecnico,
	@Pfl_aulas_supletivo,
	@Pnr_aulas_supletivo,
	@Pfl_aulas_curso_livre,
	@Pnr_aulas_curso_livre,
	@Pfl_receber,
	@Pnm_inventariante,
	@Pds_cpf_inventariante)
go

