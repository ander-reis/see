

/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_ins
Descriçao:	Cadastra a Audiencia
Data da Criaçao: 08/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_ins
(
@Pcd_audiencia	INT,
@Pnr_pasta		NVARCHAR(8),
@Pdt_audiencia		DATETIME,
@Phr_audiencia		DATETIME,
@Pcd_advogado	INT,
@Pfl_audiencia		TINYINT,
@Pfl_retorno		TINYINT,
@Pnm_cadastrado	NVARCHAR(30),
@Pdt_cadastrado	DATETIME,
@Pfl_realizada		TINYINT = 0,
@Pfl_bloquear		TINYINT = 0,
@Pnr_mesa		NVARCHAR(10)=0
)

AS

INSERT INTO    tb_jur_audiencia
	(jur_aud_cd_audiencia,
	jur_aud_nr_pasta,
	jur_aud_dt_audiencia,
	jur_aud_hr_audiencia,
	jur_aud_cd_advogado,
	jur_aud_fl_audiencia,
	jur_aud_fl_retorno,
	jur_aud_nm_cadastrado,
	jur_aud_dt_cadastrado,
	jur_aud_fl_situacao,
	jur_aud_fl_realizada,
	jur_aud_fl_bloquear,
	jur_aud_nr_mesa)
VALUES
	(@Pcd_audiencia,
	@Pnr_pasta,
	@Pdt_audiencia,
	@Phr_audiencia	,
	@Pcd_advogado,
	@Pfl_audiencia,
	@Pfl_retorno,
	@Pnm_cadastrado,
	@Pdt_cadastrado,
	0,
	@Pfl_realizada,
	@Pfl_bloquear,
	@Pnr_mesa)
go

