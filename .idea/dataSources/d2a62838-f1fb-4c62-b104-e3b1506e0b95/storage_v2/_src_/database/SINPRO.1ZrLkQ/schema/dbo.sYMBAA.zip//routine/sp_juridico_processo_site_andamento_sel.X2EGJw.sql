/*******************************************************************
Objeto criado: 	 sp_juridico_processo_site_andamento_sel
Descriçao:	Seleciona Andamentos do Processo do Professor para o Site
Data da Criaçao: 23/12/2008
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_site_andamento_sel
(
@Pnr_pasta	VARCHAR(8)
)

AS
DECLARE @Vnr_andamento	AS INT

SELECT @Vnr_andamento = COUNT(1)
FROM
	tb_jur_processo_agendamento PCA 
	INNER JOIN tb_jur_cadastro_andamento CAN ON PCA.jur_pca_cd_andamento = CAN.jur_and_cd_andamento
WHERE
	PCA.jur_pca_nr_pasta = @Pnr_pasta
	AND CONVERT(CHAR(10), PCA.jur_pca_dt_agendamento, 111) >= '2008/11/01'
	AND CONVERT(CHAR(10), PCA.jur_pca_dt_agendamento, 111) <> '2013/04/08'

IF @Vnr_andamento > 0 
	SELECT
		PRC.jur_prc_nr_processo,
		FIP.jur_fip_cd_professor,
		CONVERT(CHAR(10), PCA.jur_pca_dt_agendamento, 103) AS jur_pca_dt_agendamento,
		CAN.jur_and_ds_descricao,
		UPPER(PCA.jur_pca_ds_observacao) AS jur_pca_ds_observacao, 
		
		CASE PCA.jur_pca_fl_concluido
			WHEN 0 THEN 'NÃO'
			ELSE 'SIM'
		END AS jur_pca_fl_concluido,
		CONVERT(CHAR(10), PCA.jur_pca_dt_cadastro, 103) AS jur_pca_dt_cadastro

	FROM
		tb_jur_processo_agendamento PCA
		INNER JOIN tb_jur_cadastro_andamento CAN ON PCA.jur_pca_cd_andamento = CAN.jur_and_cd_andamento
		INNER JOIN tb_jur_processo PRC ON PCA.jur_pca_nr_pasta = PRC.jur_prc_nr_pasta
		INNER JOIN tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha
		INNER JOIN tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha
	WHERE
		PCA.jur_pca_nr_pasta = @Pnr_pasta
		AND CONVERT(CHAR(10), PCA.jur_pca_dt_agendamento, 111) >= '2008/11/01' AND CONVERT(CHAR(10), PCA.jur_pca_dt_agendamento, 111)  <= CONVERT(CHAR(10), GETDATE(), 111) 
		AND ( CONVERT(CHAR(10), PCA.jur_pca_dt_agendamento, 111) <> '2013/04/08'  AND PCA.jur_pca_nr_pasta NOT IN ('094/2006', '085/2006', '395/2006', '248/2006', '154/2003', '259/2008', '181/2006', '050/2007', '036/2004', '189/2005', '302/2006', '210/2003', '017/2004', '310/2006', '243/2007', '042/2006', '245/2006', '039/2006', '064/2009', '170/2004', '218/2003', '035/2004', '125/2003','160/2003','261/2003','002/2003','175/2004','123/1998','034/2004'))
--		AND PCA.jur_pca_fl_concluido = 1
	ORDER BY CONVERT(CHAR(10), PCA.jur_pca_dt_agendamento, 111) DESC
ELSE
	SELECT TOP 1
		PRC.jur_prc_nr_processo,
		FIP.jur_fip_cd_professor,
		CONVERT(CHAR(10), PCA.jur_pca_dt_agendamento, 103) AS jur_pca_dt_agendamento,
		CAN.jur_and_ds_descricao,
		UPPER(PCA.jur_pca_ds_observacao) AS jur_pca_ds_observacao,  

            		CASE PCA.jur_pca_fl_concluido
			WHEN 0 THEN 'NÃO'
			ELSE 'SIM'
		END AS jur_pca_fl_concluido,
		CONVERT(CHAR(10), PCA.jur_pca_dt_cadastro, 103) AS jur_pca_dt_cadastro

	FROM
		tb_jur_processo_agendamento PCA
		INNER JOIN tb_jur_cadastro_andamento CAN ON PCA.jur_pca_cd_andamento = CAN.jur_and_cd_andamento
		INNER JOIN tb_jur_processo PRC ON PCA.jur_pca_nr_pasta = PRC.jur_prc_nr_pasta
		INNER JOIN tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha
		INNER JOIN tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha	
	WHERE
		PCA.jur_pca_nr_pasta = @Pnr_pasta
		AND ( CONVERT(CHAR(10), PCA.jur_pca_dt_agendamento, 111) <> '2013/04/08'  AND PCA.jur_pca_nr_pasta NOT IN ('094/2006', '085/2006', '395/2006', '248/2006', '154/2003', '259/2008', '181/2006', '050/2007', '036/2004', '189/2005', '302/2006', '210/2003', '017/2004', '310/2006', '243/2007', '042/2006', '245/2006', '039/2006', '064/2009', '170/2004', '218/2003', '035/2004', '125/2003','160/2003','261/2003','002/2003','175/2004','123/1998','034/2004'))
	ORDER BY  CONVERT(CHAR(10), PCA.jur_pca_dt_agendamento, 111)  DESC
go

