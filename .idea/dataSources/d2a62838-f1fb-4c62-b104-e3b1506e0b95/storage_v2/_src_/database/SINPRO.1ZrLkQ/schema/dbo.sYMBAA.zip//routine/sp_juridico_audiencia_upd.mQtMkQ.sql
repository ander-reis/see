/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_upd
Descriçao:	Atualiza a Audiencia
Data da Criaçao: 08/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_upd
(
@Pcd_audiencia	INT,
@Pnr_pasta		NVARCHAR(8),
@Pdt_audiencia		DATETIME,
@Phr_audiencia		DATETIME,
@Pcd_advogado	INT,
@Pfl_audiencia		TINYINT,
@Pfl_retorno		TINYINT,
@Pnm_cadastrado	NVARCHAR(30),
@Pdt_cadastrado	DATETIME,
@Pfl_situacao		TINYINT,
@Pfl_realizada		TINYINT = 0,
@Pfl_bloquear		TINYINT = 0,
@Pnr_mesa		NVARCHAR(10) = 0
)

AS

UPDATE    tb_jur_audiencia SET
	jur_aud_dt_audiencia	= @Pdt_audiencia,
	jur_aud_hr_audiencia	= @Phr_audiencia,
	jur_aud_cd_advogado	= @Pcd_advogado,
	jur_aud_fl_audiencia	= @Pfl_audiencia,
	jur_aud_fl_retorno	= @Pfl_retorno,
	jur_aud_fl_situacao	= @Pfl_situacao,
	jur_aud_fl_realizada	= @Pfl_realizada,
	jur_aud_fl_bloquear	= @Pfl_bloquear,
	jur_aud_nr_mesa	= @Pnr_mesa
WHERE jur_aud_cd_audiencia = @Pcd_audiencia
go

