

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_capa_imp
Descriçao:	Seleciona a Ficha de Consulta para Impressão da Capa do Processo
Data da Criaçao: 28/03/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_capa_imp
(
@Pnr_ficha		INT
)
AS

SELECT     
	FIC.jur_fic_nr_ficha, 
	CP.Nome,
	CP.Endereco + ', ' + CP.Numero + ' ' + CP.Complemento AS endereco,
	CP.Bairro + ' - ' + CP.Cidade + ' - ' +  CP.Estado + ' - ' + CP.CEP AS complemento,
	'(' + CP.DDD_Telefone_Residencial + ') ' + CP.Telefone_Residencial + ' / (' + CP.DDD_Telefone_Comercial + ')' + CP.Telefone_Comercial + ' / (' + CP.DDD_Telefone_Celular + ')' + CP.Telefone_Celular AS fone,
	LEFT(CASE   WHEN ISNULL(pro_ema_ds_email1,'') <> '' THEN ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END 
		         + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END,
		         LEN(CASE   WHEN  ISNULL(pro_ema_ds_email1,'') <> '' THEN  ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END) -1) AS Email,
	CE.Razao_Social,
	FIC.jur_fic_ds_01,
	FIC.jur_fic_ds_02,
	FIC.jur_fic_ds_03,
	FIC.jur_fic_ds_04,
	FIC.jur_fic_ds_05,
	
	CASE FIC.jur_fic_fl_categoria
		WHEN 0 THEN 'BÁSICO'
		WHEN 1 THEN 'SUPERIOR'
		ELSE ''
	END AS jur_fic_fl_categoria,	

	CASE FIC.jur_fic_fl_testemunha
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS jur_fic_fl_testemunha,
	
	CASE FIC.jur_fic_fl_ctps
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS jur_fic_fl_ctps,
             
	CASE FIC.jur_fic_fl_fgts
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS jur_fic_fl_fgts,
	
	CASE FIC.jur_fic_fl_desemprego
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS jur_fic_fl_desemprego,

	CASE FIC.jur_fic_fl_processo
		WHEN 0 THEN 'INVIDIDUAL'
		WHEN 1 THEN 'COLETIVO'
		ELSE 'PLÚRIMA'
	END AS jur_fic_fl_processo	

FROM
	tb_jur_ficha_professor FIP 
	INNER JOIN Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	LEFT JOIN tb_professor_email EMA ON CP.Codigo_Professor = EMA.pro_ema_cd_professor
	INNER JOIN tb_jur_ficha_consulta FIC
	INNER JOIN Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha
WHERE 
	(FIC.jur_fic_nr_ficha = @Pnr_ficha  AND FIC.jur_fic_fl_processo = 0) OR (FIC.jur_fic_nr_ficha = @Pnr_ficha AND FIP.jur_fip_cd_professor = '00000')
go

