


/*******************************************************************
Objeto criado: 	 sp_previdencia_andamento_resumo_sel
Descriçao:	Seleciona o Resumo do Andamento de Aposentadoria
Data da Criaçao: 11/09/2007
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_previdencia_andamento_resumo_sel
(
@Pfl_situacao		INT,
@Pdt_inicio	DATETIME,
@Pdt_fim	DATETIME
)
AS

IF  @Pfl_situacao=0 --Com Entrada--
	SELECT    
		 CASE prev_pra_fl_andamento WHEN '0' THEN 'Pab' WHEN '1' THEN 'Indeferido' WHEN '2' THEN 'Concedido' WHEN '3' THEN 'Exigência' WHEN '4' THEN  'Andamento' WHEN '5' THEN 'Recurso' WHEN '6' THEN 'Revisão-Brás' WHEN '7' THEN 'Dupla Atividade'  WHEN '8' THEN 'Cancelado' WHEN '9' THEN 'Consulta'   WHEN '10' THEN 'Revisão-Xavier 'END AS ANDAMENTO, COUNT(1) AS TOTAL
	FROM         
		tb_prev_atendimento 
	WHERE
		(prev_pra_dt_entrada BETWEEN @Pdt_inicio AND @Pdt_fim) AND (prev_pra_fl_situacao <> '1') AND (prev_pra_dt_entrada<>'01/01/1900')
	GROUP BY 
		prev_pra_fl_andamento
ELSE IF @Pfl_situacao=1 --Sem Entrada--
	SELECT    
			 CASE prev_pra_fl_andamento WHEN '0' THEN 'Pab' WHEN '1' THEN 'Indeferido' WHEN '2' THEN 'Concedido' WHEN '3' THEN 'Exigência' WHEN '4' THEN  'Andamento' WHEN '5' THEN 'Recurso' WHEN '6' THEN 'Revisão-Brás' WHEN '7' THEN 'Dupla Atividade'  WHEN '8' THEN 'Cancelado' WHEN '9' THEN 'Consulta'   WHEN '10' THEN 'Revisão-Xavier 'END AS ANDAMENTO, COUNT(1) AS TOTAL
	FROM         
		tb_prev_atendimento 
	WHERE
		(prev_pra_dt_cadastro BETWEEN @Pdt_inicio AND @Pdt_fim) AND (prev_pra_fl_situacao <> '1') AND (prev_pra_dt_entrada='01/01/1900')
	GROUP BY 
		prev_pra_fl_andamento
ELSE IF @Pfl_situacao=2 --Sem Entrada--
	SELECT    
		 CASE prev_pra_fl_andamento WHEN '0' THEN 'Pab' WHEN '1' THEN 'Indeferido' WHEN '2' THEN 'Concedido' WHEN '3' THEN 'Exigência' WHEN '4' THEN  'Andamento' WHEN '5' THEN 'Recurso' WHEN '6' THEN 'Revisão-Brás' WHEN '7' THEN 'Dupla Atividade'  WHEN '8' THEN 'Cancelado' WHEN '9' THEN 'Consulta'   WHEN '10' THEN 'Revisão-Xavier 'END AS ANDAMENTO, COUNT(1) AS TOTAL
	FROM         
		tb_prev_atendimento 
	WHERE
		(prev_pra_dt_cadastro BETWEEN @Pdt_inicio AND @Pdt_fim) AND (prev_pra_fl_situacao <> '1') 
	GROUP BY 
		prev_pra_fl_andamento
go

