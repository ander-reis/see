/*******************************************************************
Objeto criado: 	 sp_escola_imagem_sel
Descriçao:	Seleciona as Imagens do Cadastro da Escola
Data da Criaçao: 30/01/2014
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_escola_imagem_sel
(
@Pcd_escola		NVARCHAR(18)
)
AS


SELECT
	IMG.esc_img_cd_imagem,
	IMG.esc_img_ds_arquivo,
	IMG.esc_img_ds_observacao,
	CONVERT(NVARCHAR(10), IMG.esc_img_dt_cadastro,103) AS esc_img_dt_cadastro,
	IMG.esc_img_nm_login,
	CONVERT(NVARCHAR(8),IMG.esc_img_dt_cadastro,108) AS esc_img_hr_cadastro
FROM
	tb_escola_imagem IMG
WHERE
	IMG.esc_img_cd_escola = @Pcd_escola
ORDER BY
	CONVERT(CHAR(10),IMG.esc_img_dt_cadastro,111) DESC,
	CONVERT(NVARCHAR(8),IMG.esc_img_dt_cadastro,108) DESC
go

