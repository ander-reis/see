/*******************************************************************
Objeto criado: 	 sp_juridico_leitura_email_sel
Descriçao:	Seleciona Todos as Fichas de Consultas liberadas para Leitura e avisa o professor por e-mail
Data da Criaçao: 22/11/2012
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_leitura_email_sel
AS

SELECT
	FIC.jur_fic_nr_ficha,
	CE.Razao_Social,
	CASE CP.Sexo
		WHEN 0 THEN 'Prezado Professor'
		ELSE 'Prezada Professora'
	END AS Tratamento,
	CP.Nome,
	EMA.pro_ema_ds_email1 + CASE WHEN EMA.pro_ema_ds_email2  <> '' THEN ';' + EMA.pro_ema_ds_email2 ELSE '' END AS pro_ema_ds_email1,
	ADV.jur_adv_ds_email
	
FROM
	Cadastro_Professores CP 
	INNER JOIN tb_jur_ficha_professor FIP 
	INNER JOIN tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha ON CP.Codigo_Professor = FIP.jur_fip_cd_professor 
	INNER JOIN Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola 
	LEFT    JOIN tb_professor_email EMA ON CP.Codigo_Professor = EMA.pro_ema_cd_professor 
	INNER JOIN tb_jur_cadastro_advogado ADV ON FIC.jur_fic_cd_advogado = ADV.jur_adv_cd_advogado
WHERE
	FIC.jur_fic_fl_email_leitura = 1
ORDER BY CP.Nome
go

