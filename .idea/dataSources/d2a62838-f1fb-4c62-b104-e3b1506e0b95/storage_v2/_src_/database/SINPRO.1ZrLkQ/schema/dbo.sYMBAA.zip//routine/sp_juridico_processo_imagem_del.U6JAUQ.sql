/*******************************************************************
Objeto criado: 	 sp_juridico_processo_imagem_del
Descriçao:	Apaga as Imagens do Processo
Data da Criaçao: 22/10/2008
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_imagem_del
(
@Pcd_imagem	INT
)

AS

DELETE 
FROM
	tb_jur_processo_imagem
WHERE
	jur_img_cd_imagem = @Pcd_imagem
go

