/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_denuncia_upd
Descriçao:	 Atualiza a Ficha da Denuncia
Data da Criaçao: 05/06/2013
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_denuncia_upd
(
@Pcd_denjur	 INT,
@Pnr_ficha 	 INT
)
AS

UPDATE    Irr_Juridico SET
	nr_ficha = @Pnr_ficha,
	data_ficha = GETDATE()
WHERE
	coddenjur = @Pcd_denjur
go

