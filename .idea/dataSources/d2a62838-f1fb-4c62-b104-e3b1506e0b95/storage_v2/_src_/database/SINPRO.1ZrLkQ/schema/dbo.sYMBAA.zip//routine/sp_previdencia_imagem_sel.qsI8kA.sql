/*******************************************************************
Objeto criado: 	 sp_previdencia_imagem_sel
Descriçao:	Seleciona as Imagens do Cadastro da Previdencia
Data da Criaçao: 18/08/2010
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_previdencia_imagem_sel
(
@Pcd_professor		NVARCHAR(6)
)
AS


SELECT
	prev_img_cd_imagem,
	prev_img_ds_arquivo,
	prev_img_ds_observacao,
	CONVERT(NVARCHAR(10), prev_img_dt_cadastro,103) AS prev_img_dt_cadastro,
	prev_img_nm_login,
	CONVERT(NVARCHAR(8),prev_img_dt_cadastro,108) AS prev_img_hr_cadastro
FROM
	tb_prev_atendimento_imagem
WHERE
	prev_img_cd_professor = @Pcd_professor
ORDER BY
	CONVERT(CHAR(10),prev_img_dt_cadastro,111) DESC,
	CONVERT(NVARCHAR(8),prev_img_dt_cadastro,108) DESC
go

