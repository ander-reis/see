/*******************************************************************
Objeto criado: 	 sp_eleicao_votos_sel_rel
Descriçao:	Seleciona Votos na Eleicao Para Relatório
Data da Criaçao: 20/10/2010
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_votos_sel_rel
(
@Pds_eleicao		CHAR(4),
@Pds_urna		INT = 0
)
AS

IF @Pds_urna <> 0
	SELECT     
		EVT.ele_evt_nr_eleitor, 
		EVT.ele_evt_nr_total_votos AS Votos, 
		EVT.ele_evt_nr_total_separado,
		EVT.ele_evt_nr_total_branco,
		EVT.ele_evt_nr_total_nulo,
		EVT.ele_evt_nr_inscrito,
		EVT.ele_evt_nr_normal,
		EVT.ele_evt_nr_desprezado,
		EVT.ele_evt_fl_status,
		EVT.ele_evt_ds_urna
	FROM tb_ele_votos EVT INNER JOIN
			tb_ele_datas EDT ON EVT.ele_evt_ds_eleicao = EDT.ele_edt_ds_eleicao
	WHERE EVT.ele_evt_ds_eleicao = @Pds_eleicao
		AND EVT.ele_evt_ds_urna = @Pds_urna
	ORDER BY EVT.ele_evt_ds_urna
ELSE
	SELECT     
		EVT.ele_evt_nr_eleitor, 
		EVT.ele_evt_nr_total_votos AS Votos, 
		EVT.ele_evt_nr_total_separado,
		EVT.ele_evt_nr_total_branco,
		EVT.ele_evt_nr_total_nulo,
		EVT.ele_evt_nr_inscrito,
		EVT.ele_evt_nr_normal,
		EVT.ele_evt_nr_desprezado,
		EVT.ele_evt_fl_status,
		EVT.ele_evt_ds_urna
	FROM tb_ele_votos EVT INNER JOIN
			tb_ele_datas EDT ON EVT.ele_evt_ds_eleicao = EDT.ele_edt_ds_eleicao
	WHERE EVT.ele_evt_ds_eleicao = @Pds_eleicao
	ORDER BY EVT.ele_evt_ds_urna
go

