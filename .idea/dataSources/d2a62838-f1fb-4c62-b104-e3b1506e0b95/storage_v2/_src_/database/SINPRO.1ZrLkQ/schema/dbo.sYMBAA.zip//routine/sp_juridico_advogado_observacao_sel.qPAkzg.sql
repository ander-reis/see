
/*******************************************************************
Objeto criado: 	 sp_juridico_advogado_observacao_sel
Descriçao:	Seleciona Observação dos Advogados
Data da Criaçao: 22/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_advogado_observacao_sel
(
@Pcd_advogado		INT

)
AS

SELECT 
	RTRIM(CASE CONVERT(CHAR(10),jur_oad_dt_observacao,103)
		WHEN '01/01/1900' THEN ''
		ELSE	CONVERT(CHAR(10),jur_oad_dt_observacao,103)
	END)					AS jur_oad_dt_observacao,

	jur_oad_ds_observacao,

	RTRIM(ISNULL(jur_oad_nm_login,''))	AS jur_oad_nm_login,

	RTRIM(CASE CONVERT(CHAR(10),jur_oad_dt_hora,108)
		WHEN '00:00:00' THEN ''
		ELSE	CONVERT(CHAR(10),jur_oad_dt_hora,108)
	END) 					 AS jur_oad_dt_hora

FROM         tb_jur_cadastro_advogado_obs ADV
WHERE     jur_oad_cd_advogado = @Pcd_advogado
ORDER BY CONVERT(CHAR(10),jur_oad_dt_observacao,111) DESC, CONVERT(CHAR(8),jur_oad_dt_hora,108) DESC
go

