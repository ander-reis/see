/*******************************************************************
Objeto criado: 	 sp_juridico_processo_site_andamento_sel
Descriçao:	Seleciona Andamentos do Processo do Professor para o E-mail
Data da Criaçao: 27/07/2011
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_email_andamento_sel
(
@Pdt_cadastro	NVARCHAR(10),
@Pnr_pasta	VARCHAR(8) = '',
@Pfl_tipo	TINYINT = 0
)

AS

IF @Pfl_tipo = 0
	SELECT     CP.Nome, 
		CASE CP.Sexo
			WHEN 0 THEN 'Prezado Professor'
			ELSE 'Prezada Professora'
		END AS Tratamento,
	CE.Razao_Social, PRC.jur_prc_nr_pasta, PRC.jur_prc_nr_processo, PRC.jur_prc_cd_vara, CONVERT(CHAR(10),PCA.jur_pca_dt_agendamento,103) AS jur_pca_dt_agendamento, CAN.jur_and_ds_descricao, PCA.jur_pca_ds_observacao, PCA.jur_pca_fl_concluido,
	EMA.pro_ema_ds_email1
	FROM         tb_jur_processo_agendamento PCA
		INNER JOIN tb_jur_processo PRC ON PCA.jur_pca_nr_pasta = PRC.jur_prc_nr_pasta
		INNER JOIN tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha
		INNER JOIN Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola
		INNER JOIN tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha
		INNER JOIN Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
		INNER JOIN tb_jur_cadastro_andamento CAN ON PCA.jur_pca_cd_andamento = CAN.jur_and_cd_andamento
		INNER JOIN tb_professor_email EMA ON CP.Codigo_Professor = EMA.pro_ema_cd_professor
	WHERE     
		CONVERT(CHAR(10),PCA.jur_pca_dt_cadastro,111) = CONVERT(CHAR(10),DATEADD(day,-1,@Pdt_cadastro),111)
		AND PCA.jur_pca_fl_concluido = 1
		AND EMA.pro_ema_ds_email1 <> ''
		AND FIC.jur_fic_fl_processo = 0
		AND PRC.jur_prc_nr_pasta NOT IN ('094/2006', '085/2006', '395/2006', '248/2006', '154/2003', '259/2008', '181/2006', '050/2007', '036/2004', '189/2005', '302/2006', '210/2003', '017/2004', '310/2006', '243/2007', '042/2006', '245/2006', '039/2006', '064/2009', '170/2004', '218/2003', '035/2004', '125/2003','160/2003','261/2003','002/2003','175/2004','123/1998','034/2004')
		AND  CAN.jur_and_cd_andamento <> 146
	ORDER BY 
		PRC.jur_prc_nr_pasta, 
		CONVERT(CHAR(10), PCA.jur_pca_dt_agendamento, 111) DESC
ELSE IF @Pfl_tipo = 1
	exec sp_juridico_processo_site_andamento_sel @Pnr_pasta
go

