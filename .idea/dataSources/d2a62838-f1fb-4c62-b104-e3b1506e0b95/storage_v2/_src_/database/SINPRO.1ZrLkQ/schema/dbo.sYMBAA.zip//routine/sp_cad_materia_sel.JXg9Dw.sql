
/*******************************************************************
Objeto criado: 	 sp_cad_materia_sel
Descriçao:	Carrega Materias
Saída:		
Data da Criaçao: 14/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_cad_materia_sel
AS

SELECT 
	Codigo_Materia,
	Materia 
FROM Materia 
ORDER BY Materia


go

