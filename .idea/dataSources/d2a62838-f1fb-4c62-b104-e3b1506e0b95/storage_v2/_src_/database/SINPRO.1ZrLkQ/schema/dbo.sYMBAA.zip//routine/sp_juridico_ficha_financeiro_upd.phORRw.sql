
/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_financeiro_upd
Descriçao:	 Atualizar os Dados Bancários de Pagamentos de Processos Existentes
Data da Criaçao: 28/02/2007
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_financeiro_upd
(
@Pnr_pagamento		INT,
@Pnr_banco			NVARCHAR(3),
@Pnr_agencia			NVARCHAR(8),
@Pnr_conta			NVARCHAR(18),
@Pfl_poupanca			TINYINT,
@Pfl_conjunta			TINYINT
)
AS

DECLARE @Vds_forma		NVARCHAR(3)

IF @Pnr_banco <> '000' 
	SET @Vds_forma = 'DOC'
ELSE	
	SET @Vds_forma = 'CHQ'	

UPDATE tb_jur_processo_financeiro SET
	jur_pcf_cd_banco	= @Pnr_banco,
	jur_pcf_nr_agencia	= @Pnr_agencia,
	jur_pcf_nr_conta	= @Pnr_conta,
	jur_pcf_fl_poupanca	= @Pfl_poupanca,
	jur_pcf_fl_conjunta	= @Pfl_conjunta,
	jur_pcf_ds_forma	= @Vds_forma,
	jur_pcf_fl_siga		= 3
WHERE jur_pcf_nr_pagamento	= @Pnr_pagamento
go

