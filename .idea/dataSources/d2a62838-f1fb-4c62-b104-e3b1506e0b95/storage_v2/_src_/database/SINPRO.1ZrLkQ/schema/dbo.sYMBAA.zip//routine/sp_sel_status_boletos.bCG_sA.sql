
/*******************************************************************
Objeto criado: 	 sp_sel_status_boletos
Descriçao:	Informa situação do boleto
Entrada:	
Saída:		
Data da Criaçao: 15/04/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_sel_status_boletos
(
@pVch_cd_escola		varchar(18),
@pInt_cd_arrecadacao		INT,
@pVch_saida			VARCHAR(12) OUTPUT
)
AS
DECLARE @vInt_Necessidade  INT
DECLARE @vInt_Pagou  INT
DECLARE @vInt_NaoPagou  INT
DECLARE @vInt_NaoGerou  INT

-- Verifica a Necessidade de Gerar o Boleto 

SET @vInt_Necessidade = (SELECT	TOP 1 COUNT(1)
	FROM 		Professores_Geral_Escolas AS PGE, Cadastro_Arrecadacoes AS ARR
	WHERE 	PGE.CGC_Escola =@pVch_cd_escola
		AND	ARR.cd_arrecadacao = @pInt_cd_arrecadacao
		AND 	(PGE.Cobranca = 1 OR ARR.cd_tipo_boleto <> 3)
		AND 	(EXISTS (SELECT 1 
			FROM Todos_Professores TOD
			WHERE fl_cobrado = 'N'
			AND TOD.cd_professor = PGE.CPF) OR ARR.cd_tipo_boleto <> 2)
		AND (
			PGE.Data_Cobranca < DATEADD(month,-1,DATEADD(day,-day(ARR.dt_vencimento)+ARR.nr_liberaboleto,ARR.dt_vencimento))
			OR ARR.cd_tipo_boleto <> 3
		        )
		AND ( 
			PGE.Situacao <> 9 OR 
			ARR.cd_tipo_boleto IN(1,3)
		         )
)	

-- Verifica se o Boleto já foi Pago 
SET @vInt_Pagou = (SELECT TOP 1 COUNT(1)
	FROM
		Boletos_Unificados AS BU
	WHERE
	BU.cd_arrecadacao = @pInt_cd_arrecadacao
	AND BU.cd_escola = @pVch_cd_escola
	AND BU.fl_cancelado = 'N'
	AND EXISTS (SELECT 1 FROM Historico_Status_Boletos AS HSB
					WHERE cd_status = 5
					AND HSB.cd_arrecadacao = BU.cd_arrecadacao
					AND HSB.cd_escola = BU.cd_escola
					AND HSB.nr_via = BU.nr_via)
	AND	BU.nr_via	=	(SELECT
							MAX(nr_via) as nr_via
						FROM
							Boletos_Unificados AS BUS
						WHERE
							BUS.cd_escola = BU.cd_escola
						AND	BUS.cd_arrecadacao = BU.cd_arrecadacao)
)

SET @vInt_NaoGerou = ( 	SELECT TOP 1 COUNT(1)
FROM 		Professores_Geral_Escolas AS PGE
	INNER JOIN 	Cadastro_Escolas AS ESC
		ON ESC.CGC_Escola = PGE.CGC_Escola
	INNER JOIN 	Boletos_Unificados BU
		ON ESC.CGC_Escola = BU.cd_escola
	INNER JOIN	Cadastro_Arrecadacoes AS ARR
		ON ARR.cd_arrecadacao = BU.cd_arrecadacao
	WHERE 		   
		 BU.cd_arrecadacao = @pInt_cd_arrecadacao
		AND BU.cd_escola = @pVch_cd_escola
		AND 	(PGE.Cobranca = 1 OR ARR.cd_tipo_boleto <> 3)
		AND 	(EXISTS (SELECT 1 
			FROM Todos_Professores AS TOD
			WHERE fl_cobrado = 'N'
			AND TOD.cd_professor = PGE.CPF) OR ARR.cd_tipo_boleto <> 2)
		AND ARR.cd_tipo_boleto <> 2
)

IF @vInt_Pagou <> 0 
	SET @pVch_saida =  'PAGOU'
ELSE IF @vInt_Necessidade <> 0 
	IF @vInt_NaoGerou = 0
		SET @pVch_saida = 'NÃO GEROU'
	ELSE
		SET @pVch_saida = 'NÃO PAGOU'
ELSE
	SET @pVch_saida =  'NÃO PRECISA'


/*
PRINT @vInt_Necessidade
PRINT @vInt_Pagou
PRINT @vInt_NaoGerou


IF @vInt_Pagou <> 0 
	PRINT 'PAGOU'
ELSE IF @vInt_Necessidade <> 0 
	IF @vInt_NaoGerou = 0
		PRINT 'NÃO GEROU'
	ELSE
		PRINT 'NÃO PAGOU'
ELSE
	PRINT 'NÃO PRECISA'
*/
go

