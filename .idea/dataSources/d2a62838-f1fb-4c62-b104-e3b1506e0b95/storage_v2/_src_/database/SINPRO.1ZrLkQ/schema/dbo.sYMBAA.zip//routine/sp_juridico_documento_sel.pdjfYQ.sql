

/*******************************************************************
Objeto criado: 	 sp_juridico_causa_sel
Descriçao:	Seleciona Cadastro de Documentos
Data da Criaçao: 28/02/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_documento_sel
AS

SELECT     
	jur_doc_cd_documento,
	jur_doc_ds_documento
FROM
	tb_jur_cadastro_documento
WHERE 
	jur_doc_cd_documento <> 28
ORDER BY
	jur_doc_ds_documento
go

