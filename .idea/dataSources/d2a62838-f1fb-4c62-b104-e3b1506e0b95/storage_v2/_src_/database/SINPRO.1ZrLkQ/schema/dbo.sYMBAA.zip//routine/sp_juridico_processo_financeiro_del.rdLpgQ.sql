/*******************************************************************
Objeto criado: 	 sp_juridico_processo_financeiro_del
Descriçao:	Altera o Status para o Microsiga processar a Exclusão do Título
Data da Criaçao: 26/07/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_financeiro_del
(
@Pnr_pagamento	INT,
@Pfl_tipo		TINYINT
)
AS

IF @Pfl_tipo = 1
	UPDATE tb_jur_processo_financeiro SET
		jur_pcf_fl_siga = 6
	WHERE 
		jur_pcf_nr_pagamento = @Pnr_pagamento
ELSE
	DELETE
	FROM
		tb_jur_processo_financeiro	
	WHERE 
		jur_pcf_nr_pagamento = @Pnr_pagamento
go

