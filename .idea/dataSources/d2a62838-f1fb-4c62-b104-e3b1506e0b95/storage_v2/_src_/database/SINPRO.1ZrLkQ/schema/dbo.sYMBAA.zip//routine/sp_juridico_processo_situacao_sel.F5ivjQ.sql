--*******************************************************************
--Objeto criado: 	 sp_juridico_processo_situacao_sel
--**Descriçao:	Seleciona as situações dos processos do jurídico
--Data da Criaçao: 22/02/20088
--Autor:		Adriana - SinproSP
--*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_situacao_sel
(
@Pdt_inicio		DATETIME,
@Pdt_fim		DATETIME,
@Pfl_situacao		INT,
@Pfl_encerramento	INT
)

AS

IF @Pfl_situacao<>6 AND @Pfl_encerramento<>'2'   -- Especifico E Selecionando encerramento
	SELECT     
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao, 
		CASE PRC.jur_prc_fl_situacao 
			WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Sentença' 
			WHEN '2' THEN 'Cancelado'
			WHEN '3' THEN 'Substabelecido para Terceiro'
			WHEN '4' THEN 'Acordo em Audiência' 
			WHEN '5' THEN 'Arquivamento em Audiência'  END AS SITUACAO  ,
		CASE PRC.jur_prc_fl_encerrado 
			WHEN '0' THEN 'NÃO' 
			WHEN '1' THEN 'SIM' END AS ENCERRADO,
                     	 PRC.jur_prc_dt_final
	FROM    tb_jur_ficha_professor FIP INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
	             tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE 	
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim
		AND FIP.jur_fip_cd_professor <> N'00000' 
		AND FIC.jur_fic_fl_processo = 0 
		AND PRC.jur_prc_fl_situacao=@Pfl_situacao
		AND PRC.jur_prc_fl_encerrado=@Pfl_encerramento

	UNION

	SELECT     
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao, 
		CASE PRC.jur_prc_fl_situacao 
			WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Sentença' 
			WHEN '2' THEN 'Cancelado'
			WHEN '3' THEN 'Substabelecido para Terceiro'
			WHEN '4' THEN 'Acordo em Audiência' 
			WHEN '5' THEN 'Arquivamento em Audiência'  END AS SITUACAO  ,
		CASE PRC.jur_prc_fl_encerrado 
			WHEN '0' THEN 'NÃO' 
			WHEN '1' THEN 'SIM' END AS ENCERRADO,
                      	PRC.jur_prc_dt_final
	FROM  tb_jur_ficha_professor FIP INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE 	
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim
		AND FIP.jur_fip_cd_professor = '00000' 
		AND FIC.jur_fic_fl_processo = 1 
		AND PRC.jur_prc_fl_situacao=@Pfl_situacao
		AND PRC.jur_prc_fl_encerrado=@Pfl_encerramento
ELSE IF  @Pfl_situacao<>6  AND @Pfl_encerramento='2'   -- Especifico E  encerramento
	SELECT     
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao, 
		CASE PRC.jur_prc_fl_situacao 
			WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Sentença' 
			WHEN '2' THEN 'Cancelado'
			WHEN '3' THEN 'Substabelecido para Terceiro'
			WHEN '4' THEN 'Acordo em Audiência' 
			WHEN '5' THEN 'Arquivamento em Audiência'  END AS SITUACAO  ,
		CASE PRC.jur_prc_fl_encerrado 
			WHEN '0' THEN 'NÃO' 
			WHEN '1' THEN 'SIM' END AS ENCERRADO,
                     	 PRC.jur_prc_dt_final
	FROM    tb_jur_ficha_professor FIP INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
	             tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE 	
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim
		AND FIP.jur_fip_cd_professor <> N'00000' 
		AND FIC.jur_fic_fl_processo = 0 
		AND PRC.jur_prc_fl_situacao=@Pfl_situacao
	UNION

	SELECT     
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao, 
		CASE PRC.jur_prc_fl_situacao 
			WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Sentença' 
			WHEN '2' THEN 'Cancelado'
			WHEN '3' THEN 'Substabelecido para Terceiro'
			WHEN '4' THEN 'Acordo em Audiência' 
			WHEN '5' THEN 'Arquivamento em Audiência'  END AS SITUACAO  ,
		CASE PRC.jur_prc_fl_encerrado 
			WHEN '0' THEN 'NÃO' 
			WHEN '1' THEN 'SIM' END AS ENCERRADO,
                      	PRC.jur_prc_dt_final
	FROM  tb_jur_ficha_professor FIP INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE 	
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim
		AND FIP.jur_fip_cd_professor = '00000' 
		AND FIC.jur_fic_fl_processo = 1 
		AND PRC.jur_prc_fl_situacao=@Pfl_situacao

ELSE IF @Pfl_situacao=6 AND @Pfl_encerramento<>'2'   -- Especifico E Selecionando encerramento
	SELECT     
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao, 
		CASE PRC.jur_prc_fl_situacao 
			WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Sentença' 
			WHEN '2' THEN 'Cancelado'
			WHEN '3' THEN 'Substabelecido para Terceiro'
			WHEN '4' THEN 'Acordo em Audiência' 
			WHEN '5' THEN 'Arquivamento em Audiência'  END AS SITUACAO  ,
		CASE PRC.jur_prc_fl_encerrado 
			WHEN '0' THEN 'NÃO' 
			WHEN '1' THEN 'SIM' END AS ENCERRADO,
                     	 PRC.jur_prc_dt_final
	FROM    tb_jur_ficha_professor FIP INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
	             tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE 	
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim
		AND FIP.jur_fip_cd_professor <> N'00000' 
		AND FIC.jur_fic_fl_processo = 0 
		AND PRC.jur_prc_fl_encerrado=@Pfl_encerramento

	UNION

	SELECT     
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao, 
		CASE PRC.jur_prc_fl_situacao 
			WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Sentença' 
			WHEN '2' THEN 'Cancelado'
			WHEN '3' THEN 'Substabelecido para Terceiro'
			WHEN '4' THEN 'Acordo em Audiência' 
			WHEN '5' THEN 'Arquivamento em Audiência'  END AS SITUACAO  ,
		CASE PRC.jur_prc_fl_encerrado 
			WHEN '0' THEN 'NÃO' 
			WHEN '1' THEN 'SIM' END AS ENCERRADO,
                      	PRC.jur_prc_dt_final
	FROM  tb_jur_ficha_professor FIP INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE 	
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim
		AND FIP.jur_fip_cd_professor = '00000' 
		AND FIC.jur_fic_fl_processo = 1 
		AND PRC.jur_prc_fl_encerrado=@Pfl_encerramento
ELSE IF @Pfl_situacao=6 AND @Pfl_encerramento='2'   -- Especifico E Selecionando encerramento
	SELECT     
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao, 
		CASE PRC.jur_prc_fl_situacao 
			WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Sentença' 
			WHEN '2' THEN 'Cancelado'
			WHEN '3' THEN 'Substabelecido para Terceiro'
			WHEN '4' THEN 'Acordo em Audiência' 
			WHEN '5' THEN 'Arquivamento em Audiência'  END AS SITUACAO  ,
		CASE PRC.jur_prc_fl_encerrado 
			WHEN '0' THEN 'NÃO' 
			WHEN '1' THEN 'SIM' END AS ENCERRADO,
                     	 PRC.jur_prc_dt_final
	FROM    tb_jur_ficha_professor FIP INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
	             tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE 	
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim
		AND FIP.jur_fip_cd_professor <> N'00000' 
		AND FIC.jur_fic_fl_processo = 0 
	UNION

	SELECT     
		PRC.jur_prc_nr_pasta, 
		CP.Nome, 
		CE.Razao_Social, 
		PRC.jur_prc_dt_distribuicao, 
		CASE PRC.jur_prc_fl_situacao 
			WHEN '0' THEN 'Em Aberto' 
			WHEN '1' THEN 'Sentença' 
			WHEN '2' THEN 'Cancelado'
			WHEN '3' THEN 'Substabelecido para Terceiro'
			WHEN '4' THEN 'Acordo em Audiência' 
			WHEN '5' THEN 'Arquivamento em Audiência'  END AS SITUACAO  ,
		CASE PRC.jur_prc_fl_encerrado 
			WHEN '0' THEN 'NÃO' 
			WHEN '1' THEN 'SIM' END AS ENCERRADO,
                      	PRC.jur_prc_dt_final
	FROM  tb_jur_ficha_professor FIP INNER JOIN
                      	tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE 	
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_inicio AND @Pdt_fim
		AND FIP.jur_fip_cd_professor = '00000' 
		AND FIC.jur_fic_fl_processo = 1
go

