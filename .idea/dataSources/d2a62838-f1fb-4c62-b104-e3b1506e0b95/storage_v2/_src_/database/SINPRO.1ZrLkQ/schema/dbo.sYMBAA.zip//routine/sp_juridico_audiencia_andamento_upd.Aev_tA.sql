/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_andamento_upd
Descriçao:	Atualiza o Andamento do Processo
Data da Criaçao: 08/10/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_andamento_upd
(
@Pcd_audiencia	INT,
@Pnr_pasta		NVARCHAR(8),
@Pdt_audiencia		DATETIME,
@Pfl_audiencia		TINYINT,
@Pfl_concluido		TINYINT,
@Pnm_cadastrado	NVARCHAR(30)
)

AS
UPDATE tb_jur_processo_agendamento SET
	jur_pca_fl_concluido	= @Pfl_concluido,
	jur_pca_nm_login	= @Pnm_cadastrado,
	jur_pca_dt_cadastro	= GETDATE()
WHERE 
	jur_pca_nr_pasta		= @Pnr_pasta
	AND jur_pca_cd_andamento	= @Pfl_audiencia
	AND jur_pca_dt_agendamento	= @Pdt_audiencia

UPDATE tb_jur_audiencia SET
	jur_aud_fl_realizada	= @Pfl_concluido
WHERE
	jur_aud_cd_audiencia	= @Pcd_audiencia
go

