/*******************************************************************
Objeto criado: 	 sp_eleicao_inscritos_ins
Descriçao:	Grava o Total de Inscritos no momento da impressão do relatório de votantes
Data da Criaçao: 18/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_inscritos_ins
(
@Pds_urna		INT = 0,
@Pds_eleicao		CHAR(4),
@Pds_login		NVARCHAR(30)
)
AS

DECLARE @Vachou_urna	TINYINT,
	@Vtotal_inscritos	SMALLINT

IF @Pds_urna <> 0
BEGIN
	SET @Vachou_urna = 0

	SELECT @Vachou_urna = 1 
		FROM tb_ele_votos
		WHERE ele_evt_ds_eleicao = @Pds_eleicao
		AND ele_evt_ds_urna = @Pds_urna

	IF @Vachou_urna = 0 
	BEGIN
		SELECT 
			@Vtotal_inscritos = COUNT(DISTINCT PGE.CPF)
			FROM Cadastro_Escolas CE INNER JOIN 
				Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
				Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
			WHERE  CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
				AND CP.Situacao IN (1,5,9,2,10,12,13) 
				AND PGE.CGC_Escola <> '00.000.000/0000-00'
			 	AND CE.Categoria IN (1,6) 
				AND CE.Situacao IN (0,1) 
				AND CE.Urna = @Pds_urna
				AND CP.Votou = 0
			GROUP BY CE.Urna
			HAVING COUNT(PGE.CPF) >= 1

		INSERT INTO tb_ele_votos (ele_evt_ds_eleicao, ele_evt_ds_urna, ele_evt_nr_eleitor, ele_evt_nr_inscrito, ele_evt_fl_status)
			VALUES (@Pds_eleicao, @Pds_urna, @Vtotal_inscritos, @Vtotal_inscritos, 0)

		INSERT INTO tb_ele_votos_detalhe (ele_evd_ds_eleicao, ele_evd_ds_urna, ele_evd_ds_chapa, ele_evd_dt_eleicao)
			VALUES (@Pds_eleicao, @Pds_urna, '01','2018/10/24')

		INSERT INTO tb_eleicao_votos_professor (ele_evp_ds_eleicao, ele_evp_nr_urna, ele_evp_cd_professor, ele_evp_cd_escola, ele_evp_ds_login, ele_evp_fl_votou, ele_evp_fl_duplicado)
			SELECT @Pds_eleicao, @Pds_urna, CP.Codigo_Professor, CE.CGC_Escola, @Pds_login,0,0
			FROM Cadastro_Escolas CE INNER JOIN 
				Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
				Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
			WHERE  CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
				AND CP.Situacao IN (1,5,9,2,10,12,13) 
				AND PGE.CGC_Escola <> '00.000.000/0000-00'
			 	AND CE.Categoria IN (1,6) 
				AND CE.Situacao IN (0,1) 
				AND CE.Urna = @Pds_urna
				AND CP.Votou = 0
			GROUP BY CP.Codigo_Professor, CE.CGC_Escola
			HAVING COUNT(PGE.CPF) >= 1
	END
END
ELSE
BEGIN
	DECLARE @Vnr_urna	INT

	DECLARE CurUrna CURSOR FAST_FORWARD FOR
		SELECT DISTINCT Urna
			FROM Cadastro_Escolas
			WHERE Urna NOT IN (0)
			ORDER BY Urna

	OPEN CurUrna
		FETCH NEXT FROM CurUrna INTO @Vnr_urna
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @Vachou_urna = 0

			SELECT @Vachou_urna = 1 
				FROM tb_ele_votos
				WHERE ele_evt_ds_eleicao = @Pds_eleicao
				AND ele_evt_ds_urna = @Vnr_urna
		
			IF @Vachou_urna = 0 
			BEGIN
				PRINT @Vnr_urna
				SELECT 
					@Vtotal_inscritos = COUNT(DISTINCT PGE.CPF)
					FROM Cadastro_Escolas CE INNER JOIN 
						Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
						Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
					WHERE  CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
						AND CP.Situacao IN (1,5,9,2,10,12,13) 
						AND PGE.CGC_Escola <> '00.000.000/0000-00'
					 	AND CE.Categoria IN (1,6) 
						AND CE.Situacao IN (0,1) 
						AND CE.Urna = @Vnr_urna
						AND CP.Votou = 0
					GROUP BY CE.Urna
					HAVING COUNT(PGE.CPF) >= 1
		
				INSERT INTO tb_ele_votos (ele_evt_ds_eleicao, ele_evt_ds_urna, ele_evt_nr_eleitor, ele_evt_nr_inscrito, ele_evt_fl_status)
					VALUES (@Pds_eleicao, @Vnr_urna, @Vtotal_inscritos, @Vtotal_inscritos, 0)
		
				INSERT INTO tb_ele_votos_detalhe (ele_evd_ds_eleicao, ele_evd_ds_urna, ele_evd_ds_chapa, ele_evd_dt_eleicao)
					VALUES (@Pds_eleicao, @Vnr_urna, '01','2018/10/24')

				INSERT INTO tb_eleicao_votos_professor (ele_evp_ds_eleicao, ele_evp_nr_urna, ele_evp_cd_professor, ele_evp_cd_escola, ele_evp_ds_login, ele_evp_fl_votou, ele_evp_fl_duplicado)
					SELECT @Pds_eleicao, @Vnr_urna, CP.Codigo_Professor, CE.CGC_Escola, @Pds_login,0,0
					FROM Cadastro_Escolas CE INNER JOIN 
						Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
						Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
					WHERE  CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
						AND CP.Situacao IN (1,5,9,2,10,12,13) 
						AND PGE.CGC_Escola <> '00.000.000/0000-00'
					 	AND CE.Categoria IN (1,6) 
						AND CE.Situacao IN (0,1) 
						AND CE.Urna = @Vnr_urna
						AND CP.Votou = 0
					GROUP BY CP.Codigo_Professor, CE.CGC_Escola
					HAVING COUNT(PGE.CPF) >= 1
			END

			FETCH NEXT FROM CurUrna INTO @Vnr_urna
		END
	CLOSE CurUrna
	DEALLOCATE CurUrna
END
go

