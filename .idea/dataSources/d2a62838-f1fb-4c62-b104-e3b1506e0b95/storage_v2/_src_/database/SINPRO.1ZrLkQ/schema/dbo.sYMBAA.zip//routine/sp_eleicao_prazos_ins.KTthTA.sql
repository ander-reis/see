


/*******************************************************************
Objeto criado: 	 sp_eleicao_prazos_ins
Descriçao:	Inclui Prazos de Eleição
Data da Criaçao: 17/03/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_prazos_ins
(
@pInt_cd_eleicao		INT,
@pNvc_ds_eleicao	NVARCHAR(4),
@pNvc_ds_descricao	NVARCHAR(300),
@pNvc_ds_periodo	NVARCHAR(300),
@pTin_fl_lembrete	TINYINT,
@pDt_avisar		DATETIME,
@pNvc_ds_lembrete	NVARCHAR(300),
@pNvc_ds_usuarios	NVARCHAR(300),
@pTin_fl_parar		TINYINT
)
AS

INSERT INTO tb_ele_prazos (
	ele_prz_cd_eleicao,
	ele_prz_ds_eleicao,
	ele_prz_ds_descricao,
	ele_prz_ds_periodo,	
	ele_prz_fl_lembrete,
	ele_prz_dt_avisar,
	ele_prz_ds_lembrete, 
	ele_prz_ds_usuarios,
	ele_prz_fl_parar)
VALUES(
	@pInt_cd_eleicao,
	@pNvc_ds_eleicao,
	@pNvc_ds_descricao,
	@pNvc_ds_periodo,
	@pTin_fl_lembrete,
	@pDt_avisar,
	@pNvc_ds_lembrete,
	@pNvc_ds_usuarios,
	@pTin_fl_parar)
go

