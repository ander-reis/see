
/*******************************************************************
Objeto criado: 	 sp_eleicao_escola_sel
Descriçao:	Seleciona Informações da Escola onde a Urna Passará
Data da Criaçao: 17/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_escola_sel
(
@Pfl_urna		INT
)
AS

IF @Pfl_urna <> 0 
	SELECT     CE.CGC_Escola, Nome_Fantasia, Endereco + ', ' + Numero AS Endereco, Bairro, CEP, Telefone1, Telefone2, FAX, CASE hor_1dia WHEN 0 THEN '' ELSE 'SIM' END AS [22/10], 
            		         CASE hor_2dia WHEN 0 THEN '' ELSE 'SIM' END AS [23/10], CASE hor_3dia WHEN 0 THEN '' ELSE 'SIM' END AS [24/10], hor_manha, hor_tarde, hor_noite, hor_intervalo, hor_reuniao, urna_local, contato_eleicao, CE1.Votos,
			CASE 
				WHEN hor_1dia = 1 AND hor_2dia = 1 AND hor_3dia = 1 THEN '[22/10], [23/10] e [24/10] - ' + obs1
				WHEN hor_1dia = 1 AND hor_2dia = 1 AND hor_3dia = 0 THEN '[22/10] e [23/10] - '          + obs1
				WHEN hor_1dia = 1 AND hor_2dia = 0 AND hor_3dia = 0 THEN '[22/10] - '  		     	 + obs1
				WHEN hor_1dia = 0 AND hor_2dia = 1 AND hor_3dia = 1 THEN '[23/10] e [22/10] - '          + obs1
				WHEN hor_1dia = 0 AND hor_2dia = 1 AND hor_3dia = 0 THEN '[22/10] - '	  	     	 + obs1
				WHEN hor_1dia = 0 AND hor_2dia = 0 AND hor_3dia = 1 THEN '[24/10] - ' 		     	 + obs1
				WHEN hor_1dia = 1 AND hor_2dia = 0 AND hor_3dia = 1 THEN '[22/10] e [24/10] - '     	 + obs1
			END AS obs1, obs2, Urna
	FROM         Cadastro_Escolas CE INNER JOIN (

	SELECT CE.CGC_Escola, COUNT(PGE.CPF) AS Votos
	FROM Cadastro_Escolas CE INNER JOIN 
		Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
		Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
	WHERE   CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
		AND CP.Situacao IN (1,5,9,2,10,12,13)
		AND PGE.CGC_Escola <> '00.000.000/0000-00'
		AND ((CE.Categoria IN (1,6) AND CE.Situacao IN (0,1) ) OR Categoria = 11)
		AND CE.Urna = @Pfl_urna
	GROUP BY CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Situacao, CE.Categoria, CE.CEP, CE.Urna
	HAVING	 COUNT(PGE.CPF) >= 1
	) AS CE1 ON CE.CGC_Escola = CE1.CGC_Escola
	ORDER BY [22/10] DESC, [23/10] DESC, [24/10] DESC, CE.CEP, CE.Nome_Fantasia
ELSE
	SELECT     CE.CGC_Escola, Nome_Fantasia, Endereco + ', ' + Numero AS Endereco, Bairro, CEP, Telefone1, Telefone2, FAX, CASE hor_1dia WHEN 0 THEN '' ELSE 'SIM' END AS [22/10], 
            		         CASE hor_2dia WHEN 0 THEN '' ELSE 'SIM' END AS [23/10], CASE hor_3dia WHEN 0 THEN '' ELSE 'SIM' END AS [24/10], hor_manha, hor_tarde, hor_noite, hor_intervalo, hor_reuniao, urna_local, contato_eleicao, CE1.Votos,
			CASE 
				WHEN hor_1dia = 1 AND hor_2dia = 1 AND hor_3dia = 1 THEN '[22/10], [23/10] e [24/10] - ' + obs1
				WHEN hor_1dia = 1 AND hor_2dia = 1 AND hor_3dia = 0 THEN '[22/10] e [23/10] - '          + obs1
				WHEN hor_1dia = 1 AND hor_2dia = 0 AND hor_3dia = 0 THEN '[22/10] - '  		     	 + obs1
				WHEN hor_1dia = 0 AND hor_2dia = 1 AND hor_3dia = 1 THEN '[23/10] e [24/10] - '          + obs1
				WHEN hor_1dia = 0 AND hor_2dia = 1 AND hor_3dia = 0 THEN '[23/10] - '	  	     	 + obs1
				WHEN hor_1dia = 0 AND hor_2dia = 0 AND hor_3dia = 1 THEN '[22/10] - ' 		     	 + obs1
				WHEN hor_1dia = 1 AND hor_2dia = 0 AND hor_3dia = 1 THEN '[22/10] e [24/10] - '     	 + obs1
			END AS obs1, obs2, Urna
	FROM         Cadastro_Escolas CE INNER JOIN (

	SELECT CE.CGC_Escola, COUNT(PGE.CPF) AS Votos
	FROM Cadastro_Escolas CE INNER JOIN 
		Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
		Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
	WHERE   CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
		AND CP.Situacao IN (1,5,9,2,10,12,13)
		AND PGE.CGC_Escola <> '00.000.000/0000-00'
		AND ((CE.Categoria IN (1,6) AND CE.Situacao IN (0,1) ) OR Categoria = 11)
		AND CE.Urna NOT IN (0,1)
	GROUP BY CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Situacao, CE.Categoria, CE.CEP, CE.Urna
	HAVING	 COUNT(PGE.CPF) >= 1
	) AS CE1 ON CE.CGC_Escola = CE1.CGC_Escola
	ORDER BY [22/10] DESC, [23/10] DESC, [24/10] DESC, CE.Urna, CE.CEP, CE.Nome_Fantasia
go

