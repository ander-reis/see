

/*******************************************************************
Objeto criado: 	 sp_previdencia_doctoprof_sel
Descriçao:	Traz todos os documentos que o professor deixou no Sinpro e deverá buscar.
Data da Criaçao: 25/09/2007
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_previdencia_doctoprof_sel
AS
	SELECT   
		SCPG.CPF, 
		SCPG.Codigo_Professor, 
		SCPG.Nome, 
		'(' + SCPG.DDD_Telefone_Residencial + ')' +  SCPG.Telefone_Residencial + ' / (' +  SCPG.DDD_Telefone_Celular + ')' +  SCPG.Telefone_Celular AS CONTATO, 
		PRA.prev_pra_cd_previdencia, 
		PRA.prev_pra_cd_tipoespecie, 	
		PAE.prev_pae_ds_especie,	
                     	PAP.prev_pap_ds_descricao
	FROM  tb_prev_atendimento PRA INNER JOIN Soc_Cadastro_Professor_Geral SCPG ON PRA.prev_pra_cd_codprofgeral = SCPG.CodProf_Geral INNER JOIN
                      	tb_prev_atendimento_documento_professor PAP ON PRA.prev_pra_cd_previdencia = PAP.prev_pap_cd_previdencia INNER JOIN
                     	 tb_prev_atendimento_tipoespecie PAE ON PRA.prev_pra_cd_tipoespecie = PAE.prev_pae_cd_tipoespecie
	WHERE     PAP.prev_pap_dt_devolucao = '01/01/1900' AND (PRA.prev_pra_fl_situacao <> 0 OR    PRA.prev_pra_fl_andamento = 1)
ORDER BY SCPG.Nome
go

