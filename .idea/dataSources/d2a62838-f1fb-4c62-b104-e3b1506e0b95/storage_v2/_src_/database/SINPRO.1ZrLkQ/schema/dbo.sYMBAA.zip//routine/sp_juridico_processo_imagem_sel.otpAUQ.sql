/*******************************************************************
Objeto criado: 	 sp_juridico_processo_imagem_sel
Descriçao:	Seleciona as Imagens do Processo
Data da Criaçao: 27/06/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_imagem_sel
(
@Pnr_pasta	NVARCHAR(8)
)
AS


SELECT
	IMG.jur_img_cd_imagem,
	IMG.jur_img_ds_arquivo,
	IMG.jur_img_ds_observacao,
	CONVERT(NVARCHAR(10), IMG.jur_img_dt_cadastro,103) AS jur_img_dt_cadastro,
	IMG.jur_img_nm_login,
	CONVERT(NVARCHAR(8),IMG.jur_img_dt_cadastro,108) AS jur_img_hr_cadastro
FROM
	tb_jur_processo_imagem IMG
WHERE
	IMG.jur_img_nr_pasta = @Pnr_pasta
ORDER BY
	CONVERT(CHAR(10),IMG.jur_img_dt_cadastro,111) DESC,
	CONVERT(NVARCHAR(8),IMG.jur_img_dt_cadastro,108) DESC
go

