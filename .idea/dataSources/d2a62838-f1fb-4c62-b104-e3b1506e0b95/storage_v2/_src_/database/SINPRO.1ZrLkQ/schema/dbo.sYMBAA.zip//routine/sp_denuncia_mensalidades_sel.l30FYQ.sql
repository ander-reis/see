/*******************************************************************
Objeto criado: 	 sp_denuncia_mensalidades_sel
Descriçao:	Pesquisa Sindicais e Mensalidades em Aberto
Data da Criaçao: 05/05/2010
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_denuncia_mensalidades_sel
(
@Pcd_escola		CHAR(18)
)
AS

-- Pesquisar Sindicais em Aberto
SELECT TOP 5 
	CONVERT(CHAR(10), BOU.dt_vencimento, 103) AS dt_vencimento 
FROM Boletos_Unificados BOU 
	INNER JOIN Cadastro_Arrecadacoes ARR ON BOU.cd_arrecadacao = ARR.cd_arrecadacao 
	INNER JOIN Historico_Status_Boletos HSB ON BOU.cd_arrecadacao = HSB.cd_arrecadacao AND BOU.cd_escola = HSB.cd_escola AND BOU.nr_via = HSB.nr_via 
WHERE HSB.cd_status <> 5 AND BOU.cd_escola = @Pcd_escola 
	AND ARR.cd_tipo_boleto = 1 AND CONVERT(CHAR(10),BOU.dt_vencimento,112) < CONVERT(CHAR(10),GETDATE(),112)
	AND YEAR(BOU.dt_vencimento) >= YEAR(GETDATE()) - 5
ORDER BY ARR.cd_arrecadacao DESC

-- Pesquisar Mensalidades em Aberto
SELECT TOP 12 
	CONVERT(CHAR(10), BOU.dt_vencimento, 103) AS dt_vencimento 
FROM Boletos_Unificados BOU 
	INNER JOIN Cadastro_Arrecadacoes ARR ON BOU.cd_arrecadacao = ARR.cd_arrecadacao 
	INNER JOIN Historico_Status_Boletos HSB ON BOU.cd_arrecadacao = HSB.cd_arrecadacao AND BOU.cd_escola = HSB.cd_escola AND BOU.nr_via = HSB.nr_via 
WHERE HSB.cd_status <> 5 AND BOU.cd_escola = @Pcd_escola 
	AND ARR.cd_tipo_boleto = 3  AND CONVERT(CHAR(10),BOU.dt_vencimento,112) < CONVERT(CHAR(10),GETDATE(),112)
	AND YEAR(BOU.dt_vencimento) >= YEAR(GETDATE()) - 5
ORDER BY ARR.cd_arrecadacao DESC
go

