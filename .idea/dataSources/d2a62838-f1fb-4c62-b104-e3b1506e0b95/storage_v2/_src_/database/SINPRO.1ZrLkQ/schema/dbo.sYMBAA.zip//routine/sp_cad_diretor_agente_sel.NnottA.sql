
/*******************************************************************
Objeto criado: 	 sp_cad_diretor_agente_sel
Descriçao:	Carrega Diretores e Agentes
Entrada:	@pCha_Tipo - A = Agentes, D = Diretores e NULL = Todos	
Data da Criaçao: 14/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_cad_diretor_agente_sel
(
@pCha_Tipo		CHAR(1)
)
AS

IF @pCha_Tipo IS NULL
	SET @pCha_Tipo = 'W'

SELECT 
	CodDiretor_Agente,
	Nome
FROM Cadastro_Diretor_Agente
WHERE Ativo = 'S' 
	AND Tipo = @pCha_Tipo OR 'W' = @pCha_Tipo
ORDER BY Nome


go

