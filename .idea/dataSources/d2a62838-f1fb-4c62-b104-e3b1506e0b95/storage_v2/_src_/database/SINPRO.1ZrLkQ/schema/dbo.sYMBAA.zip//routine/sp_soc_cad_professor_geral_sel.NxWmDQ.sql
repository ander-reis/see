



/*******************************************************************
Objeto criado: 	 sp_soc_cad_professor_geral_sel
Descriçao:	Seleciona Soc_Cadastro_Professor_Geral
Entrada:	@pNvc_professor  -> CPF do Professor
Saída:		
Data da Criaçao: 11/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professor_geral_sel
(
@pNvc_professor		NVARCHAR(14)
)
AS

	SELECT CodProf_Geral
	FROM Soc_Cadastro_Professor_Geral 
	WHERE CPF = @pNvc_professor


go

