

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_observacao_sel
Descriçao:	Seleciona as OBservações da Ficha de Consulta
Data da Criaçao: 02/03/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_observacao_sel
(
@Pnr_ficha		INT
)
AS

SELECT
	CONVERT(CHAR(10),jur_fio_dt_observacao,103) AS jur_fio_dt_observacao,
	CONVERT(CHAR(8),jur_fio_hr_observacao,108) AS jur_fio_hr_observacao,
	jur_fio_nm_login,
	jur_fio_ds_observacao
FROM
	tb_jur_ficha_observacao
WHERE
	jur_fio_nr_ficha = @Pnr_ficha
ORDER BY
	CONVERT(CHAR(10),jur_fio_dt_observacao,111) DESC,
	CONVERT(CHAR(8),jur_fio_hr_observacao,108) DESC

go

