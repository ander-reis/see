
/*******************************************************************
Objeto criado: 	 sp_eleicao_votos_ins
Descriçao:	Cadastra os Votos da Eleicao pela 1º vez
Data da Criaçao: 07/07/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_votos_ins
(
@Pds_eleicao		CHAR(4),

@Pds_urna		INT = 0,
@Pnr_eleitor		INT = 0,
@Pnr_total_votos	INT = 0,
@Pnr_total_separado	INT = 0,
@Pnr_total_branco	INT = 0,
@Pnr_total_nulo	INT = 0,
@Pfl_status		TINYINT = 1,

@Pds_chapa		CHAR(2) = '',
@Pdt_eleicao		DATETIME = '1900/01/01',
@Pnr_valido		INT = 0,
@Pval_branco 		INT = 0,
@Pval_nulo 		INT = 0,

@Pfl_tipo		TINYINT ,

@Pnr_total_inscrito		INT = 0,
@Pnr_total_normal		INT = 0,
@Pnr_total_desprezado		INT = 0

)

AS

IF @Pfl_tipo = 0	-- TOTAIS

	INSERT INTO    tb_ele_votos 
		(ele_evt_ds_eleicao,
		ele_evt_ds_urna,
		ele_evt_nr_eleitor,
             		ele_evt_nr_total_votos,
		ele_evt_nr_total_separado,
		ele_evt_nr_total_branco,
		ele_evt_nr_total_nulo,
		ele_evt_fl_status,
		ele_evt_nr_inscrito,
		ele_evt_nr_normal,
		ele_evt_nr_desprezado
		 ) 	
	VALUES
		(@Pds_eleicao,
		@Pds_urna,
		@Pnr_eleitor,
		@Pnr_total_votos,
		@Pnr_total_separado,
		@Pnr_total_branco,
		@Pnr_total_nulo,
		@Pfl_status,
		@Pnr_total_inscrito,
		@Pnr_total_normal,
		@Pnr_total_desprezado)


ELSE		-- BRANCOS E NULOS
	INSERT INTO	tb_ele_votos_detalhe
             		(ele_evd_ds_eleicao, 
		ele_evd_ds_urna,
		ele_evd_ds_chapa, 
		ele_evd_dt_eleicao, 
		ele_evd_nr_valido, 
		ele_evd_nr_val_branco,
		ele_evd_nr_val_nulo)
	VALUES     
		(@Pds_eleicao,
		@Pds_urna,
		@Pds_chapa,
		@Pdt_eleicao,
		@Pnr_valido,
		@Pval_branco,
		@Pval_nulo)
go

