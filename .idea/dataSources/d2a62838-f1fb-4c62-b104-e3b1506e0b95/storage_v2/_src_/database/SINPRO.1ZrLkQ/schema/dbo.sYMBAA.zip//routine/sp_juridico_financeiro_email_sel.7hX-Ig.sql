/*******************************************************************
Objeto criado: 	 sp_juridico_financeiro_email_sel
Descriçao:	Seleciona Todos os Pagamentos que foram enviados no Dia para informar o Professor por E-mail
Data da Criaçao: 03/07/2008
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_financeiro_email_sel
AS

SELECT
	PRC.jur_prc_nr_pasta,
	PRC.jur_prc_nr_processo,
	CVA.jur_cva_ds_vara ,
	PCF.jur_pcf_nr_parcela,
	CONVERT(CHAR(10),PCF.jur_pcf_dt_pagamento,103) AS jur_pcf_dt_pagamento,
	CE.Razao_Social,
	CASE CP.Sexo
		WHEN 0 THEN 'Prezado Professor'
		ELSE 'Prezada Professora'
	END AS Tratamento,
	CP.Nome,
	EMA.pro_ema_ds_email1
	
FROM
	Cadastro_Professores CP 
	INNER JOIN tb_jur_ficha_professor FIP 
	INNER JOIN tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha ON CP.Codigo_Professor = FIP.jur_fip_cd_professor 
	INNER JOIN Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola 
	INNER JOIN tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha 
	INNER JOIN tb_professor_email EMA ON CP.Codigo_Professor = EMA.pro_ema_cd_professor 
	INNER JOIN tb_jur_cadastro_vara CVA ON PRC.jur_prc_cd_vara = CVA.jur_cva_cd_vara 
	INNER JOIN tb_jur_processo_financeiro PCF ON FIP.jur_fip_cd_fic_pro = PCF.jur_pcf_cd_fic_pro
WHERE
	PCF.jur_pcf_fl_situacao = 2
	AND CONVERT(CHAR(8), PCF.jur_pcf_dt_pagamento, 112) = CONVERT(CHAR(8), GETDATE(), 112)
ORDER BY CP.Nome
go

