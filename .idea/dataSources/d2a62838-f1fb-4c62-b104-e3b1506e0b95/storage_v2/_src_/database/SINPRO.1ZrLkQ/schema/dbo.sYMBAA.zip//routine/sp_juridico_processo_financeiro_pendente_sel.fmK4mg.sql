/*******************************************************************
Objeto criado: 	 sp_juridico_processo_financeiro_pendente_sel
Descriçao:	Seleciona os Pagamentos Pendentes por Período
Data da Criaçao: 11/09/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE [dbo].[sp_juridico_processo_financeiro_pendente_sel]
(
@Pdt_de	NVARCHAR(10),
@Pdt_ate	NVARCHAR(10)
)
AS

SELECT
	PRC.jur_prc_nr_pasta,
	CP.Nome,
	CE.Razao_Social,
	PCF.jur_pcf_nr_parcela,
	CONVERT(CHAR(10),PCF.jur_pcf_dt_vencimento,103) AS jur_pcf_dt_vencimento,
	CONVERT(DECIMAL(10,2),PCF.jur_pcf_vl_parcela) AS jur_pcf_vl_parcela,
	CONVERT(DECIMAL(10,2),PCF.jur_pcf_vl_taxa) AS jur_pcf_vl_taxa,
	CONVERT(DECIMAL(10,2),PCF.jur_pcf_vl_honorario) AS jur_pcf_vl_honorario,
	CONVERT(DECIMAL(10,2),PCF.jur_pcf_vl_parcela - PCF.jur_pcf_vl_taxa - PCF.jur_pcf_vl_honorario) AS jur_pcf_vl_professor, 
	ADV.jur_adv_nm_advogado,
	ADV.jur_adv_ds_email
FROM
	tb_jur_ficha_consulta FIC
	INNER JOIN tb_jur_processo PRC ON FIC.jur_fic_nr_ficha = PRC.jur_prc_nr_ficha
	INNER JOIN tb_jur_processo_financeiro PCF ON PRC.jur_prc_nr_pasta = PCF.jur_pcf_nr_pasta
	INNER JOIN Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola
	INNER JOIN tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha  AND PCF.jur_pcf_cd_fic_pro = FIP.jur_fip_cd_fic_pro 
	INNER JOIN Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	INNER JOIN tb_jur_cadastro_vara CVA ON PRC.jur_prc_cd_vara = CVA.jur_cva_cd_vara
	INNER JOIN tb_jur_cadastro_advogado ADV ON CVA.jur_cva_cd_advogado = ADV.jur_adv_cd_advogado
WHERE
	CONVERT(CHAR(10), PCF.jur_pcf_dt_pagamento, 111) = '1900/01/01' 
	AND CONVERT(CHAR(10), PCF.jur_pcf_dt_vencimento,111) BETWEEN @Pdt_de AND @Pdt_ate
	AND PCF.jur_pcf_ds_titulo <> 'HONORARIOS'
	AND PRC.jur_prc_fl_execucao <> 4
	AND PCF.jur_pcf_fl_destino = 0
	AND PCF.jur_pcf_cd_banco <> '999'
	AND CONVERT(DECIMAL(10,2),PCF.jur_pcf_vl_parcela - PCF.jur_pcf_vl_taxa - PCF.jur_pcf_vl_honorario) <> 0
ORDER BY
	ADV.jur_adv_nm_advogado,
	CONVERT(CHAR(8),PCF.jur_pcf_dt_vencimento,112),
	CP.Nome
go

