/*******************************************************************
Objeto criado: 	 sp_pos_imagem_ins
Descriçao:	Cadastra as Imagens do Cadatro na Pos
Data da Criaçao: 16/06/2008
Autor:		Adriana
*******************************************************************/

CREATE PROCEDURE sp_pos_imagem_ins
(
@Pcd_imagem		REAL,
@Pcd_curso		REAL,
@Pds_cpf		NVARCHAR(18),
@Pds_arquivo		NVARCHAR(300),
@Pds_observacao	NVARCHAR(600),
@Pdt_cadastro		DATETIME,
@Pnm_login		NVARCHAR(30)
)

AS

IF @Pcd_imagem = 0  
	INSERT INTO tb_pos_agendamento_imagem
		(pos_pai_cd_curso,
		pos_pai_ds_cpf,
		pos_pai_ds_arquivo,
		pos_pai_ds_obs,
		pos_pai_dt_cadastro,
		pos_pai_ds_login)
	VALUES
		(@Pcd_curso,
		@Pds_cpf,	
		@Pds_arquivo,
		@Pds_observacao,
		@Pdt_cadastro,
		@Pnm_login)
ELSE
	UPDATE tb_pos_agendamento_imagem SET
		pos_pai_ds_arquivo	= @Pds_arquivo,
		pos_pai_ds_obs		= @Pds_observacao,
		pos_pai_dt_cadastro	= @Pdt_cadastro, 
		pos_pai_ds_login	= @Pnm_login
	WHERE
		 pos_pai_cd_imagem = @Pcd_imagem
go

