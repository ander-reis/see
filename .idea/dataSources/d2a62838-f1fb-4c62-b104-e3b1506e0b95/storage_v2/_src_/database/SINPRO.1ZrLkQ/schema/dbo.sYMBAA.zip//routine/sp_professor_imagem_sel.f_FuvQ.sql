/*******************************************************************
Objeto criado: 	 sp_professor_imagem_sel
Descriçao:	Seleciona as Imagens do Cadastro do Professor
Data da Criaçao: 23/10/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_professor_imagem_sel
(
@Pcd_professor		NVARCHAR(6)
)
AS


SELECT
	IMG.pro_img_cd_imagem,
	IMG.pro_img_ds_arquivo,
	IMG.pro_img_ds_observacao,
	CONVERT(NVARCHAR(10), IMG.pro_img_dt_cadastro,103) AS pro_img_dt_cadastro,
	IMG.pro_img_nm_login,
	CONVERT(NVARCHAR(8),IMG.pro_img_dt_cadastro,108) AS pro_img_hr_cadastro
FROM
	tb_professor_imagem IMG
WHERE
	IMG.pro_img_cd_professor = @Pcd_professor
ORDER BY
	CONVERT(CHAR(10),IMG.pro_img_dt_cadastro,111) DESC,
	CONVERT(NVARCHAR(8),IMG.pro_img_dt_cadastro,108) DESC
go

