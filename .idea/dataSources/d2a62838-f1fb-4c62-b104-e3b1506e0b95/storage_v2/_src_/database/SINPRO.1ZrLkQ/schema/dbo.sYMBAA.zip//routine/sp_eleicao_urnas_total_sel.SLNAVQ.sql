
/*******************************************************************
Objeto criado: 	 sp_eleicao_urnas_total_sel
Descriçao:	Seleciona Votos na Eleicao
Data da Criaçao: 25/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_urnas_total_sel
(
@Pds_eleicao		CHAR(4)

)
AS

SELECT     
	SUM(EVT.ele_evt_nr_total_votos) AS ele_evt_nr_total_votos, 
	SUM(EVT.ele_evt_nr_total_separado) AS ele_evt_nr_total_separado, 
	SUM(EVT.ele_evt_nr_total_branco) AS ele_evt_nr_total_branco, 
	SUM(EVT.ele_evt_nr_total_nulo) AS ele_evt_nr_total_nulo, 
	SUM(EVT.ele_evt_nr_inscrito) AS ele_evt_nr_inscrito, 
	EVT1.Urnas
FROM         tb_ele_votos EVT INNER JOIN
                          (SELECT     ele_evt_ds_eleicao, COUNT(1) AS Urnas
                            FROM          tb_ele_votos
                            WHERE      ele_evt_ds_eleicao = @Pds_eleicao AND ele_evt_fl_status = 1
                            GROUP BY ele_evt_ds_eleicao) EVT1 ON EVT.ele_evt_ds_eleicao = EVT1.ele_evt_ds_eleicao
WHERE     (EVT.ele_evt_ds_eleicao = @Pds_eleicao ) AND (EVT.ele_evt_fl_status = 1)
GROUP BY EVT1.Urnas

SELECT COUNT(DISTINCT Urna) AS Total_Urnas FROM Cadastro_Escolas
WHERE Urna NOT IN (0, 999)
go

