


/*******************************************************************
Objeto criado: 	 sp_previdencia_concessao_sel
Descriçao:	Seleciona as Concessoes de Aposentadoria de um determinado Periodo
Data da Criaçao: 06/09/2007
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_previdencia_concessao_sel
(
@Pdt_Inicio	DATETIME,
@Pdt_Fim	DATETIME,
@Pnr_Tipo	int
)
AS

IF  @Pnr_Tipo=0 --EM ABERTO
	SELECT     
		PRA.prev_pra_cd_previdencia, SCPG.Codigo_Professor, SCPG.CPF, SCPG.Nome, PRA.prev_pra_nr_beneficio, PAE.prev_pae_ds_especie,   PRA.prev_pra_dt_entrada, DATEDIFF(DD, PRA.prev_pra_dt_entrada, GETDATE()) AS DATA,PRA.prev_pra_dt_concessao
	FROM         
		tb_prev_atendimento PRA INNER JOIN   Soc_Cadastro_Professor_Geral SCPG ON PRA.prev_pra_cd_codprofgeral = SCPG.CodProf_Geral INNER JOIN   tb_prev_atendimento_tipoespecie PAE ON PRA.prev_pra_cd_tipoespecie = PAE.prev_pae_cd_tipoespecie
	WHERE     
		PRA.prev_pra_dt_entrada  BETWEEN @Pdt_Inicio AND @Pdt_Fim  AND PRA.prev_pra_fl_situacao='0'  AND prev_pra_dt_concessao='01/01/1900'
	ORDER BY 
		 SCPG.Nome
ELSE
	SELECT     
		PRA.prev_pra_cd_previdencia, SCPG.Codigo_Professor, SCPG.CPF, SCPG.Nome, PRA.prev_pra_nr_beneficio, PAE.prev_pae_ds_especie,   PRA.prev_pra_dt_entrada, DATEDIFF(DD, PRA.prev_pra_dt_entrada, PRA.prev_pra_dt_concessao) AS DATA,PRA.prev_pra_dt_concessao
	FROM         
		tb_prev_atendimento PRA INNER JOIN   Soc_Cadastro_Professor_Geral SCPG ON PRA.prev_pra_cd_codprofgeral = SCPG.CodProf_Geral INNER JOIN   tb_prev_atendimento_tipoespecie PAE ON PRA.prev_pra_cd_tipoespecie = PAE.prev_pae_cd_tipoespecie
	WHERE     
		PRA.prev_pra_dt_concessao  BETWEEN @Pdt_Inicio AND @Pdt_Fim  AND PRA.prev_pra_fl_situacao<>'1'  AND prev_pra_dt_concessao<>'01/01/1900'
	ORDER BY 
		SCPG.Nome
go

