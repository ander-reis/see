
/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_urna_aposentado_upd
Descriçao:	Atualiza o Pasar Urna do Cadastro do Professor
Data da Criaçao: 20/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_urna_aposentado_upd
(
@Pcd_professor		NVARCHAR(5),
@Pnr_urna		INT,
@Pds_eleicao		NVARCHAR(200)

)
AS

UPDATE Cadastro_Professores SET
	Urna = @Pnr_urna,
	Obs_Eleicao = @Pds_eleicao
WHERE Codigo_Professor = @Pcd_professor
go

