/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_leitura_email_upd
Descriçao:	 Atualiza o Flag de envio de Email quando ficha for para leitura
Data da Criaçao: 22/11/2012
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_leitura_email_upd
(
@Pnr_ficha 		INT
)
AS

UPDATE tb_jur_ficha_consulta SET
	jur_fic_fl_email_leitura = 1
WHERE jur_fic_nr_ficha = @Pnr_ficha
	AND jur_fic_fl_email_leitura = 0
go

