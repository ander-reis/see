
/*******************************************************************
Objeto criado: 	 sp_juridico_causa_sel
Descriçao:	Seleciona Cadastro de causa
Data da Criaçao: 15/09/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_causa_sel
AS

SELECT
	jur_cau_cd_causa,
	jur_cau_ds_causa,
	CASE jur_cau_fl_testemunha
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS jur_cau_fl_testemunha
FROM
	tb_jur_cadastro_causa
ORDER BY
	jur_cau_ds_causa
go

