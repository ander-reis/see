
/*******************************************************************
Objeto criado: 	 sp_juridico_advogado_upd
Descriçao:	Atualiza o Cadastro de Advogados
Data da Criaçao: 22/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_advogado_upd
(
@Pcd_advogado		NVARCHAR(5),
@Pnm_advogado		VARCHAR(70),
@Pfl_sexo			TINYINT,
@Pds_cpf			NVARCHAR(14),
@Pds_rg			NVARCHAR(12),
@Pfl_civil			TINYINT,
@Pnr_oab			VARCHAR(10),
@Pds_oab			CHAR(2),
@Pds_cep			NVARCHAR(9),
@Pds_endereco		NVARCHAR(63),
@Pds_numero			NVARCHAR(6),
@Pds_complemento		NVARCHAR(50),
@Pds_bairro			NVARCHAR(59),
@Pds_cidade			NVARCHAR(21),
@Pds_uf			NVARCHAR(2),
@Pnr_ddd_residencial		NVARCHAR(2),
@Pnr_fone_residencial		NVARCHAR(9),
@Pnr_ddd_celular		NVARCHAR(2),
@Pnr_celular			NVARCHAR(10),
@Pds_email			NVARCHAR(120),
@Pfl_ativo			TINYINT,
@Pfl_sinpro			TINYINT,
@Pfl_cargo			TINYINT,
@Pfl_procuracao		TINYINT,
@Pfl_atendimento		TINYINT,
@Pfl_doe			TINYINT = 1
)
AS

UPDATE tb_jur_cadastro_advogado SET
	jur_adv_nm_advogado		= @Pnm_advogado,
	jur_adv_fl_sexo			= @Pfl_sexo,
	jur_adv_ds_cpf			= @Pds_cpf,
	jur_adv_ds_rg			= @Pds_rg,
	jur_adv_fl_civil			= @Pfl_civil,
	jur_adv_nr_oab			= @Pnr_oab,
	jur_adv_ds_uf_oab		= @Pds_oab,
	jur_adv_ds_cep			= @Pds_cep,
	jur_adv_ds_endereco		= @Pds_endereco,
	jur_adv_ds_numero		= @Pds_numero,
	jur_adv_ds_complemento	= @Pds_complemento,
	jur_adv_ds_bairro		= @Pds_bairro,
	jur_adv_ds_cidade		= @Pds_cidade,
	jur_adv_ds_uf			= @Pds_uf,
	jur_adv_nr_ddd_fone_residencial	= @Pnr_ddd_residencial,
	jur_adv_nr_fone_residencial	= @Pnr_fone_residencial,
	jur_adv_nr_ddd_celular		= @Pnr_ddd_celular,
	jur_adv_nr_celular		= @Pnr_celular,
	jur_adv_ds_email		= @Pds_email,
	jur_adv_fl_ativo			= @Pfl_ativo,
	jur_adv_fl_sinpro		= @Pfl_sinpro,
	jur_adv_fl_cargo			= @Pfl_cargo,
	jur_adv_fl_procuracao		= @Pfl_procuracao,
	jur_adv_fl_atendimento		= @Pfl_atendimento,
	jur_adv_fl_doe			= @Pfl_doe
WHERE
	jur_adv_cd_advogado = @Pcd_advogado
go

