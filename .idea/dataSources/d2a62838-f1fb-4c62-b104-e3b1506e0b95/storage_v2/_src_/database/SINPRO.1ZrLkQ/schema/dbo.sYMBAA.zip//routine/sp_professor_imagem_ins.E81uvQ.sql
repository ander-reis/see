/*******************************************************************
Objeto criado: 	 sp_professor_imagem_ins
Descriçao:	Cadastra as Imagens do Cadatro do Professor
Data da Criaçao: 23/10/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_professor_imagem_ins
(
@Pcd_imagem		INT,
@Pcd_professor		NVARCHAR(6),
@Pds_arquivo		NVARCHAR(300),
@Pds_observacao	NVARCHAR(600),
@Pdt_cadastro		DATETIME,
@Pnm_login		NVARCHAR(30)
)

AS

IF @Pcd_imagem = 0  
	INSERT INTO tb_professor_imagem
		(pro_img_cd_professor,
		pro_img_ds_arquivo,
		pro_img_ds_observacao,
		pro_img_dt_cadastro,
		pro_img_nm_login)
	VALUES
		(@Pcd_professor,
		@Pds_arquivo,
		@Pds_observacao,
		@Pdt_cadastro,
		@Pnm_login)
ELSE
	UPDATE tb_professor_imagem SET
		pro_img_ds_arquivo	= @Pds_arquivo,
		pro_img_ds_observacao	= @Pds_observacao,
		pro_img_dt_cadastro	= @Pdt_cadastro, 
		pro_img_nm_login	= @Pnm_login
	WHERE
		pro_img_cd_imagem = @Pcd_imagem
go

