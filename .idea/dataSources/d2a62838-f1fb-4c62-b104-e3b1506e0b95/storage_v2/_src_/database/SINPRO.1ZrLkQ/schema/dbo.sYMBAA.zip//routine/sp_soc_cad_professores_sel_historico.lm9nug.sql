
/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_sel_historico
Descriçao:	Seleciona Historico do Professor
Entrada:	@pNvc_professor  -> Codigo do Professor
Saída:		
Data da Criaçao: 14/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_sel_historico
(
@pNvc_professor		NVARCHAR(5)
)
AS

SELECT     
	HEP.Codigo_Professor, 
	HEP.CGC_Escola, 
	SUBSTRING(CE.Razao_Social, 1,29) AS Razao_Social,
	SUBSTRING(COALESCE(CE.Nome_Fantasia, Razao_Social),1,29) AS Nome_Fantasia,
	COALESCE(CONVERT(CHAR(10), HEP.Data_Entrada,103),'01/01/1900') AS Data_Entrada,  
	COALESCE(CONVERT(CHAR(10), HEP.Data_Saida,103),'01/01/1900') AS Data_Saida
FROM         Cadastro_Escolas CE INNER JOIN
                      Historico_Escolas_Professores HEP ON CE.CGC_Escola = HEP.CGC_Escola
WHERE     (HEP.Codigo_Professor = @pNvc_professor)
ORDER BY CONVERT(CHAR(10), HEP.Data_Saida,111) DESC


go

