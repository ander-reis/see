

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_financeiro_siga_sel
Descriçao:	Verifica se a parcela já foi enviada pro banco no Microsiga
Data da Criaçao: 29/06/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_financeiro_siga_sel
(
@Pds_prefixo	NVARCHAR(3),
@Pds_numero	NVARCHAR(6),
@Pds_parcela	NVARCHAR(1)
)
AS

SELECT
	E2_NUMBOR
FROM
	DADOSADV.dbo.SE2010
WHERE
	E2_PREFIXO = @Pds_prefixo
	AND E2_NUM = @Pds_numero
	AND E2_PARCELA = @Pds_parcela
go

