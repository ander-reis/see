
/*******************************************************************
Objeto criado: 	 sp_juridico_advogado_observacao_ins
Descriçao:	Cadastra a observação do Advogado
Data da Criaçao: 09/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_advogado_observacao_ins
(
@Pcd_advogado	INT,
@Pdt_observacao	DATETIME,
@Pds_observacao	NTEXT,
@Pnm_login		NVARCHAR(30),
@Phr_observacao	DATETIME
)

AS

INSERT INTO    tb_jur_cadastro_advogado_obs
	(jur_oad_cd_advogado,
	jur_oad_dt_observacao,
	jur_oad_ds_observacao,
	jur_oad_nm_login,
	jur_oad_dt_hora)
VALUES
	(@Pcd_advogado,
	@Pdt_observacao,
	@Pds_observacao,
	@Pnm_login,
	@Phr_observacao)
go

