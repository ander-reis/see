

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_consulta_upd
Descriçao:	Atualiza a Ficha de Consulta
Data da Criaçao: 02/03/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_consulta_upd
(
@Pnr_ficha		INT,
@Pcd_advogado	INT,
@Pfl_honorario		TINYINT,
@Pfl_status		TINYINT,
@Pds_01		NVARCHAR(2),
@Pds_02		NVARCHAR(2),
@Pds_03		NVARCHAR(2),
@Pds_04		NVARCHAR(2),
@Pds_05		NVARCHAR(2),
@Pfl_categoria		SMALLINT,
@Pfl_testemunha	TINYINT,
@Pfl_ctps		TINYINT,
@Pfl_fgts		TINYINT,
@Pfl_desemprego	TINYINT,
@Pfl_processo		TINYINT,
@Pds_testemunha	NVARCHAR(200)= '',
@Pvl_causa		DECIMAL(10,2) = 0
)

AS

UPDATE    tb_jur_ficha_consulta SET
	jur_fic_cd_advogado	= @Pcd_advogado,
	jur_fic_fl_honorario	= @Pfl_honorario,
	jur_fic_fl_status		= @Pfl_status,
	jur_fic_ds_01		= @Pds_01,
	jur_fic_ds_02		= @Pds_02,
	jur_fic_ds_03		= @Pds_03,
	jur_fic_ds_04		= @Pds_04,
	jur_fic_ds_05		= @Pds_05,
	jur_fic_fl_categoria	= @Pfl_categoria,
	jur_fic_fl_testemunha	= @Pfl_testemunha,
	jur_fic_fl_ctps		= @Pfl_ctps,
	jur_fic_fl_fgts		= @Pfl_fgts,
	jur_fic_fl_desemprego	= @Pfl_desemprego,
	jur_fic_fl_processo	= @Pfl_processo,
	jur_fic_ds_testemunha	= @Pds_testemunha,
	jur_fic_vl_causa		= @Pvl_causa,
	jur_fic_fl_email_leitura	=  jur_fic_fl_email_leitura
WHERE jur_fic_nr_ficha	= @Pnr_ficha
go

