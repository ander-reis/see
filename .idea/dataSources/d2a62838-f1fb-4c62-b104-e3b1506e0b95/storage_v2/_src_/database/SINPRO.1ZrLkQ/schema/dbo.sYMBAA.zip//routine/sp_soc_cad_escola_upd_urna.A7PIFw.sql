
/*******************************************************************
Objeto criado: 	 sp_soc_cad_escola_upd_urna
Descriçao:	Transfere Escola de Urna Eleitoral
Data da Criaçao: 02/06/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_escola_upd_urna
(
@pInt_Urna		INT,
@pNvc_CNPJ		NVARCHAR(18)
)
AS

UPDATE Cadastro_Escolas SET
	Urna = @pInt_Urna
WHERE CGC_Escola = @pNvc_CNPJ
go

