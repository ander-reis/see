

/*******************************************************************
Objeto criado: 	 sp_juridico_andamento_sel
Descriçao:	Seleciona andamentos
Data da Criaçao: 25/06/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_andamento_sel
AS

SELECT
	jur_and_cd_andamento, 
	jur_and_ds_andamento
FROM
	tb_jur_cadastro_andamento
ORDER BY
	jur_and_ds_andamento

go

