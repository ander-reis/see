
/*******************************************************************
Objeto criado: 	 sp_eleicao_urna_escola_sel
Descriçao:	Seleciona as Escolas da Eleição
Data da Criaçao: 19/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_urna_escola_sel
(
@Pds_urna		INT = 0
)
AS

IF @Pds_urna <> 0
	SELECT 
		CE.CGC_Escola, 
		CE.Razao_Social, 
		CE.Nome_Fantasia, 
		COUNT(PGE.CPF) AS Votos, 
		CE.Endereco + ', ' + CE.Numero AS Endereco,
		CE.Bairro + ' - ' + CE.Cidade + ' - ' + CE.CEP AS Complemento,
		CE.Urna
	FROM Cadastro_Escolas CE INNER JOIN 
		Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
		Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
	WHERE  CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
		AND CP.Situacao IN (1,5,9,2,10,12,13) 
		AND PGE.CGC_Escola <> '00.000.000/0000-00'
	 	AND CE.Categoria IN (1,6) 
		AND CE.Situacao IN (0,1) 
		AND CE.Urna NOT IN (0,1)
		AND CE.Urna = @Pds_urna
	GROUP BY CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Situacao, CE.Categoria, CE.CEP, CE.Urna, CE.Endereco, CE.Numero, CE.Bairro, CE.Cidade
	HAVING COUNT(PGE.CPF) >= 1
	ORDER BY SUBSTRING(CE.CEP,1,5) , CE.CGC_Escola

ELSE
	SELECT 
		CE.CGC_Escola, 
		CE.Razao_Social, 
		CE.Nome_Fantasia, 
		COUNT(PGE.CPF) AS Votos, 
		CE.Endereco + ', ' + CE.Numero AS Endereco,
		CE.Bairro + ' - ' + CE.Cidade + ' - ' + CE.CEP AS Complemento,
		CE.Urna
	FROM Cadastro_Escolas CE INNER JOIN 
		Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
		Cadastro_Professores CP ON CP.Codigo_Professor = PGE.Codigo_Professor
	WHERE  CP.Data_Inicio <= DATEADD(month,-6,DATEADD(day,-1,'10/24/2018'))
		AND CP.Situacao IN (1,5,9,2,10,12,13) 
		AND PGE.CGC_Escola <> '00.000.000/0000-00'
	 	AND CE.Categoria IN (1,6) 
		AND CE.Situacao IN (0,1) 
		AND CE.Urna NOT IN (0,1)
	GROUP BY CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Situacao, CE.Categoria, CE.CEP, CE.Urna, CE.Endereco, CE.Numero, CE.Bairro, CE.Cidade
	HAVING COUNT(PGE.CPF) >= 1
	ORDER BY CE.Urna, SUBSTRING(CE.CEP,1,5) , CE.CGC_Escola
go

