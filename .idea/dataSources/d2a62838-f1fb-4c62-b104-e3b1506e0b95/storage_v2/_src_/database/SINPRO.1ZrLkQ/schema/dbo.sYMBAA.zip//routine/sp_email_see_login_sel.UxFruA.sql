/*******************************************************************
Objeto criado: 	 sp_email_see_login_sel
Descriçao:	Pesquisa o nome dos usuários pra fazer o login
Data da Criaçao: 24/06/2015
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_email_see_login_sel
(
@Pds_login		NVARCHAR(30)
)

AS

SELECT UPPER(Login) AS Login 
FROM MUsuario
WHERE UPPER(Login) LIKE UPPER(@Pds_login) + '%'
ORDER BY Login
go

