

/*******************************************************************
Objeto criado: 	 sp_eleicao_chapas_sel
Descriçao:	Seleciona Chapas da Eleicao
Data da Criaçao: 03/07/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_chapas_sel
(
@Pds_eleicao		CHAR(4)
)
AS


SELECT     
	DISTINCT ele_cda_ds_chapa AS ele_cda_ds_chapa
FROM tb_ele_cand_dados
WHERE ele_cda_ds_eleicao = @Pds_eleicao
ORDER BY ele_cda_ds_chapa ASC

go

