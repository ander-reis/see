
/*******************************************************************
Objeto criado: 	 sp_eleicao_votos_professor_ins
Descriçao:	Cadastra Escola em que Professor Votou 
Data da Criaçao: 30/10/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_votos_professor_ins
(
@Pds_eleicao		CHAR(4),
@Pnr_urna		INT = 0,
@Pcd_professor		NVARCHAR(5),
@Pcd_escola		NVARCHAR(18),
@Pds_login		NVARCHAR(30) = '',
@Pfl_duplicado		TINYINT
)

AS

DECLARE @Vcd_escola	NVARCHAR(18)
DECLARE @Vfl_votou		BIT

SET @Vcd_escola = ''
SET @Vfl_votou = 0

SELECT @Vcd_escola = ele_evp_cd_escola, @Vfl_votou = ele_evp_fl_votou
	FROM tb_eleicao_votos_professor
	WHERE ele_evp_ds_eleicao = @Pds_eleicao
		AND ele_evp_cd_professor = @Pcd_professor
		AND ele_evp_cd_escola = @Pcd_escola

IF @Vcd_escola <> '' 
	IF @Pfl_duplicado = 0 
		UPDATE tb_eleicao_votos_professor SET
			ele_evp_fl_votou = 1
		WHERE ele_evp_ds_eleicao = @Pds_eleicao
			AND ele_evp_cd_professor = @Pcd_professor
			AND ele_evp_cd_escola = @Pcd_escola
	ELSE
	BEGIN
		UPDATE tb_eleicao_votos_professor SET
			ele_evp_fl_votou = 1
		WHERE ele_evp_ds_eleicao = @Pds_eleicao
			AND ele_evp_cd_professor = @Pcd_professor
			AND ele_evp_cd_escola = @Pcd_escola

		UPDATE tb_eleicao_votos_professor SET
			ele_evp_fl_duplicado = ele_evp_fl_duplicado + 1
		WHERE ele_evp_ds_eleicao = @Pds_eleicao
			AND ele_evp_cd_professor = @Pcd_professor
	END
ELSE
BEGIN
	SELECT @Vfl_votou = ele_evp_fl_duplicado
		FROM tb_eleicao_votos_professor
		WHERE ele_evp_ds_eleicao = @Pds_eleicao
			AND ele_evp_cd_professor = @Pcd_professor

	IF @Vfl_votou = 0
		INSERT INTO    tb_eleicao_votos_professor
			(ele_evp_ds_eleicao,
			ele_evp_nr_urna,
			ele_evp_cd_professor,
			ele_evp_cd_escola,
			ele_evp_ds_login,
			ele_evp_fl_votou
			 ) 	
		VALUES
			(@Pds_eleicao,
			@Pnr_urna,
			@Pcd_professor,
			@Pcd_escola,
			@Pds_login,
			1
			)
	ELSE
	BEGIN
		SELECT @Vfl_votou = ele_evp_fl_duplicado
			FROM tb_eleicao_votos_professor
			WHERE ele_evp_ds_eleicao = @Pds_eleicao
				AND ele_evp_cd_professor = @Pcd_professor
			
		INSERT INTO    tb_eleicao_votos_professor
			(ele_evp_ds_eleicao,
			ele_evp_nr_urna,
			ele_evp_cd_professor,
			ele_evp_cd_escola,
			ele_evp_ds_login,
			ele_evp_fl_votou
			 ) 	
		VALUES
			(@Pds_eleicao,
			@Pnr_urna,
			@Pcd_professor,
			@Pcd_escola,
			@Pds_login,
			1
			)
		
		UPDATE tb_eleicao_votos_professor SET
			ele_evp_fl_duplicado = @Vfl_votou + 1
		WHERE ele_evp_ds_eleicao = @Pds_eleicao
			AND ele_evp_cd_professor = @Pcd_professor

	END
END
go

