/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_professor_documento_del
Descriçao:	 Inserir Causa do Processo na Ficha
Data da Criaçao: 05/03/2007
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_professor_documento_del
(
@Pcd_doc_pro		INT
)

AS

DELETE 
FROM
	tb_jur_ficha_professor_documento
WHERE
	jur_fpd_cd_doc_pro = @Pcd_doc_pro
go

