


/*******************************************************************
Objeto criado: 	sp_eleicao_func_dad_ins
Descriçao:	Inclui / Altera Dados da Eleição do Funcionário
Saída:		
Data da Criaçao: 09/06/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_func_dad_ins
(
@Pcd_funcionario			CHAR(5),
@Pcd_dados				INT,
@Pds_eleicao				CHAR(4),
@Pds_cargo				CHAR(10),
@Pfl_carro				TINYINT,
@Pds_placa				CHAR(9),
@Pnr_urna				TINYINT,
@Pfl_aprovado				CHAR(3),
@Pfl_tipo				CHAR(1)
)
AS

DECLARE @Vds_cargo			TINYINT
DECLARE @Vfl_aprovado		TINYINT
DECLARE @Vcd_dados			INT

IF @Pds_cargo = 'PRESIDENTE'
	SET	@Vds_cargo	= 0
ELSE IF @Pds_cargo = 'MESÁRIO'
	SET	@Vds_cargo	= 1
ELSE IF @Pds_cargo = 'SUPLENTE'
	SET	@Vds_cargo	= 2

IF @Pfl_aprovado = 'NÃO'
	SET	@Vfl_aprovado	= 0
ELSE IF @Pfl_aprovado = 'SIM'
	SET	@Vfl_aprovado	= 1


IF @Pfl_tipo = 'I'
BEGIN
	SELECT @Vcd_dados = ISNULL(MAX(ele_dad_cd_dados) + 1,1)
	FROM tb_ele_func_dados
	WHERE ele_dad_cd_funcionario = @Pcd_funcionario

	INSERT INTO tb_ele_func_dados (
		ele_dad_cd_funcionario,
		ele_dad_cd_dados,
		ele_dad_ds_eleicao,
		ele_dad_ds_cargo,
		ele_dad_fl_carro,
		ele_dad_ds_placa,
		ele_dad_nr_urna,
		ele_dad_fl_aprovado) 
	VALUES (
		@Pcd_funcionario,
		@Vcd_dados,
		@Pds_eleicao,
		@Vds_cargo,
		@Pfl_carro,
		@Pds_placa,
		@Pnr_urna,
		@Vfl_aprovado
		)
END
ELSE
BEGIN
	UPDATE tb_ele_func_dados SET
		ele_dad_ds_eleicao 	= @Pds_eleicao,
		ele_dad_ds_cargo 	= @Vds_cargo,
		ele_dad_fl_carro		= @Pfl_carro,
		ele_dad_ds_placa	= @Pds_placa,
		ele_dad_nr_urna	= @Pnr_urna,
		ele_dad_fl_aprovado	= @Vfl_aprovado
	WHERE ele_dad_cd_funcionario = @Pcd_funcionario AND ele_dad_ds_eleicao = @Pds_eleicao
END
go

