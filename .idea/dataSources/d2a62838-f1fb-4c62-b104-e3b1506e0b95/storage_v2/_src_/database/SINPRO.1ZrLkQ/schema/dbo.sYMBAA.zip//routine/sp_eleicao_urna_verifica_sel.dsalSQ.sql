
/*******************************************************************
Objeto criado: 	 sp_eleicao_urna_verifica_sel
Descriçao:	Seleciona Escola
Data da Criaçao: 20/06/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_urna_verifica_sel
(
@Pnr_urna		INT,
@Pfl_tipo		TINYINT
)
AS

IF @Pfl_tipo = 0  -- Aposentados verifica na Escola
	SELECT     	
		TOP 1 1 AS Urna
	FROM         Cadastro_Escolas 
	WHERE   	Urna = @Pnr_urna
			AND Urna <> 0
		
ELSE
	SELECT     	
		TOP 1 1  AS Urna
	FROM         Cadastro_Professores 
	WHERE    Urna = @Pnr_urna
			AND Urna <> 0
go

