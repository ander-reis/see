
/*******************************************************************
Objeto criado: 	 sp_soc_cad_escola_total_sel
Descriçao:	Seleciona Total de Escola
Data da Criaçao: 28/01/2016
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_escola_total_sel
(
@Pfl_tipo		TINYINT,
@Pds_cnpj		NVARCHAR(18) = ''
)
AS

--SINDICAL
SELECT     ARR.cd_arrecadacao, ARR.ds_arrecadacao, COUNT(PAG.cd_professor) AS TOTPROF, ISNULL(CONVERT(DECIMAL(10, 2), SUM(PAG.vl_salario) 
                      / COUNT(PAG.cd_professor)), 0) AS MEDSAL
FROM         Cadastro_Arrecadacoes ARR INNER JOIN
                      Boletos_Unificados BU ON ARR.cd_arrecadacao = BU.cd_arrecadacao LEFT OUTER JOIN
                      Pagantes_Boletos PAG ON BU.cd_arrecadacao = PAG.cd_arrecadacao AND BU.cd_escola = PAG.cd_escola
WHERE     (ARR.cd_tipo_boleto = 1) AND (ARR.cd_arrecadacao >= 96) AND (BU.cd_escola = N'00.000.210/0001-80')
GROUP BY ARR.cd_arrecadacao, ARR.ds_arrecadacao, BU.nr_professores
ORDER BY ARR.cd_arrecadacao DESC



--DEMISSAO
SELECT     YEAR(Data_Demissao) AS ANO, COUNT(1) AS EXPR1
FROM         HDados_Homologacao
WHERE     (CGC_Escola = N'60.990.751/0001-24') AND (Data_Homologacao <> CONVERT(DATETIME, '1900-01-01 00:00:00', 102))
GROUP BY YEAR(Data_Demissao)
HAVING      (YEAR(Data_Demissao) >= 2003)
ORDER BY YEAR(Data_Demissao) DESC
go

