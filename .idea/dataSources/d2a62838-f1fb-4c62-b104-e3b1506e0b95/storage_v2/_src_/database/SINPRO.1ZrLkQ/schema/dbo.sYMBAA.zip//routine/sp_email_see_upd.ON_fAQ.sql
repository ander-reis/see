/*******************************************************************
Objeto criado: 	 sp_email_see_upd
Descriçao:	 Cancela o Agendamento de Envio de E-mail pelo SEE
Data da Criaçao: 13/11/2015
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/
CREATE PROCEDURE sp_email_see_upd
(
@Pcd_observacao	SMALLINT
)

AS

DECLARE @Vfl_cancelou	AS TINYINT

SELECT @Vfl_cancelou = 1 FROM tb_email_see WHERE
	ema_see_cd_observacao = @Pcd_observacao
	AND ema_see_fl_status = 0

IF  @Vfl_cancelou = 1
	UPDATE tb_email_see SET
		ema_see_dt_fim = GETDATE(),
		ema_see_fl_status = 9
	WHERE 
		ema_see_cd_observacao = @Pcd_observacao
ELSE
	SET @Vfl_cancelou = 0	

SELECT @Vfl_cancelou AS fl_cancelou
go

