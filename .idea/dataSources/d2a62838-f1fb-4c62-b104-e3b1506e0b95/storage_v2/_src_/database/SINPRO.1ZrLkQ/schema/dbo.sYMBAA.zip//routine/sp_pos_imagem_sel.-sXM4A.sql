/*******************************************************************
Objeto criado: 	 sp_pos_imagem_sel
Descriçao:	Seleciona as Imagens do Cadastro da Pós
Data da Criaçao: 16/06/2008
Autor:		Adriana
*******************************************************************/

CREATE PROCEDURE sp_pos_imagem_sel
(
@Pcd_curso		REAL,
@Pds_cpf		NVARCHAR(18)
)
AS

SELECT DISTINCT
	pos_pai_cd_imagem, 
	pos_pai_cd_curso, 
	pos_pai_ds_cpf, 
	pos_pai_ds_arquivo, 
	pos_pai_ds_obs, 
	pos_pai_dt_cadastro, 
	pos_pai_ds_login
FROM
	tb_pos_agendamento_imagem
WHERE
	pos_pai_cd_curso = @Pcd_curso AND pos_pai_ds_cpf=@Pds_cpf
ORDER BY
	 pos_pai_dt_cadastro DESC
go

