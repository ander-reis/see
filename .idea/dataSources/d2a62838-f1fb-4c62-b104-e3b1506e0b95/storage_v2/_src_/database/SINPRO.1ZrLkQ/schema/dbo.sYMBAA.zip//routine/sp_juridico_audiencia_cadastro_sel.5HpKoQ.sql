

/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_cadastro_sel
Descriçao:	Seleciona advogado
Data da Criaçao: 10/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_cadastro_sel
AS

SELECT     
	jur_cau_fl_audiencia,
	jur_cau_ds_audiencia
FROM
	tb_jur_cadastro_audiencia
ORDER BY
	 jur_cau_ds_audiencia

go

