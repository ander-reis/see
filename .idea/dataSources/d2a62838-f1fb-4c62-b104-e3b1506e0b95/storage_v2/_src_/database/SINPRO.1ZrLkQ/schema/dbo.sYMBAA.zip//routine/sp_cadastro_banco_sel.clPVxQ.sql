

/*******************************************************************
Objeto criado: 	 sp_cadastro_banco_sel
Descriçao:	Seleciona os Bancos Cadastrados
Data da Criaçao: 12/02/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_cadastro_banco_sel
AS

SELECT
	CodBanco, Banco
FROM
	Cadastro_Banco
WHERE
	CodBanco <> ''
ORDER BY
	Banco

go

