

/*******************************************************************
Objeto criado: 	 sp_eleicao_cand_del
Descriçao:	Deleta o Cadastro do Candidato
Data da Criaçao: 05/07/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_cand_del
(
@Pcd_candidato		NVARCHAR(5),
@Pds_eleicao			CHAR(4)
    
)
AS

DELETE tb_ele_cand_dados 
WHERE ele_cda_cd_candidato = @Pcd_candidato AND ele_cda_ds_eleicao = @Pds_eleicao

go

