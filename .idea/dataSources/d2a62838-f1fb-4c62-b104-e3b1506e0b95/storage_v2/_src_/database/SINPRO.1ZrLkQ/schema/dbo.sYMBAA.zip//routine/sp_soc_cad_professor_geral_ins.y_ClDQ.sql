/*******************************************************************
Objeto criado: 	 sp_soc_cad_professor_geral_ins
Descriçao:	Inclui no Soc_Cadastro_Professor_Geral
Data da Criaçao: 13/01/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professor_geral_ins
(
@pNvc_professor		NVARCHAR(5),
@pNvc_nome			NVARCHAR(100),
@pTin_caixa_postal		TINYINT		= 0,
@pNvc_endereco		NVARCHAR(63)		= '',
@pNvc_numero			NVARCHAR(6)		= '',
@pNvc_complemento		NVARCHAR(50)		= '',
@pNvc_bairro			NVARCHAR(59)		= '',
@pNvc_cidade			NVARCHAR(21)		= '',
@pNvc_uf			NVARCHAR(2)		= 'SP',
@pNvc_cep			NVARCHAR(9)		= '',
@pNvc_ddd_residencial		NVARCHAR(2)		= '11',
@pNvc_fone_residencial	NVARCHAR(9)		= '',
@pNvc_ramal_residencial	NVARCHAR(5)		= '',
@pNvc_ddd_comercial		NVARCHAR(2)		= '11',
@pNvc_fone_comercial		NVARCHAR(9)		= '',	
@pNvc_ramal_comercial		NVARCHAR(5)		= '',
@pNvc_ddd_celular		NVARCHAR(2)		= '11',
@pNvc_celular			NVARCHAR(10)		= '',
@pNvc_CPF			NVARCHAR(14),
@pNvc_RG			NVARCHAR(12)		='',
@pNvc_naturalidade		NVARCHAR(40)		='BRASILEIRO',
@pDt_aniversario		DATETIME		= '01/01/1900',
@pDt_modificacao		DATETIME		= GETDATE,
@pTin_sexo			TINYINT		= 1,
@pNvc_email			NVARCHAR(120),
@pTin_estado_civil		TINYINT		= 5,
@Pds_Banco			NVARCHAR(3) = '000',
@Pds_Agencia			NVARCHAR(8) = '',
@Pds_Conta			NVARCHAR(18) = '',
@Pfl_Poupanca			TINYINT = 0,
@Pfl_Conjunta			TINYINT = 0
)
AS

DECLARE @vCodProfGeral	REAL

UPDATE MCodigos 
SET 	CodProf_Geral = CodProf_Geral + 1

SELECT @vCodProfGeral = CodProf_Geral FROM MCodigos

INSERT INTO Soc_Cadastro_Professor_Geral (
	CodProf_Geral,
	Codigo_Professor,
	Nome,
	Caixa_Postal,
	Endereco,
             Numero,
	Complemento,
	Bairro,
	Cidade,
	Estado,
	CEP,
	DDD_Telefone_Residencial,
	Telefone_Residencial,
	Telefone_Residencial_Ramal,
             	DDD_Telefone_Comercial,
	Telefone_Comercial,
	Telefone_Comercial_Ramal,
	DDD_Telefone_Celular,
	Telefone_Celular,
	CPF,
	RG,
	Naturalidade,	
	Data_Aniversario,
	Data_Modificacao,
	Sexo,
	Email,
	Estado_Civil,
	Banco,
	Agencia,
	Conta,
	Poupanca,
	Conjunta)
VALUES(
	@vCodProfGeral,
	@pNvc_professor,
	@pNvc_nome,	
	@pTin_caixa_postal,
	@pNvc_endereco,	
	@pNvc_numero	,	
	@pNvc_complemento,
	@pNvc_bairro,	
	@pNvc_cidade,			
	@pNvc_uf,		
	@pNvc_cep,
	@pNvc_ddd_residencial,
	@pNvc_fone_residencial,
	@pNvc_ramal_residencial,
	@pNvc_ddd_comercial,
	@pNvc_fone_comercial,
	@pNvc_ramal_comercial	,
	@pNvc_ddd_celular,
	@pNvc_celular,	
	@pNvc_CPF,		
	@pNvc_RG,		
	@pNvc_naturalidade,
	@pDt_aniversario,
	@pDt_modificacao,
	@pTin_sexo,		
	@pNvc_email,
	@pTin_estado_civil,
	@Pds_Banco,
	@Pds_Agencia,
	@Pds_Conta,
	@Pfl_Poupanca,
	@Pfl_Conjunta
	)
PRINT @vCodProfGeral
go

