

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_consulta_imp
Descriçao:	Seleciona a Ficha de Consulta para Impressão
Data da Criaçao: 22/03/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_consulta_imp
(
@Pnr_ficha		INT
)
AS

SELECT     
	FIC.jur_fic_nr_ficha, 
	CONVERT(CHAR(10),FIC.jur_fic_dt_cadastro,103) AS jur_fic_dt_cadastro,
	ADV.jur_adv_nm_advogado,
	ADV.jur_adv_fl_sexo,
	CASE ADV.jur_adv_fl_sexo
		WHEN 0 THEN 'seu advogado'
		ELSE 'sua advogada'
	END AS jur_adv_ds_tratamento,
	ADV.jur_adv_ds_uf_oab + ' ' + ADV.jur_adv_nr_oab AS jur_adv_nr_oab,
	FIP.jur_fip_cd_professor,
	CP.Nome,
	CP.Endereco + ', ' + CP.Numero + ' ' + CP.Complemento AS endereco_reclamante,
	CP.Bairro ,
	CP.Cidade,
	CP.Estado,
	CP.CEP,
	'(' + CP.DDD_Telefone_Residencial + ') ' + CP.Telefone_Residencial + ' / (' + CP.DDD_Telefone_Comercial + ')' + CP.Telefone_Comercial + ' / (' + CP.DDD_Telefone_Celular + ')' + CP.Telefone_Celular AS fone_reclamante,
	CP.Sexo,
	CONVERT(CHAR(10),CP.Data_Aniversario,103) as dt_nascimento,
	LEFT(CASE   WHEN ISNULL(pro_ema_ds_email1,'') <> '' THEN ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END 
		         + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END,
		         LEN(CASE   WHEN  ISNULL(pro_ema_ds_email1,'') <> '' THEN  ISNULL(pro_ema_ds_email1,'') + ';' ELSE ';' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email2,'') <> '' THEN  ISNULL(pro_ema_ds_email2,'') + ';' ELSE '' END
		         + CASE WHEN  ISNULL(pro_ema_ds_email3,'') <> '' THEN  ISNULL(pro_ema_ds_email3,'') + ';' ELSE '' END) -1) AS Email,
	CP.Nome_Mae,
	CASE CP.Sexo
		WHEN 0 THEN 'filho'
		ELSE 'filha'
	END AS filho,
	CP.RG + ' - ' + CP.Orgao_Expedidor AS nr_rg,
	CP.CPF,
	FIP.jur_fip_ds_ctps + ' / ' + FIP.jur_fip_ds_ctps_serie AS nr_cart,
	CP.PIS,
	CASE CP.Estado_Civil
		WHEN 0 THEN CASE CP.Sexo WHEN 0 THEN 'CASADO'     ELSE 'CASADA'     END
		WHEN 1 THEN CASE CP.Sexo WHEN 0 THEN 'DIVORCIADO' ELSE 'DIVORCIADA' END
		WHEN 2 THEN CASE CP.Sexo WHEN 0 THEN 'SEPARADO'   ELSE 'SEPARADA'   END
		WHEN 3 THEN CASE CP.Sexo WHEN 0 THEN 'SOLTEIRO'   ELSE 'SOLTEIRA'   END
		WHEN 4 THEN CASE CP.Sexo WHEN 0 THEN 'VIÚVO'      ELSE 'VÍUVA'      END
		ELSE 'OUTROS'
	END AS civil, 
	CASE SUBSTRING(CP.Naturalidade,1,3)
		WHEN 'BRA'THEN  CASE CP.Sexo WHEN 0 THEN 'BRASILEIRO'     ELSE 'BRASILEIRA'     END
		ELSE CP.Naturalidade
	END AS nacionalidade,
	CASE 	
		WHEN CONVERT(CHAR(10),FIP.jur_fip_dt_admissao,103)  <> '01/01/1900' THEN CONVERT(CHAR(10),FIP.jur_fip_dt_admissao,103)
		ELSE ''
	END AS dt_admissao, 

	CASE 	
		WHEN CONVERT(CHAR(10),FIP.jur_fip_dt_demissao,103)  <> '01/01/1900' THEN CONVERT(CHAR(10),FIP.jur_fip_dt_demissao,103) 
		ELSE ''
	END AS dt_demissao,

	CONVERT(DECIMAL(10,2),FIP.jur_fip_vl_salario) AS jur_fip_vl_salario,
	CASE  
		WHEN CP.Banco <> '000' THEN CP.Banco + ' - ' + CB.Banco
		ELSE ''
	END AS Banco,
	CP.Agencia,
	CP.Conta,
	CASE CP.Poupanca
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS Poupanca,
	CASE CP.Conjunta
		WHEN 0 THEN 'NÃO'
		ELSE 'SIM'
	END AS Conjunta,  
	FIC.jur_fic_cd_cnpj,
	CE.Razao_Social,
	CE.Endereco + ', ' + CE.Numero + ' ' + CE.Complemento AS endereco_reclamada,
	CE.Bairro + ' - ' + CE.Cidade + ' - ' + CE.Estado + ' - ' + CE.CEP AS complemento_reclamada,
	'(11) ' + CE.Telefone1+ ' - ' + CE.Telefone1_Ramal  + ' / (11)' + CE.Telefone2 + ' - ' + CE.Telefone2_Ramal AS fone_reclamada,
	CE.Categoria,
        	FIP.jur_fip_fl_pre_escola,
	FIP.jur_fip_fl_aulas_14, FIP.jur_fip_nr_aulas_14,
	FIP.jur_fip_fl_aulas_58, FIP.jur_fip_nr_aulas_58,
        	FIP.jur_fip_fl_aulas_ens_medio, FIP.jur_fip_nr_aulas_ens_medio,
	FIP.jur_fip_fl_aulas_ens_superior, FIP.jur_fip_nr_aulas_ens_superior,
        	FIP.jur_fip_fl_aulas_tecnico, FIP.jur_fip_nr_aulas_tecnico,
	FIP.jur_fip_fl_aulas_supletivo, FIP.jur_fip_nr_aulas_supletivo,
	FIP.jur_fip_fl_aulas_curso_livre, FIP.jur_fip_nr_aulas_curso_livre,
	FIC.jur_fic_fl_honorario
FROM
	tb_jur_ficha_professor FIP 
	INNER JOIN tb_jur_ficha_consulta FIC ON FIP.jur_fip_nr_ficha = FIC.jur_fic_nr_ficha 
	INNER JOIN Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	LEFT JOIN tb_professor_email EMA ON CP.Codigo_Professor = EMA.pro_ema_cd_professor
	INNER JOIN Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola
	INNER JOIN tb_jur_cadastro_advogado ADV ON FIC.jur_fic_cd_advogado = ADV.jur_adv_cd_advogado
	INNER JOIN Cadastro_Banco CB ON CP.Banco = CB.CodBanco
WHERE 
	(FIC.jur_fic_nr_ficha = @Pnr_ficha  AND FIC.jur_fic_fl_processo = 0) OR (FIC.jur_fic_nr_ficha = @Pnr_ficha AND FIP.jur_fip_cd_professor = '00000')
ORDER BY
	CP.Nome
go

