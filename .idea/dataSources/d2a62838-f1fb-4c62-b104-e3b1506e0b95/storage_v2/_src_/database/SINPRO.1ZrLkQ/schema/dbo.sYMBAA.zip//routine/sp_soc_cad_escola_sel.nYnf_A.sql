
/*******************************************************************
Objeto criado: 	 sp_soc_cad_escola_sel
Descriçao:	Seleciona Escola
Entrada:	@pNvc_CNPJ  -> CNPJ da Escola
Saída:		
Data da Criaçao: 17/11/2005
Autor:		Adriana  - SinproSP
Alterado por:	Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_escola_sel
(
@pNvc_CNPJ		NVARCHAR(18)
)
AS

SELECT 
	CGC_Escola, 
	CGC_Mantenedora, 
	Razao_Social, 
	Nome_Fantasia, 
	Endereco,
	Numero,
	Complemento,
	Bairro,
	Cidade,
	Estado,
	CEP,
	Telefone1,
	Telefone1_Ramal,
	Telefone2,
	Telefone2_Ramal,
	FAX,
	Fax_Ramal,
	CONVERT(CHAR(10),Data_Alteracao,103) AS Data_Alteracao,
	Diretor_Base,
        	Pre,
	[1_4Serie],
	[5_8Serie],
	Ens_Medio,
	Ens_Superior,
	Tecnico,
	Curso_Livre,
        	Supletivo,
	Situacao,
	Matriz_Filial,
	Gera_Boleto,
	Gera_Lista,
	Gera_Sindical,
        	Sem_Cobranca,
	Tipo,
	LOWER(Email) AS Email,
	LOWER(Email2) AS Email2,
	Contato,
	Contato_Nome,
	Contato_DDD,
	Contato_Telefone,
        	Contato_Ramal,
	LOWER(Contato_Email) AS Contato_Email,
	Correspondencia,
	Categoria,
	LOWER(Site) AS Site,
	CNAE,
	hor_1dia,
	hor_2dia,
	hor_3dia,
	hor_manha,
	hor_tarde,
	hor_noite,
	hor_intervalo,
	hor_reuniao,
	obs1,
	obs2,
	urna_local,
	contato_eleicao,
	info_eleicao,
	agente_responsavel,
	Urna,
	fl_judicial,
	Observacao,
	fl_estacionamento
FROM Cadastro_Escolas
WHERE CGC_Escola=@pNvc_CNPJ
go

