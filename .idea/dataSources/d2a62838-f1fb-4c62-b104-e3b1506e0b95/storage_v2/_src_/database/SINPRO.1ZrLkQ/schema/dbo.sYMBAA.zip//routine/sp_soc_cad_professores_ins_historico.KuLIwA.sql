
/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_ins_historico
Descriçao:	Inclui Historico do Professor
Entrada:	@pNvc_professor  -> CPF do Professor
Saída:		
Data da Criaçao: 14/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_ins_historico
(
@pNvc_CNPJ				NVARCHAR(18),
@pNvc_professor			NVARCHAR(5),
@pDt_entrada				DATETIME,
@pDt_saida				DATETIME
)
AS


INSERT INTO Historico_Escolas_Professores (
	CGC_Escola,
	Codigo_Professor,
	Data_Entrada,
	Data_Saida) 
VALUES (
	@pNvc_CNPJ,
	@pNvc_professor,
	CONVERT(DATETIME,@pDt_entrada,102),
	CONVERT(DATETIME,@pDt_saida,102)
	)
go

