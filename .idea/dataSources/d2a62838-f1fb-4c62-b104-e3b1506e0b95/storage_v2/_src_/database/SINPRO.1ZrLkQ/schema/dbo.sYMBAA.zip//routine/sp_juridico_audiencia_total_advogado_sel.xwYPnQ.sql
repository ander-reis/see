

/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_total_advogado_sel
Descriçao:	Seleciona Total de Audiência por Advogado
Data da Criaçao: 10/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_total_advogado_sel
(
@Pdt_audiencia		DATETIME
)
AS

SELECT
	ADV.jur_adv_nm_advogado, 
	COUNT(1) AS Audiencia
FROM         
	tb_jur_audiencia AUD INNER JOIN
	tb_jur_cadastro_advogado ADV ON AUD.jur_aud_cd_advogado = ADV.jur_adv_cd_advogado
WHERE    
	AUD.jur_aud_fl_situacao IN (0, 1) 
	AND MONTH(AUD.jur_aud_dt_audiencia) = MONTH(@Pdt_audiencia) AND YEAR(AUD.jur_aud_dt_audiencia) = YEAR(@Pdt_audiencia)
GROUP BY ADV.jur_adv_nm_advogado
go

