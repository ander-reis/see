/*******************************************************************
Objeto criado: 	 sp_sms_ins
Descriçao:	Cadastra o SMS enviado para o Professor
Data da Criaçao: 30/09/2013
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_sms_ins
(
@Pcd_matricula		NVARCHAR(5),
@Pnm_professor	NVARCHAR(150),
@Pnr_celular		NVARCHAR(50),
@Pds_mensagem	NVARCHAR(400),
@Pds_origem		NVARCHAR(40)
)

AS

INSERT INTO    tb_professor_sms (
	cd_matricula,
	nm_professor,
	nr_celular,
	ds_mensagem,
	ds_origem)
VALUES
	(@Pcd_matricula,
	@Pnm_professor,
	@Pnr_celular,
	@Pds_mensagem,
	@Pds_origem)
go

