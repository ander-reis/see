/*******************************************************************
Objeto criado: 	 sp_email_sas_ins
Descriçao:	Cadastra o Agendamento de Envio de E-mail pelo SAS
Data da Criaçao: 29/10/2015
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_email_sas_ins
(
@Pds_email		NTEXT,
@Pds_de		NVARCHAR(50),
@Pds_exibir		NVARCHAR(50),
@Pds_assunto		NVARCHAR(100),
@Pds_para		NVARCHAR(500),
@Pds_copia		NVARCHAR(500),
@Pds_cco		NTEXT,
@Pds_login		NVARCHAR(30)
)

AS
INSERT INTO tb_email_sas
	(ema_sas_ds_email, ema_sas_ds_de, ema_sas_ds_exibir, ema_sas_ds_assunto, ema_sas_ds_para, ema_sas_ds_copia, ema_sas_ds_cco, ema_sas_ds_login)
VALUES (@Pds_email, @Pds_de, @Pds_exibir, @Pds_assunto, @Pds_para, @Pds_copia, @Pds_cco, @Pds_login)
go

