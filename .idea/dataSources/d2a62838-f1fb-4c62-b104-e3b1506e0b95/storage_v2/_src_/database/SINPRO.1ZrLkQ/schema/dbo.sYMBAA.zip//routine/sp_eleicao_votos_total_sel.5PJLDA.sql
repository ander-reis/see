


/*******************************************************************
Objeto criado: 	 sp_eleicao_votos_total_sel
Descriçao:	Seleciona Votos na Eleicao
Data da Criaçao: 12/07/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_votos_total_sel
(
@Pds_eleicao		CHAR(4)

)
AS

DECLARE @Vnr_total AS INTEGER

SELECT     @Vnr_total = SUM(ele_evd_nr_valido + ele_evd_nr_separado + ele_evd_nr_val_branco + ele_evd_nr_val_nulo)
FROM         tb_ele_votos_detalhe
WHERE     (ele_evd_ds_eleicao = '2018')

SELECT     
	EDT.ele_edt_nr_eleitor,
	@Vnr_total AS ele_edt_nr_votos
	--EDT.ele_edt_nr_votos
FROM         tb_ele_datas EDT 
WHERE EDT.ele_edt_ds_eleicao = @Pds_eleicao
go

