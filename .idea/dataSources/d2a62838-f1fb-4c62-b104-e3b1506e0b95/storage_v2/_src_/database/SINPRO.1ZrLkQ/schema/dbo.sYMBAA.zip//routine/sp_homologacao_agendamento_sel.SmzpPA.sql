/*******************************************************************
Objeto criado: 	 sp_homologacao_agendamento_sel
Descriçao:	Seleciona as Homologações Agendadas para o Dia
Data da Criaçao: 07/12/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_homologacao_agendamento_sel
(
@Pdt_agendamento		CHAR(10) = '1900/01/01',
@Pdt_de			DATETIME = '1900/01/01',
@Pdt_ate			DATETIME = '1900/01/01',
@Pfl_tipo			TINYINT = 0
)

AS

IF @Pfl_tipo = 0
BEGIN
/*
	SELECT     HAG.Horario, ISNULL(HAG.Nome_Fantasia,'') AS Nome_Fantasia, HAG.Qtde, 
		CASE HAG.Enviou
			WHEN 1 THEN 'SIM'
			ELSE 'NÃO'
		END AS Enviou , SCPG.Nome, ISNULL(HAG.CGC_Escola,'') AS CNPJ, HDH.CodHomologacao,HAG.CodAgendamento, CONVERT(CHAR(10), HAG.Data_Agendamento, 111)
	FROM         Soc_Cadastro_Professor_Geral SCPG LEFT OUTER JOIN
	                      HDados_Homologacao HDH ON SCPG.CodProf_Geral = HDH.CodProf_Geral RIGHT OUTER JOIN
	                      Hom_Agendamento HAG ON HDH.CGC_Escola = HAG.CGC_Escola
	WHERE     (CONVERT(CHAR(10), HAG.Data_Agendamento, 103) = @Pdt_agendamento) AND (CONVERT(CHAR(10), HDH.Data_Homologacao, 103) = '01/01/1900') AND 
	                      (DATEDIFF(m,HDH.Data_Cadastro, GETDATE()) <=3)
	
	UNION
	
	SELECT HAG.Horario, ISNULL(HAG.Nome_Fantasia,'') AS Nome_Fantasia, HAG.Qtde, 
		CASE HAG.Enviou
			WHEN 1 THEN 'SIM'
			ELSE 'NÃO'
		END AS Enviou , '', ISNULL(HAG.CGC_Escola,'') AS CNPJ, '', HAG.CodAgendamento, CONVERT(CHAR(10), HAG.Data_Agendamento, 111)
	FROM Hom_Agendamento HAG
	WHERE     (CONVERT(CHAR(10), HAG.Data_Agendamento, 103) = @Pdt_agendamento) AND HAG.CodAgendamento NOT IN (
		SELECT     HAG.CodAgendamento
		FROM         Soc_Cadastro_Professor_Geral SCPG LEFT OUTER JOIN
	        	              HDados_Homologacao HDH ON SCPG.CodProf_Geral = HDH.CodProf_Geral RIGHT OUTER JOIN
	                	      Hom_Agendamento HAG ON HDH.CGC_Escola = HAG.CGC_Escola
		WHERE     (CONVERT(CHAR(10), HAG.Data_Agendamento, 103) = @Pdt_agendamento) AND (CONVERT(CHAR(10), HDH.Data_Homologacao, 103) = '01/01/1900') AND 
	        	              (YEAR(HDH.Data_Cadastro) >= YEAR(GETDATE())) 
	)
	ORDER BY CONVERT(CHAR(10), HAG.Data_Agendamento, 111), HAG.Horario, CodAgendamento, SCPG.Nome
*/
	SELECT     HAG.Horario, ISNULL(HAG.Nome_Fantasia,'') AS Nome_Fantasia, HAG.Qtde, 
		CASE HAG.Enviou
			WHEN 1 THEN 'SIM'
			ELSE 'NÃO'
		END AS Enviou , SCPG.Nome, ISNULL(HAG.CGC_Escola,'') AS CNPJ, HDH.CodHomologacao,HAG.CodAgendamento, CONVERT(CHAR(10), HAG.Data_Agendamento, 111)
	FROM         Soc_Cadastro_Professor_Geral SCPG LEFT OUTER JOIN
	                      HDados_Homologacao HDH ON SCPG.CodProf_Geral = HDH.CodProf_Geral RIGHT OUTER JOIN
	                      Hom_Agendamento HAG ON HDH.CGC_Escola = HAG.CGC_Escola
	WHERE     (CONVERT(CHAR(10), HAG.Data_Agendamento, 111)  BETWEEN CONVERT(CHAR(10), @Pdt_de,111) AND CONVERT(CHAR(10), @Pdt_ate,111) ) AND (CONVERT(CHAR(10), HDH.Data_Homologacao, 103) = '01/01/1900') AND 
	                      (DATEDIFF(m,HDH.Data_Cadastro, GETDATE()) <=3)
	
	UNION

	SELECT HAG.Horario, ISNULL(HAG.Nome_Fantasia,'') AS Nome_Fantasia, HAG.Qtde, 
		CASE HAG.Enviou
			WHEN 1 THEN 'SIM'
			ELSE 'NÃO'
		END AS Enviou , '', ISNULL(HAG.CGC_Escola,'') AS CNPJ, '', HAG.CodAgendamento, CONVERT(CHAR(10), HAG.Data_Agendamento, 111)
	FROM Hom_Agendamento HAG
	WHERE     (CONVERT(CHAR(10), HAG.Data_Agendamento, 111)  BETWEEN CONVERT(CHAR(10), @Pdt_de,111) AND CONVERT(CHAR(10), @Pdt_ate,111)) AND HAG.CodAgendamento NOT IN (
		SELECT     HAG.CodAgendamento
		FROM         Soc_Cadastro_Professor_Geral SCPG LEFT OUTER JOIN
	        	              HDados_Homologacao HDH ON SCPG.CodProf_Geral = HDH.CodProf_Geral RIGHT OUTER JOIN
	                	      Hom_Agendamento HAG ON HDH.CGC_Escola = HAG.CGC_Escola
		WHERE     (CONVERT(CHAR(10), HAG.Data_Agendamento, 111)  BETWEEN CONVERT(CHAR(10), @Pdt_de,111) AND CONVERT(CHAR(10), @Pdt_ate,111) )

AND (CONVERT(CHAR(10), HDH.Data_Homologacao, 103) = '01/01/1900') AND 
	        	              (YEAR(HDH.Data_Cadastro) >= YEAR(GETDATE())) 
	)
	ORDER BY CONVERT(CHAR(10), HAG.Data_Agendamento, 111), HAG.Horario, CodAgendamento, Nome_Fantasia

END
ELSE IF @Pfl_tipo = 1
BEGIN


	SELECT HAG.Nome_Fantasia, SUM(HAG.Qtde) AS QTDE
	FROM Hom_Agendamento HAG
	WHERE     HAG.Nome_Fantasia <> ''
		AND  (CONVERT(CHAR(10), HAG.Data_Agendamento, 111)  BETWEEN CONVERT(CHAR(10), @Pdt_de,111) AND CONVERT(CHAR(10), @Pdt_ate,111) )
	GROUP BY HAG.Nome_Fantasia
	ORDER BY QTDE DESC, Nome_Fantasia
/*
	SELECT     ISNULL(HAG.Nome_Fantasia,'') AS Nome_Fantasia, SUM(HAG.Qtde) AS QTDE
	FROM         Soc_Cadastro_Professor_Geral SCPG LEFT OUTER JOIN
	                      HDados_Homologacao HDH ON SCPG.CodProf_Geral = HDH.CodProf_Geral RIGHT OUTER JOIN
	                      Hom_Agendamento HAG ON HDH.CGC_Escola = HAG.CGC_Escola
	WHERE     HAG.Nome_Fantasia <> '' AND  (CONVERT(CHAR(10), HAG.Data_Agendamento, 111)  BETWEEN CONVERT(CHAR(10), @Pdt_de,111) AND CONVERT(CHAR(10), @Pdt_ate,111) ) AND (CONVERT(CHAR(10), HDH.Data_Homologacao, 103) = '01/01/1900') AND 
	                      (DATEDIFF(m,HDH.Data_Cadastro, GETDATE()) <=3)
	GROUP BY HAG.Nome_Fantasia	
	UNION

	SELECT ISNULL(HAG.Nome_Fantasia,'') AS Nome_Fantasia, SUM(HAG.Qtde) AS QTDE
	FROM Hom_Agendamento HAG
	WHERE     HAG.Nome_Fantasia <> '' AND  (CONVERT(CHAR(10), HAG.Data_Agendamento, 111)  BETWEEN CONVERT(CHAR(10), @Pdt_de,111) AND CONVERT(CHAR(10), @Pdt_ate,111)) AND HAG.CodAgendamento NOT IN (
		SELECT     HAG.CodAgendamento
		FROM         Soc_Cadastro_Professor_Geral SCPG LEFT OUTER JOIN
	        	              HDados_Homologacao HDH ON SCPG.CodProf_Geral = HDH.CodProf_Geral RIGHT OUTER JOIN
	                	      Hom_Agendamento HAG ON HDH.CGC_Escola = HAG.CGC_Escola
		WHERE     (CONVERT(CHAR(10), HAG.Data_Agendamento, 111)  BETWEEN CONVERT(CHAR(10), @Pdt_de,111) AND CONVERT(CHAR(10), @Pdt_ate,111) )

AND (CONVERT(CHAR(10), HDH.Data_Homologacao, 103) = '01/01/1900') AND 
	        	              (YEAR(HDH.Data_Cadastro) >= YEAR(GETDATE())) 
	)
	GROUP BY Nome_Fantasia
	ORDER BY QTDE DESC, Nome_Fantasia
*/
END
go

