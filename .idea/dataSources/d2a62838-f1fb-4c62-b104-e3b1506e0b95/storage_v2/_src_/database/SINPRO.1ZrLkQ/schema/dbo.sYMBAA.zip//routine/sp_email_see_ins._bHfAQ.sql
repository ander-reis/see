/*******************************************************************
Objeto criado: 	 sp_email_see_ins
Descriçao:	Cadastra o Agendamento de Envio de E-mail pelo SEE
Data da Criaçao: 22/06/2015
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_email_see_ins
(
@Pds_email		NTEXT,
@Pds_de		NVARCHAR(50),
@Pds_exibir		NVARCHAR(50),
@Pds_assunto		NVARCHAR(100),
@Pds_copia		NVARCHAR(500),
@Pds_para		NVARCHAR(500),
@Pds_lista		NTEXT,
@Pds_tipo		NVARCHAR(10),
@Pds_login		NVARCHAR(30),
@Pdt_envio		DATETIME
)

AS

DECLARE @Vcd_see INT

INSERT INTO tb_email_see
	(ema_see_ds_email, ema_see_ds_de, ema_see_ds_exibir, ema_see_ds_assunto, ema_see_ds_copia, ema_see_ds_para, ema_see_ds_lista, ema_see_ds_tipo,ema_see_ds_login, ema_see_dt_envio, ema_see_fl_status, ema_see_dt_inicio, ema_see_dt_fim)
VALUES (ISNULL(@Pds_email,''), @Pds_de, @Pds_exibir, @Pds_assunto, @Pds_copia, @Pds_para, @Pds_lista, @Pds_tipo, @Pds_login, @Pdt_envio, 0,'1900/01/01','1900/01/01')

IF @Pds_para = 'E-mails na tabela'
BEGIN
SELECT TOP 1 @Vcd_see = ema_see_cd_observacao FROM  tb_email_see ORDER BY	ema_see_cd_observacao DESC

UPDATE  website.dbo.tb_boletim_envio SET cd_see = @Vcd_see WHERE cd_see = 0

END
go

