
/*******************************************************************
Objeto criado: 	sp_eleicao_func_obs_ins
Descriçao:	Inclui Dados do Funcionário
Saída:		
Data da Criaçao: 09/06/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_func_obs_ins
(
@Pcd_funcionario			CHAR(5),
@Pdt_observacao			DATETIME,
@Pds_observacao			NTEXT,
@Pnm_login				NVARCHAR(30),
@Pdt_hora				DATETIME
)
AS

INSERT INTO tb_ele_func_observacao (
	ele_obs_cd_funcionario,
	ele_obs_dt_observacao,
	ele_obs_ds_observacao,
	ele_obs_nm_login,
	ele_obs_dt_hora) 
VALUES (
	@Pcd_funcionario,
	@Pdt_observacao,
	@Pds_observacao,
	@Pnm_login,
	@Pdt_hora
	)
go

