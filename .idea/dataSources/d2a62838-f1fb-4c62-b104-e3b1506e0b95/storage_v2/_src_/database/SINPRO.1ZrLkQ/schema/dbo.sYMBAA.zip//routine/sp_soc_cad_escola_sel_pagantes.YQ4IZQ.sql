
/*******************************************************************
Objeto criado: 	 sp_soc_cad_escola_sel_pagantes
Descriçao:	Seleciona Professores Pagantes da Escola de Determinada Arrecadação
Data da Criaçao: 06/06/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_escola_sel_pagantes
(
@pInt_arrecadacao		INT,
@pNvc_CNPJ			NVARCHAR(18)
)
AS

SELECT     cd_professor, nm_professor
FROM         Pagantes_Boletos
WHERE     cd_arrecadacao = @pInt_arrecadacao AND cd_escola = @pNvc_CNPJ
ORDER BY nm_professor
go

