/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_observacao_ins
Descriçao:	Cadastra a observação da Audiencia
Data da Criaçao: 09/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_observacao_ins
(
@Pcd_audiencia	INT,
@Pnr_pasta		NVARCHAR(8) = '',
@Pdt_observacao	DATETIME,
@Pds_observacao	NTEXT,
@Pnm_login		NVARCHAR(30),
@Phr_observacao	DATETIME
)

AS

INSERT INTO    tb_jur_aud_obs
	(jur_oau_cd_audiencia,
	jur_oau_dt_observacao,
	jur_oau_ds_observacao,
	jur_oau_nm_login,
	jur_oau_hr_observacao,
	jur_oau_nr_pasta)
VALUES
	(@Pcd_audiencia,
	@Pdt_observacao,
	@Pds_observacao,
	@Pnm_login	,
	@Phr_observacao,
	@Pnr_pasta)
go

