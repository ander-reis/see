/*******************************************************************
Objeto criado: 	 sp_eleicao_prazos_lembrete_sel
*******************************************************************/

CREATE PROCEDURE sp_eleicao_prazos_lembrete_sel
AS

SELECT
	ele_prz_ds_usuarios,
	ele_prz_ds_descricao
FROM
	tb_ele_prazos
WHERE
	ele_prz_fl_parar = 0
	AND ele_prz_fl_lembrete = 1 
	AND CONVERT(CHAR(8),GETDATE(),112) >= CONVERT(CHAR(8),ele_prz_dt_avisar,112)
go

