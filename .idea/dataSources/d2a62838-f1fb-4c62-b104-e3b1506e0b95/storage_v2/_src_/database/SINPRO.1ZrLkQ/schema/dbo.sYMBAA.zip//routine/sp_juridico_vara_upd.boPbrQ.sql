


/*******************************************************************
Objeto criado: 	 sp_juridico_vara_upd
Descriçao:	Atualiza a Vara
Data da Criaçao: 22/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_vara_upd
(
@Pcd_vara		INT,
@Pcd_advogado	INT,
@Pds_vara		VARCHAR(20),
@Pds_endereco	NVARCHAR(63),
@Pds_numero		NVARCHAR(6),
@Pds_complemento	NVARCHAR(100),
@Pnr_fone		NVARCHAR(9),
@Pfl_dia_semana	TINYINT
)

AS

UPDATE    tb_jur_cadastro_vara  SET
	jur_cva_ds_vara =		@Pds_vara,
	jur_cva_cd_advogado=		@Pcd_advogado,
	jur_cva_ds_endereco =		@Pds_endereco,
	jur_cva_ds_numero =		@Pds_numero,
	jur_cva_ds_complemento =	@Pds_complemento,
	jur_cva_nr_fone =		@Pnr_fone,
	jur_cva_fl_dia_semana =		@Pfl_dia_semana
WHERE jur_cva_cd_vara =		@Pcd_vara
go

