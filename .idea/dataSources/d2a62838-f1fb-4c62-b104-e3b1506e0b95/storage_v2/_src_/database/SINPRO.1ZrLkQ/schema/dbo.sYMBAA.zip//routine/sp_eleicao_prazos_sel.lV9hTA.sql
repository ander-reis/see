

/*******************************************************************
Objeto criado: 	 sp_eleicao_prazos_sel
Descriçao:	Carrega Prazo de Eleições
Data da Criaçao: 17/03/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE  sp_eleicao_prazos_sel
(
@pTin_fl_tipo	TINYINT = 0
)
AS

IF @pTin_fl_tipo	= 0 
	SELECT     
		ele_prz_cd_eleicao,
		ele_prz_ds_eleicao,
		ele_prz_ds_descricao,
		ele_prz_ds_periodo,	
		CASE ele_prz_fl_lembrete
			WHEN 1 THEN 'SIM' 
			ELSE 'NÃO' 
		END AS ele_prz_fl_lembrete,
		CONVERT(CHAR(10),ele_prz_dt_avisar,103) AS ele_prz_dt_avisar,
		ele_prz_ds_lembrete, 
		ele_prz_ds_usuarios,
		CASE ele_prz_fl_parar
			WHEN 1 THEN 'SIM' 
			ELSE 'NÃO' 
		END AS ele_prz_fl_parar
	FROM         tb_ele_prazos
	ORDER BY ele_prz_ds_eleicao DESC, ele_prz_cd_eleicao DESC
ELSE
	SELECT     
		ele_prz_cd_eleicao,
		ele_prz_ds_eleicao,
		ele_prz_ds_lembrete, 
		ele_prz_ds_usuarios
		
	FROM         tb_ele_prazos
	WHERE CONVERT(CHAR(10),ele_prz_dt_avisar,112) <= CONVERT(CHAR(10),GETDATE(),112) 
		AND ele_prz_fl_lembrete = 1 
		AND ele_prz_fl_parar = 0
	ORDER BY ele_prz_ds_eleicao DESC, ele_prz_cd_eleicao DESC
go

