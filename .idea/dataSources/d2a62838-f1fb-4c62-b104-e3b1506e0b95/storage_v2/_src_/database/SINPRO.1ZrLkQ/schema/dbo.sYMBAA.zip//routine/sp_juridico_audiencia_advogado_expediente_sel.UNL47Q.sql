
/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_advogado_expediente_sel
Descriçao:	Informa se o advogado está disponível para audiência
Data da Criaçao: 01/12/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_advogado_expediente_sel
(
@Pcd_advogado		INT,
@Pdt_audiencia		DATETIME
)

AS
SELECT     TOP 1 
	ASE.Motivo
FROM 
	JAdv_AgendaSemExpediente ASE INNER JOIN
              tb_jur_cadastro_advogado ADV ON ASE.CPF_Advogado = ADV.jur_adv_ds_cpf
WHERE
	CONVERT(CHAR(8),ASE.Data_Agenda,112) = CONVERT(CHAR(8),@Pdt_audiencia,112)
	 AND ASE.Ausente = 1
	AND ADV.jur_adv_cd_advogado = @Pcd_advogado
go

