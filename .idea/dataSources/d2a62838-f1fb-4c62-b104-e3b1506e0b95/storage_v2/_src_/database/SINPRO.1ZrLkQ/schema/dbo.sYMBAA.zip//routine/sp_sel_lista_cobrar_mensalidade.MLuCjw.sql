/*******************************************************************
Objeto criado: 	sp_sel_lista_cobrar_mensalidade
Descriçao:	Script para pegar dados de Responsáveis das escolas que não pagaram determinada arrecadação (Mensalidade)
Entrada:	
Saída:		
Data da Criaçao: 23/05/2007
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/
CREATE PROCEDURE sp_sel_lista_cobrar_mensalidade
(
@pIntArrecadacao 	INT
)
AS


SELECT     CON.cd_cnpj AS CNPJ1, CON.nm_razao, '(' + CON.nr_ddd_1 + ') ' + CON.nr_telefone_1 AS Fone, CON.nm_contato, CON.ds_email_1 AS Email_1, CON.ds_email_2 AS Email_2, ESC.cd_escola  AS CNPJ2, 
                      ESC.nm_escola, ESC.nm_fantasia, CONVERT(DECIMAL(10,2),CONESC.vl_boleto) AS vl_boleto, 'S' AS Responsavel, CASE boleto WHEN 0 THEN 'N' ELSE 'S' END AS Gerou, CONVERT(CHAR(8),CONESC.dt_vencimento,112) AS dt_vencimento
FROM        sinprosp.dbo.tb_contabilidade CON INNER JOIN
                          (SELECT     CONESC.cd_cnpj, CONESC.cd_escola, COB.vl_boleto, COB.dt_vencimento, boleto
                            FROM         sinprosp.dbo.tb_contabilidade_escola AS CONESC INNER JOIN
                                                       (SELECT     DISTINCT COB.CGC_Escola, COB.vl_boleto, ARR.dt_vencimento, COB.boleto
                                                         FROM          Cob_Arrecadacao COB INNER JOIN
                                                                                Cadastro_Arrecadacoes ARR ON COB.cd_arrecadacao = ARR.cd_arrecadacao
                                                         WHERE      COB.cd_arrecadacao = @pIntArrecadacao) AS COB ON 
                                                   CONESC.cd_escola = COB.CGC_Escola) CONESC ON CON.cd_cnpj = CONESC.cd_cnpj INNER JOIN
                      sinprosp.dbo.tb_escolas ESC ON CONESC.cd_escola = ESC.cd_escola

UNION

SELECT     DISTINCT ESC.cd_escola CNPJ1 , ESC.nm_escola, '(' + ESC.nr_contabddd + ') ' + ESC.nr_contabfone AS Fone, ESC.nm_contabcontato, ESC.ds_contabemail AS Email_1, '', ESC.cd_escola AS CNPJ2, ESC.nm_escola, ESC.nm_fantasia, CONVERT(DECIMAL(10,2),CONESC.vl_boleto) AS vl_boleto, 'N' AS Responsavel, CASE boleto WHEN 0 THEN 'N' ELSE 'S' END AS Gerou, CONVERT(CHAR(8),CONESC.dt_vencimento,112) AS dt_vencimento
FROM         sinprosp.dbo.tb_escolas ESC INNER JOIN
                          (SELECT     CONESC.cd_cnpj, COB.CGC_Escola, COB.vl_boleto, dt_vencimento, boleto
                            FROM          sinprosp.dbo.tb_contabilidade_escola AS CONESC RIGHT JOIN
                                                       (SELECT     DISTINCT COB.CGC_Escola, COB.vl_boleto, ARR.dt_vencimento, COB.boleto
                                                         FROM          Cob_Arrecadacao COB INNER JOIN
                                                                                Cadastro_Arrecadacoes ARR ON COB.cd_arrecadacao = ARR.cd_arrecadacao
                                                         WHERE      COB.cd_arrecadacao = @pIntArrecadacao ) AS COB ON 
                                                   CONESC.cd_escola = COB.CGC_Escola
				WHERE CONESC.cd_cnpj IS NULL) CONESC ON ESC.cd_escola = CONESC.CGC_Escola
UNION

SELECT     CON.cd_cnpj AS CNPJ1, CON.nm_razao, '(' + CON.nr_ddd_1 + ') ' + CON.nr_telefone_1 AS Fone, CON.nm_contato, CON.ds_email_1 AS Email_1, CON.ds_email_2 AS Email_2, ESC.cd_escola  AS CNPJ2, 
                      ESC.nm_escola, ESC.nm_fantasia, CONVERT(DECIMAL(10,2),CONESC.vl_boleto) AS vl_boleto, 'S' AS Responsavel, CASE boleto WHEN 0 THEN 'N' ELSE 'S' END AS Gerou, CONVERT(CHAR(8),CONESC.dt_vencimento,112) AS dt_vencimento
FROM         sinprosp.dbo.tb_contabilidade CON INNER JOIN
                          (SELECT     CONESC.cd_cnpj, CONESC.cd_escola, COB.vl_boleto, dt_vencimento, boleto
                            FROM          sinprosp.dbo.tb_contabilidade_escola AS CONESC INNER JOIN
                                                       (SELECT     DISTINCT COB.CGC_Escola, COB.vl_boleto, ARR.dt_vencimento, COB.boleto
                                                         FROM          Cob_Arrecadacao COB INNER JOIN
                                                                                Cadastro_Arrecadacoes ARR ON COB.cd_arrecadacao = ARR.cd_arrecadacao
                                                         WHERE      COB.cd_arrecadacao = @pIntArrecadacao ) AS COB ON 
                                                   CONESC.cd_escola = COB.CGC_Escola) CONESC ON CON.cd_cnpj = CONESC.cd_cnpj INNER JOIN
                      sinprosp.dbo.tb_escolas ESC ON CONESC.cd_escola = ESC.cd_escola

UNION

SELECT     DISTINCT ESC.cd_escola CNPJ1 , ESC.nm_escola, '(' + ESC.nr_contabddd + ') ' + ESC.nr_contabfone AS Fone, ESC.nm_contabcontato, ESC.ds_contabemail AS Email_1, '', ESC.cd_escola AS CNPJ2, ESC.nm_escola, ESC.nm_fantasia, CONVERT(DECIMAL(10,2),CONESC.vl_boleto) AS vl_boleto, 'N' AS Responsavel, CASE boleto WHEN 0 THEN 'N' ELSE 'S' END AS Gerou, CONVERT(CHAR(8),CONESC.dt_vencimento,112) AS dt_vencimento
FROM         sinprosp.dbo.tb_escolas ESC INNER JOIN
                          (SELECT     CONESC.cd_cnpj, COB.CGC_Escola, COB.vl_boleto, dt_vencimento, boleto
                            FROM          sinprosp.dbo.tb_contabilidade_escola AS CONESC RIGHT JOIN
                                                       (SELECT     DISTINCT COB.CGC_Escola, COB.vl_boleto, ARR.dt_vencimento, COB.boleto
                                                         FROM          Cob_Arrecadacao COB INNER JOIN
                                                                                Cadastro_Arrecadacoes ARR ON COB.cd_arrecadacao = ARR.cd_arrecadacao
                                                         WHERE      COB.cd_arrecadacao = @pIntArrecadacao ) AS COB ON 
                                                   CONESC.cd_escola = COB.CGC_Escola
				WHERE CONESC.cd_cnpj IS NULL) CONESC ON ESC.cd_escola = CONESC.CGC_Escola

ORDER BY CNPJ1, Gerou DESC, CNPJ2
go

