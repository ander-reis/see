
/*******************************************************************
Objeto criado: 	 sp_juridico_advogado_sel
Descriçao:	Seleciona advogado
Data da Criaçao: 22/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_advogado_sel
(
@jur_adv_cd_advogado 	INT = 0

)
AS

IF @jur_adv_cd_advogado <> 0 
	SELECT
		jur_adv_cd_advogado,
		jur_adv_nm_advogado,
		jur_adv_fl_sexo,
		jur_adv_ds_cpf,
		jur_adv_ds_rg,	
	 	jur_adv_fl_civil,
		jur_adv_nr_oab,
		jur_adv_ds_uf_oab,
		jur_adv_ds_cep,
		jur_adv_ds_endereco,
		jur_adv_ds_numero,
		jur_adv_ds_complemento,
		jur_adv_ds_bairro,
		jur_adv_ds_cidade,
		jur_adv_ds_uf,
	             jur_adv_nr_ddd_fone_residencial,
		jur_adv_nr_fone_residencial,
		jur_adv_nr_ddd_celular,
		jur_adv_nr_celular,
		jur_adv_ds_email,
		CONVERT(CHAR(10),jur_adv_dt_cadastro,103) AS jur_adv_dt_cadastro,
		jur_adv_fl_ativo,
		jur_adv_fl_sinpro,
		jur_adv_fl_cargo,
		jur_adv_fl_procuracao,
		jur_adv_fl_atendimento,
		jur_adv_fl_doe
	FROM         tb_jur_cadastro_advogado ADV
	WHERE     jur_adv_cd_advogado = @jur_adv_cd_advogado
ELSE
	SELECT
		jur_adv_cd_advogado,
		jur_adv_nm_advogado,
		jur_adv_fl_sexo
	FROM         tb_jur_cadastro_advogado ADV
	WHERE     jur_adv_fl_ativo = 1
		AND jur_adv_fl_sinpro = 1
go

