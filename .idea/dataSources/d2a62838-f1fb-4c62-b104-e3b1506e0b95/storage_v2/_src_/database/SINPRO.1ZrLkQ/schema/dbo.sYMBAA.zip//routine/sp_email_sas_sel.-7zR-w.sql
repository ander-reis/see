/*******************************************************************
Objeto criado: 	sp_email_sas_sel
Descriçao:	Carrega os e-mails já cadastrados para envio
Data da Criaçao: 29/10/2015
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_email_sas_sel
AS

SELECT     ema_sas_cd_email, ema_sas_ds_email, ema_sas_ds_de, ema_sas_ds_exibir, ema_sas_ds_assunto, ema_sas_ds_para, ema_sas_ds_copia, ema_sas_ds_cco
FROM         tb_email_sas
WHERE    CONVERT(CHAR(8), ema_sas_dt_envio, 112) = '19000101'
ORDER BY ema_sas_cd_email
go

