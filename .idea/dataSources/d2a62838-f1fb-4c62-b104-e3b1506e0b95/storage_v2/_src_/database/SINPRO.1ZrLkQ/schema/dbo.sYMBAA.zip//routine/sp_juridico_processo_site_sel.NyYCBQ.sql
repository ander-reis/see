/*******************************************************************
Objeto criado: 	 sp_juridico_processo_site_sel
Descriçao:	Seleciona Processos do Professor para o Site
Data da Criaçao: 23/12/2008
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_site_sel
(
@Pcd_professor		VARCHAR(5)
)

AS
SELECT
	FIP.jur_fip_cd_professor,
	CE.Nome_Fantasia,
	PRC.jur_prc_nr_pasta,
	PRC.jur_prc_nr_processo,

	CASE jur_prc_fl_encerrado
		WHEN 0 THEN ''
		ELSE 'ENCERRADO'
	END AS jur_prc_fl_encerrado,

	CASE PRC.jur_prc_fl_execucao
		WHEN 0 THEN ''
		WHEN 1 THEN 'EM ANDAMENTO'
		WHEN 2 THEN 'ALVARÁ'
		WHEN 3 THEN 'ACORDO'
		WHEN 4 THEN 'EXECUÇÃO DE ACORDO'
		WHEN 5 THEN 'NÃO RECEBIDO'
	END AS jur_prc_fl_execucao,

	CASE PRC.jur_prc_fl_situacao
		WHEN 0 THEN 'EM ANDAMENTO'
		WHEN 1 THEN 'SENTENÇA'
		WHEN 2 THEN 'CANCELADO'
		WHEN 3 THEN 'SUBSTABELECIDO PARA TERCEIRO'
		WHEN 4 THEN 'ACORDO EM AUDIÊNCIA'
		WHEN 5 THEN 'ARQUIVAMENTO EM AUDIÊNCIA'
	END AS jur_prc_fl_situacao

FROM
	tb_jur_processo PRC 
	INNER JOIN tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha
	INNER JOIN tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha
	INNER JOIN Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola
WHERE
	FIP.jur_fip_cd_professor = @Pcd_professor
	AND FIC.jur_fic_fl_processo = 0
go

