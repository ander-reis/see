/*******************************************************************
Objeto criado: 	 sp_professor_promocao_sel
Descriçao:	Consulta as promoções em que o professor participou
Data da Criaçao: 09/06/2011
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_professor_promocao_sel
(
@Pcd_professor		NVARCHAR(6)
)

AS
	SELECT     SCS.id_sorteio, SCS.ds_sorteio, CONVERT(CHAR(10),ISNULL(SCS.dt_sorteio,'01/01/1900'),103) AS dt_sorteio, 
		CASE SIN.fl_sorteado WHEN '1' THEN 'SIM' Else 'NÃO' END AS CONTEMPLADO
	FROM         website.dbo.tb_cadastro_sorteios SCS
		INNER JOIN website.dbo.tb_cadastro_sorteios_inscritos SIN ON SCS.id_sorteio = SIN.id_sorteio
	WHERE     SIN.Codigo_Professor = @Pcd_professor
	ORDER BY SCS.id_sorteio DESC


/*

	SELECT     
	SP.id_promocao, 
	SP.ds_promocao, 
	SPP.Codigo_Professor, 
	SP.dt_promocao, 
	CASE SPP.fl_contemplado WHEN '1' THEN 'Sim' Else 'Não' END AS CONTEMPLADO
	FROM         
		tb_site_promocao SP INNER JOIN  tb_site_promocao_participantes SPP ON SP.id_promocao = SPP.id_promocao
	WHERE    
		 SPP.Codigo_Professor = @Pcd_professor
	ORDER BY SP.dt_promocao DESC
*/
go

