
/*******************************************************************
Objeto criado: 	 sp_soc_cad_escola_sel_observacoes
Descriçao:	Seleciona Observações da Escola
Entrada:	@pNvc_CNPJ  -> CNPJ da Escola
Saída:		
Data da Criaçao: 25/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_escola_sel_observacoes
(
@pNvc_CNPJ		NVARCHAR(18)
)
AS

SELECT 
	CONVERT(CHAR(10),Data,103) AS Data, 
	Observacoes,
	ISNULL(Login,'') AS Login,
	ISNULL(CONVERT(CHAR(8),Hora,108),'') AS Hora 
FROM Escola_Observacoes
WHERE CGC_Escola = @pNvc_CNPJ
ORDER BY CONVERT(CHAR(10),Data,111) DESC,
	CONVERT(CHAR(8),Hora,108) DESC

go

