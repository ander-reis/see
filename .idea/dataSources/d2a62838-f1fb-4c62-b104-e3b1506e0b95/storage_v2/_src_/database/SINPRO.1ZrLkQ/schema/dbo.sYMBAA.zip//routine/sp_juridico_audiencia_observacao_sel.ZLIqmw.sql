/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_observacao_sel
Descriçao:	Seleciona Obsercações da Audiencias
Data da Criaçao: 09/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_observacao_sel
(
@Pnr_pasta	NVARCHAR(8)
)
AS

SELECT 
	RTRIM(CASE CONVERT(CHAR(10),jur_oau_dt_observacao,103)
		WHEN '01/01/1900' THEN ''
		ELSE	CONVERT(CHAR(10),jur_oau_dt_observacao,103)
	END)					AS jur_oau_dt_observacao,

	jur_oau_ds_observacao,

	RTRIM(ISNULL(jur_oau_nm_login,''))	AS jur_oau_nm_login,

	RTRIM(CASE CONVERT(CHAR(10),jur_oau_hr_observacao,108)
		WHEN '00:00:00' THEN ''
		ELSE	CONVERT(CHAR(10),jur_oau_hr_observacao,108)
	END) 					 AS jur_oau_hr_observacao
FROM tb_jur_aud_obs
WHERE jur_oau_nr_pasta = @Pnr_pasta
ORDER BY CONVERT(CHAR(10),jur_oau_dt_observacao,111) DESC, CONVERT(CHAR(8),jur_oau_hr_observacao,108) DESC
go

