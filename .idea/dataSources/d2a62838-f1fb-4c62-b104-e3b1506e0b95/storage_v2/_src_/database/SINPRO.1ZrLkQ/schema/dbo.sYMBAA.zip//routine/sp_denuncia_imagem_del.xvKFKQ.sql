/*******************************************************************
Objeto criado: 	 sp_denuncia_imagem_del
Descriçao:	Apaga as Imagens da Denuncia
Data da Criaçao: 09/08/2011
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_denuncia_imagem_del
(
@Pcd_imagem	INT
)

AS

DELETE 
FROM
	tb_denuncia_imagem
WHERE
	den_img_cd_imagem = @Pcd_imagem
go

