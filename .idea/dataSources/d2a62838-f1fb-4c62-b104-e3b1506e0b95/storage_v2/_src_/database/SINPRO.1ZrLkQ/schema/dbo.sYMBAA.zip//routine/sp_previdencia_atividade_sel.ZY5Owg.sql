

/*******************************************************************
Objeto criado: 	 sp_previdencia_especie_sel
Descriçao:	Seleciona as atividade de um determinado período
Data da Criaçao: 10/09/2007
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_previdencia_atividade_sel
(
@Pnr_atividade	INT,
@Pdt_inicio	DATETIME,
@Pdt_fim 	DATETIME 
)
AS
SELECT 
	DISTINCT SCPG.Codigo_Professor,
	SCPG.Nome,
	PAA.prev_paa_cd_tipoatendimento,
	COUNT(SCPG.Codigo_Professor) AS QTDE
FROM         
	tb_prev_atendimento PRA INNER JOIN    tb_prev_atendimento_atividade PAA ON PRA.prev_pra_cd_previdencia = PAA.prev_paa_cd_previdencia INNER JOIN
            Soc_Cadastro_Professor_Geral SCPG ON PRA.prev_pra_cd_codprofgeral = SCPG.CodProf_Geral
WHERE
	PRA.prev_pra_fl_situacao<>'1' AND PAA.prev_paa_dt_cadastro BETWEEN @Pdt_inicio AND @Pdt_fim  AND prev_paa_cd_tipoatendimento=@Pnr_atividade
GROUP BY 
	SCPG.Nome, PAA.prev_paa_cd_tipoatendimento, PAA.prev_paa_dt_cadastro, SCPG.Codigo_Professor
ORDER BY 
	COUNT(SCPG.Codigo_Professor) DESC, SCPG.Nome
go

