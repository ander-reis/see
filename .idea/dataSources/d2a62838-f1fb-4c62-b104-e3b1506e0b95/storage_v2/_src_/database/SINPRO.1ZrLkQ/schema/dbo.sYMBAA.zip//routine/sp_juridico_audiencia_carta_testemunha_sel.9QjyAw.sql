
/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_carta_testemunha_sel
Descriçao:	Seleciona Causas do Processo para Quando for Necessário Testemunha
Data da Criaçao: 22/11/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_carta_testemunha_sel
(
@Pnr_pasta		NVARCHAR(8)
)

AS

SELECT     
	CAU.jur_cau_ds_causa AS Descricao
FROM         
	tb_jur_ficha_causa FCA INNER JOIN
	tb_jur_ficha_consulta FIC ON FCA.jur_fca_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
	tb_jur_cadastro_causa CAU ON FCA.jur_fca_cd_causa = CAU.jur_cau_cd_causa
WHERE CAU.jur_cau_fl_testemunha = 1
	AND FIC.jur_fic_nr_pasta = @Pnr_pasta
ORDER BY 
	CAU.jur_cau_ds_causa
go

