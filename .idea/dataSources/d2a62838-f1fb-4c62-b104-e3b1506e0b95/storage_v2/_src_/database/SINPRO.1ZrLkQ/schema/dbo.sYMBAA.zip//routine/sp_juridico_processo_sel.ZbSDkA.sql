
/*******************************************************************
Objeto criado: 	 sp_juridico_processo_sel
Descriçao:	Seleciona Processo para Audiência
Data da Criaçao: 08/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_sel
(
@Pnr_pasta	VARCHAR(17),
@Pfl_tipo	TINYINT = 1 
)
AS

IF @Pfl_tipo = 1
	SELECT
		CASE CONVERT(NVARCHAR(10),PRC.jur_prc_dt_cadastro, 103) 
			WHEN '01/01/1900' THEN ''
			ELSE CONVERT(NVARCHAR(10),PRC.jur_prc_dt_cadastro, 103) 
		END AS jur_prc_dt_cadastro,
		PRC.jur_prc_nm_login,
		CASE CONVERT(NVARCHAR(10),PRC.jur_prc_dt_distribuicao,103) 
			WHEN '01/01/1900' THEN ''
			ELSE CONVERT(NVARCHAR(10),PRC.jur_prc_dt_distribuicao,103)
		END AS jur_prc_dt_distribuicao,
		ADV.jur_adv_cd_advogado,
		ADV.jur_adv_nm_advogado,
		CVA.jur_cva_ds_vara,
		CVA.jur_cva_ds_complemento,
		PRC.jur_prc_nr_processo,
		PRC.jur_prc_nr_trt,
		PRC.jur_prc_nr_tst,
		PRC.jur_prc_nr_stf,
		PRC.jur_prc_fl_situacao,
		PRC.jur_prc_fl_recurso,
		PRC.jur_prc_fl_rec_execucao,
		PRC.jur_prc_fl_exe_contador,
		PRC.jur_prc_fl_execucao,
		PRC.jur_prc_fl_encerrado,
		CASE CONVERT(NVARCHAR(10),PRC.jur_prc_dt_final,103)
			WHEN '01/01/1900' THEN ''
			ELSE CONVERT(NVARCHAR(10),PRC.jur_prc_dt_final,103)
		END AS jur_prc_dt_final,
		PRC.jur_prc_nr_morto,
		CASE PRC.jur_prc_fl_procedente
			WHEN 0 THEN 'Procedente'
			WHEN 1 THEN 'Procedente em Partes'
			WHEN 2 THEN 'Improcedente'
			WHEN 3 THEN ''
			WHEN 4 THEN 'Acordo em Audiência'
		END AS jur_prc_fl_procedente,
		PRC.jur_prc_nr_ficha,
		PRC.jur_prc_cd_terceiro,	
		PRC.jur_prc_fl_rescisoria,
		PRC.jur_prc_nr_trt_rescisoria,
		PRC.jur_prc_fl_desarquivado,
		CONVERT(DECIMAL(10,2),PRC.jur_prc_vl_homologado) AS jur_prc_vl_homologado,
		PRC.jur_prc_fl_embargos,
		PRC.jur_prc_fl_darf,
		PRC.jur_prc_fl_greve,
		PRC.jur_prc_fl_pje
	FROM
		tb_jur_cadastro_vara CVA
		INNER JOIN tb_jur_processo PRC ON CVA.jur_cva_cd_vara = PRC.jur_prc_cd_vara
		INNER JOIN tb_jur_cadastro_advogado ADV ON PRC.jur_prc_cd_advogado = ADV.jur_adv_cd_advogado
	WHERE
		PRC.jur_prc_nr_pasta = @Pnr_pasta
ELSE
	SELECT
		CASE CONVERT(NVARCHAR(10),PRC.jur_prc_dt_cadastro, 103) 
			WHEN '01/01/1900' THEN ''
			ELSE CONVERT(NVARCHAR(10),PRC.jur_prc_dt_cadastro, 103) 
		END AS jur_prc_dt_cadastro,
		PRC.jur_prc_nm_login,
		CASE CONVERT(NVARCHAR(10),PRC.jur_prc_dt_distribuicao,103) 
			WHEN '01/01/1900' THEN ''
			ELSE CONVERT(NVARCHAR(10),PRC.jur_prc_dt_distribuicao,103)
		END AS jur_prc_dt_distribuicao,
		ADV.jur_adv_cd_advogado,
		ADV.jur_adv_nm_advogado,
		CVA.jur_cva_ds_vara,
		CVA.jur_cva_ds_complemento,
		PRC.jur_prc_nr_processo,
		PRC.jur_prc_nr_trt,
		PRC.jur_prc_nr_tst,
		PRC.jur_prc_nr_stf,
		PRC.jur_prc_fl_situacao,
		PRC.jur_prc_fl_recurso,
		PRC.jur_prc_fl_rec_execucao,
		PRC.jur_prc_fl_exe_contador,
		PRC.jur_prc_fl_execucao,
		PRC.jur_prc_fl_encerrado,
		CASE CONVERT(NVARCHAR(10),PRC.jur_prc_dt_final,103)
			WHEN '01/01/1900' THEN ''
			ELSE CONVERT(NVARCHAR(10),PRC.jur_prc_dt_final,103)
		END AS jur_prc_dt_final,
		PRC.jur_prc_nr_morto,
		CASE PRC.jur_prc_fl_procedente
			WHEN 0 THEN 'Procedente'
			WHEN 1 THEN 'Procedente em Partes'
			WHEN 2 THEN 'Improcedente'
			WHEN 3 THEN ''
			WHEN 4 THEN 'Acordo em Audiência'
		END AS jur_prc_fl_procedente,
		PRC.jur_prc_nr_ficha,
		PRC.jur_prc_cd_terceiro,
		PRC.jur_prc_fl_rescisoria,
		PRC.jur_prc_nr_trt_rescisoria,
		PRC.jur_prc_fl_desarquivado,
		CONVERT(DECIMAL(10,2),PRC.jur_prc_vl_homologado) AS jur_prc_vl_homologado,
		PRC.jur_prc_fl_embargos,
		PRC.jur_prc_fl_darf,
		PRC.jur_prc_fl_greve,
		PRC.jur_prc_fl_pje
	FROM
		tb_jur_cadastro_vara CVA
		INNER JOIN tb_jur_processo PRC ON CVA.jur_cva_cd_vara = PRC.jur_prc_cd_vara
		INNER JOIN tb_jur_cadastro_advogado ADV ON PRC.jur_prc_cd_advogado = ADV.jur_adv_cd_advogado
	WHERE
		PRC.jur_prc_nr_processo = @Pnr_pasta
go

