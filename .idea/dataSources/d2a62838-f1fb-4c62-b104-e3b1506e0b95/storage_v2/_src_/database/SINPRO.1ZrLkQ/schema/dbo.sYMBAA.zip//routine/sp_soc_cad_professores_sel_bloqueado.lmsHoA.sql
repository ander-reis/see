
/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_sel_bloqueado
Descriçao:	Seleciona Observações do Professor
Entrada:	@pNvc_professor  -> CPF do Professor
Saída:		
Data da Criaçao: 14/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_sel_bloqueado
(
@pNvc_professor		NVARCHAR(14)
)
AS


SELECT 
	Cadastrado_Por,
	CONVERT(CHAR(10),Data_Cadastro,103) AS Data_Cadastro,
	Motivo
FROM Professor_Bloqueado
WHERE CPF = @pNvc_professor


go

