

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_status_sel
Descriçao:	 Carrega o Status da  Ficha
Data da Criaçao: 06/03/2007
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_status_sel
(
@Pnr_ficha 		INT
)
AS

SELECT 
	CONVERT(CHAR(10),jur_fis_dt_entrevista,103) AS dt_entrevista,
	CONVERT(CHAR(10),jur_fis_dt_documentacao,103) AS dt_documentacao,
	CONVERT(CHAR(10),jur_fis_dt_analise,103) AS dt_analise,
	CONVERT(CHAR(10),jur_fis_dt_contador,103) AS dt_contador,	
	CONVERT(CHAR(10),jur_fis_dt_leitura,103) AS dt_leitura,
	CONVERT(CHAR(10),jur_fis_dt_montagem,103) AS dt_montagem,
	CONVERT(CHAR(10),jur_fis_dt_conciliacao,103) AS dt_conciliacao,
	CONVERT(CHAR(10),jur_fis_dt_acordo,103) AS dt_acordo,	
	CONVERT(CHAR(10),jur_fis_dt_conferencia,103) AS dt_conferencia,
	CONVERT(CHAR(10),jur_fis_dt_distribuir,103) AS dt_distribuir,
	CONVERT(CHAR(10),jur_fis_dt_processo,103) AS dt_processo,
	CONVERT(CHAR(10),jur_fis_dt_finalizado,103) AS dt_finalizado,
	CONVERT(CHAR(10),jur_fis_dt_cancelado,103) AS dt_cancelado
FROM 
	tb_jur_ficha_status 
WHERE 
	jur_fis_nr_ficha = @Pnr_ficha

go

