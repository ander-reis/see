/*******************************************************************
Objeto criado: 	 sp_juridico_processo_julgamento_e197_sel
Descriçao:	Seleciona Julgamentos E197 para avisar juridico
Data da Criaçao:  01/09/2014
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_julgamento_e197_sel
AS

SELECT
	PCA.jur_pca_nr_pasta,
	CONVERT(CHAR(10),PCA.jur_pca_dt_agendamento,103) AS jur_pca_dt_agendamento,
	CONVERT(CHAR(5),PCA.jur_pca_hr_agendamento,108) AS jur_pca_hr_agendamento,
	ADV.jur_adv_nm_advogado,
	ADV.jur_adv_ds_email
FROM
	tb_jur_processo_agendamento PCA
	INNER JOIN tb_jur_cadastro_advogado ADV ON PCA.jur_pca_cd_advogado = ADV.jur_adv_cd_advogado
WHERE
	PCA.jur_pca_cd_andamento = 78
	AND CONVERT(CHAR(10), PCA.jur_pca_dt_agendamento, 111) = CONVERT(CHAR(10), GETDATE(), 111)
ORDER BY
	ADV.jur_adv_nm_advogado, PCA.jur_pca_dt_agendamento DESC
go

