/*******************************************************************
Objeto criado: 	 sp_juridico_consulta_sentenca
Descriçao:	Seleciona as Sentenças dos Processos
Data da Criaçao: 14/02/2008
Autor:		Adriana- SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_processo_sentenca_sel
(
@Pdt_de		VARCHAR(8),
@Pdt_ate		VARCHAR(8),
@Pcd_sentenca	INT,
@Pcd_execucao	INT

)
AS

IF @Pcd_sentenca =0  --Específico
BEGIN
	SELECT     
		PRC.jur_prc_nr_pasta, 
		PRC.jur_prc_nr_processo, 
		CASE PRC.jur_prc_fl_execucao 
			WHEN '0' THEN 'Não Executou' 
			WHEN '1' THEN 'Andamento'
			WHEN '2' THEN 'Alvará'
			WHEN '3' THEN 'Acordo'
			WHEN '4' THEN 'Execução de Acordo'
			WHEN '5' THEN 'Não Recebido'
			END AS EXECUCAO, 
		CE.CGC_Escola, 
		CE.Razao_Social, 
		FIP.jur_fip_cd_professor,
		CP.Nome
	FROM         
		tb_jur_processo PRC INNER JOIN
                     	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE     
		PRC.jur_prc_fl_execucao = @Pcd_execucao
		AND PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_de AND @Pdt_ate 
		AND  FIP.jur_fip_cd_professor <> N'00000'
		AND FIC.jur_fic_fl_processo = 0
	UNION
	SELECT     
		PRC.jur_prc_nr_pasta, 
		PRC.jur_prc_nr_processo, 
		CASE PRC.jur_prc_fl_execucao 
			WHEN '0' THEN 'Não Executou' 
			WHEN '1' THEN 'Andamento'
			WHEN '2' THEN 'Alvará'
			WHEN '3' THEN 'Acordo'
			WHEN '4' THEN 'Execução de Acordo'
			WHEN '5' THEN 'Não Recebido'
			END AS EXECUCAO, 
		CE.CGC_Escola, 
		CE.Razao_Social, 
		FIP.jur_fip_cd_professor,
		CP.Nome
	FROM         
		tb_jur_processo PRC INNER JOIN
                     	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE     
		PRC.jur_prc_fl_execucao = @Pcd_execucao
		AND PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_de AND @Pdt_ate 
		AND  FIP.jur_fip_cd_professor = N'00000'
		AND FIC.jur_fic_fl_processo = 1
END
ELSE
BEGIN
	SELECT     
		PRC.jur_prc_nr_pasta, 
		PRC.jur_prc_nr_processo, 
		CASE PRC.jur_prc_fl_execucao 
			WHEN '0' THEN 'Não Executou' 
			WHEN '1' THEN 'Andamento'
			WHEN '2' THEN 'Alvará'
			WHEN '3' THEN 'Acordo'
			WHEN '4' THEN 'Execução de Acordo'
			WHEN '5' THEN 'Não Recebido'
			END AS EXECUCAO, 
		CE.CGC_Escola, 
		CE.Razao_Social, 
		FIP.jur_fip_cd_professor,
		CP.Nome
	FROM         
		tb_jur_processo PRC INNER JOIN
                     	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE     
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_de AND @Pdt_ate
		AND  FIP.jur_fip_cd_professor <> N'00000'
		AND FIC.jur_fic_fl_processo = 0

	UNION

	SELECT     
		PRC.jur_prc_nr_pasta, 
		PRC.jur_prc_nr_processo, 
		CASE PRC.jur_prc_fl_execucao 
			WHEN '0' THEN 'Não Executou' 
			WHEN '1' THEN 'Andamento'
			WHEN '2' THEN 'Alvará'
			WHEN '3' THEN 'Acordo'
			WHEN '4' THEN 'Execução de Acordo'
			WHEN '5' THEN 'Não Recebido'
			END AS EXECUCAO, 
		CE.CGC_Escola, 
		CE.Razao_Social, 
		FIP.jur_fip_cd_professor,
		CP.Nome
	FROM         
		tb_jur_processo PRC INNER JOIN
                     	tb_jur_ficha_consulta FIC ON PRC.jur_prc_nr_ficha = FIC.jur_fic_nr_ficha INNER JOIN
                      	Cadastro_Escolas CE ON FIC.jur_fic_cd_cnpj = CE.CGC_Escola INNER JOIN
                      	tb_jur_ficha_professor FIP ON FIC.jur_fic_nr_ficha = FIP.jur_fip_nr_ficha INNER JOIN
                      	Cadastro_Professores CP ON FIP.jur_fip_cd_professor = CP.Codigo_Professor
	WHERE     
		PRC.jur_prc_dt_distribuicao BETWEEN @Pdt_de AND @Pdt_ate
		AND  FIP.jur_fip_cd_professor = N'00000'
		AND FIC.jur_fic_fl_processo = 1

END
go

