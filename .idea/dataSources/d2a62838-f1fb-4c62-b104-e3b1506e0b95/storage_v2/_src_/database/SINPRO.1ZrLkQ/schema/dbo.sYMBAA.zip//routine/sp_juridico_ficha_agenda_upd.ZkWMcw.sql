/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_agenda_upd
Descriçao:	 Atualiza a Agenda do Advogado
Data da Criaçao: 19/09/2006
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_agenda_upd
(
@Pcd_agenda 	INT,
@Pnr_ficha 	INT
)
AS

UPDATE    tb_jur_agenda_ficha SET
	jur_agf_cd_ficha = @Pnr_ficha
WHERE
	jur_agf_cd_agenda = @Pcd_agenda

UPDATE    tb_jur_agenda_advogado SET
	jur_aag_fl_compareceu = 1
WHERE
	jur_aag_cd_agenda = @Pcd_agenda
go

