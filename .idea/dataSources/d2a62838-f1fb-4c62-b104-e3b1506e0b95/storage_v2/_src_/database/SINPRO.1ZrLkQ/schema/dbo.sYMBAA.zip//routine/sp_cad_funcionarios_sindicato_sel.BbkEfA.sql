

/*******************************************************************
Objeto criado: 	 sp_cad_funcionarios_sindicato_sel
Descriçao:	Carrega E-mail dos Funcionários Ativos
Data da Criaçao: 17/03/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE  sp_cad_funcionarios_sindicato_sel
AS

SELECT 
	Nome,
	Email
FROM Funcionarios_Sindicato
WHERE Ativo = 1
ORDER BY Nome

go

