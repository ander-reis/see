
/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_advogado_sel
Descriçao:	Seleciona Advogados
Data da Criaçao: 20/09/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_advogado_sel
(
@Pfl_ativo		INT = 0

)
AS

SELECT 
	jur_adv_cd_advogado,
	jur_adv_nm_advogado, 
	jur_adv_nr_oab,
	jur_adv_ds_email
FROM tb_jur_cadastro_advogado
WHERE jur_adv_fl_ativo = @Pfl_ativo and jur_adv_fl_sinpro = 1 AND jur_adv_fl_cargo = 1
ORDER BY jur_adv_nm_advogado
go

