
/*******************************************************************
Objeto criado: 	 sp_sel_emails
Descriçao:	Seleciona e-mails dos professores que lecionam na escola informada
Entrada:	
Saída:		
Data da Criaçao: 18/04/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_sel_emails
(
@pNvc_cd_escola		NVARCHAR(500)
)
AS

--DECLARE @teste as NVARCHAR(500)

--Altera o separador para |
SET @pNvc_cd_escola  = '''' + REPLACE(@pNvc_cd_escola, ',', ''',''') + ''''



--print @pNvc_cd_escola

SELECT     RTRIM(CP.Nome) AS Nome, RTRIM(LOWER(CP.Email)) AS EMail, ESC.Nome_Fantasia, 
                   CASE CP.Sexo 
		WHEN 0 THEN 'Prezado Professor' 
		WHEN 1 THEN 'Prezada Professora' 
	      END AS Saudacao
FROM         Cadastro_Professores CP 
	INNER JOIN  Professores_Geral_Escolas PGE ON CP.Codigo_Professor = PGE.Codigo_Professor 
	INNER JOIN  Cadastro_Escolas ESC ON PGE.CGC_Escola = ESC.CGC_Escola 
	LEFT OUTER JOIN tb_email_errado EE ON CP.Email = EE.Email
WHERE     (CP.Situacao <> 3) 
	AND (EE.Email IS NULL) 
	AND (CP.Email <> '') 
	AND (PGE.CGC_Escola IN (  @pNvc_cd_escola ))
ORDER BY CP.Nome


go

