


/*******************************************************************
Objeto criado: 	 sp_previdencia_situacao_resumo_sel
Descriçao:	Seleciona as Situacoes de Aposentadoria
Data da Criaçao: 11/09/2007
Autor:		Adriana - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_previdencia_situacao_resumo_sel
(
@Pdt_Inicio	DATETIME,
@Pdt_Fim	DATETIME

)
AS

	SELECT 
	 CASE prev_pra_fl_situacao WHEN '0' THEN 'Ativo' WHEN '1' THEN 'Cancelado' WHEN '2' THEN 'Finalizado' END AS SITUACAO, 
	COUNT(prev_pra_fl_situacao) AS QTDE
	FROM         tb_prev_atendimento
	WHERE     prev_pra_dt_entrada BETWEEN @Pdt_Inicio AND @Pdt_Fim AND prev_pra_fl_situacao<>1
	GROUP BY prev_pra_fl_situacao
	ORDER BY prev_pra_fl_situacao
go

