

/*******************************************************************
Objeto criado: 	 sp_juridico_ficha_status_upd
Descriçao:	 Cadastra o Status da  Ficha
Data da Criaçao: 06/03/2007
Autor:		 Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_ficha_status_upd
(
@Pnr_ficha 		INT,
@Pdt_status		DATETIME,
@Pfl_status	 	TINYINT
)
AS

DECLARE @Vfl_retorno 	TINYINT
IF @Pfl_status = 0  --Entrevista
	INSERT INTO tb_jur_ficha_status
		(jur_fis_nr_ficha,
		jur_fis_dt_entrevista)
	VALUES
		(@Pnr_ficha,
		@Pdt_status)

ELSE IF @Pfl_status = 1  --Documentação
	UPDATE tb_jur_ficha_status SET
		jur_fis_dt_documentacao = @Pdt_status
	WHERE jur_fis_nr_ficha = @Pnr_ficha
		
ELSE IF @Pfl_status = 2  --Analise
	SELECT @Vfl_retorno = 1 FROM tb_jur_ficha_status WHERE jur_fis_nr_ficha = @Pnr_ficha AND CONVERT(CHAR(10),jur_fis_dt_analise,103) = '01/01/1900'

	IF @Vfl_retorno = 1 
	BEGIN
		UPDATE tb_jur_ficha_status SET
			jur_fis_dt_analise = @Pdt_status
		WHERE jur_fis_nr_ficha = @Pnr_ficha

		UPDATE tb_jur_ficha_consulta SET
			jur_fic_fl_status = 2
		WHERE  jur_fic_nr_ficha = @Pnr_ficha

	END

ELSE IF @Pfl_status = 3  --Contador
	UPDATE tb_jur_ficha_status SET
		jur_fis_dt_contador = @Pdt_status
	WHERE jur_fis_nr_ficha = @Pnr_ficha

ELSE IF @Pfl_status = 4  --Leitura
	UPDATE tb_jur_ficha_status SET
		jur_fis_dt_leitura = @Pdt_status
	WHERE jur_fis_nr_ficha = @Pnr_ficha

ELSE IF @Pfl_status = 5  --Montagem
	UPDATE tb_jur_ficha_status SET
		jur_fis_dt_montagem = @Pdt_status
	WHERE jur_fis_nr_ficha = @Pnr_ficha

ELSE IF @Pfl_status = 6  --Conciliacao
	UPDATE tb_jur_ficha_status SET
		jur_fis_dt_conciliacao = @Pdt_status
	WHERE jur_fis_nr_ficha = @Pnr_ficha

ELSE IF @Pfl_status = 7  --Acordo na Conciliacao
	UPDATE tb_jur_ficha_status SET
		jur_fis_dt_acordo = @Pdt_status
	WHERE jur_fis_nr_ficha = @Pnr_ficha

ELSE IF @Pfl_status = 8  --Conferencia
	UPDATE tb_jur_ficha_status SET
		jur_fis_dt_conferencia = @Pdt_status
	WHERE jur_fis_nr_ficha = @Pnr_ficha

ELSE IF @Pfl_status = 9  --Ditribuição
	UPDATE tb_jur_ficha_status SET
		jur_fis_dt_distribuir = @Pdt_status
	WHERE jur_fis_nr_ficha = @Pnr_ficha

ELSE IF @Pfl_status = 10  --Processo
	UPDATE tb_jur_ficha_status SET
		jur_fis_dt_processo = @Pdt_status
	WHERE jur_fis_nr_ficha = @Pnr_ficha

ELSE IF @Pfl_status = 11  --Finalizado
	UPDATE tb_jur_ficha_status SET
		jur_fis_dt_finalizado = @Pdt_status
	WHERE jur_fis_nr_ficha = @Pnr_ficha

ELSE IF @Pfl_status = 12  --Cancelado
	UPDATE tb_jur_ficha_status SET
		jur_fis_dt_cancelado = @Pdt_status
	WHERE jur_fis_nr_ficha = @Pnr_ficha

go

