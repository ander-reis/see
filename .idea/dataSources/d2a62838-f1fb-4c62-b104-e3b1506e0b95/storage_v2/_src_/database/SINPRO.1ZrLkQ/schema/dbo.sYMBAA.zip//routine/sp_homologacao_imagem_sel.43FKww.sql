/*******************************************************************
Objeto criado: 	 sp_homologacao_imagem_sel
Descriçao:	Seleciona as Imagens do Cadastro do homologacao
Data da Criaçao: 16/10/2008
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_homologacao_imagem_sel
(
@Pcd_homologacao		NVARCHAR(6)
)
AS


SELECT
	IMG.hom_img_cd_imagem,
	IMG.hom_img_ds_arquivo,
	IMG.hom_img_ds_observacao,
	CONVERT(NVARCHAR(10), IMG.hom_img_dt_cadastro,103) AS hom_img_dt_cadastro,
	IMG.hom_img_nm_login,
	CONVERT(NVARCHAR(8),IMG.hom_img_dt_cadastro,108) AS hom_img_hr_cadastro
FROM
	tb_homologacao_imagem IMG
WHERE
	IMG.hom_img_cd_homologacao = @Pcd_homologacao
ORDER BY
	CONVERT(CHAR(10),IMG.hom_img_dt_cadastro,111) DESC,
	CONVERT(NVARCHAR(8),IMG.hom_img_dt_cadastro,108) DESC
go

