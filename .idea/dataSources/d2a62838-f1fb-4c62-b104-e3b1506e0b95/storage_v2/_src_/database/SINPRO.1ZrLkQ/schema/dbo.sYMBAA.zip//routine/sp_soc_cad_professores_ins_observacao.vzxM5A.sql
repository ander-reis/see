
/*******************************************************************
Objeto criado: 	 sp_soc_cad_professores_ins_observacao
Descriçao:	Inclui Observações do Professor
Entrada:	@pNvc_professor  -> CPF do Professor
Saída:		
Data da Criaçao: 14/11/2005
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_professores_ins_observacao
(
@pNvc_professor			NVARCHAR(5),
@pDt_data				DATETIME,
@pNtx_observacao			NTEXT,
@pNvc_user				VARCHAR(30),
@pDt_hora				DATETIME
)
AS

INSERT INTO Professor_Observacoes (
	Codigo_Professor,
	Data,
	Observacao,
	Login,
	Hora) 
VALUES (
	@pNvc_professor,
	CONVERT(DATETIME,@pDt_data,102),
	@pNtx_observacao,
	@pNvc_user,
	CONVERT(DATETIME,@pDt_hora,108)
	)
go

