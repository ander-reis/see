


/*******************************************************************
Objeto criado: 	 sp_eleicao_prazos_upd
Descriçao:	Alterar Prazos de Eleição
Data da Criaçao: 17/03/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_prazos_upd
(
@pInt_cd_eleicao		INT,
@pNvc_ds_eleicao	NVARCHAR(4),
@pNvc_ds_descricao	NVARCHAR(300),
@pNvc_ds_periodo	NVARCHAR(300),
@pTin_fl_lembrete	TINYINT,
@pDt_avisar		DATETIME,
@pNvc_ds_lembrete	NVARCHAR(300),
@pNvc_ds_usuarios	NVARCHAR(300),
@pTin_fl_parar		TINYINT
)
AS

UPDATE tb_ele_prazos SET
	ele_prz_ds_eleicao	= 	@pNvc_ds_eleicao,
	ele_prz_ds_descricao	=	@pNvc_ds_descricao,
	ele_prz_ds_periodo	=	@pNvc_ds_periodo,
	ele_prz_fl_lembrete	=	@pTin_fl_lembrete,
	ele_prz_dt_avisar	=	@pDt_avisar,
	ele_prz_ds_lembrete	=	@pNvc_ds_lembrete,
	ele_prz_ds_usuarios	=	@pNvc_ds_usuarios,
	ele_prz_fl_parar		=	@pTin_fl_parar
WHERE ele_prz_cd_eleicao = @pInt_cd_eleicao
go

