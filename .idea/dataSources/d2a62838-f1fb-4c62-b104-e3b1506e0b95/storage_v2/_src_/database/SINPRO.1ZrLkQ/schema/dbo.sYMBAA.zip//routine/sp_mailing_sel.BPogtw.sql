/*******************************************************************
Objeto criado: 	 sp_mailing_sel
Descriçao:	Monta mailing de professores
Saída:		
Data da Criaçao: 01/08/2012
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_mailing_sel (
@Pdt_sindicalizacao DATETIME
)

AS

SELECT     DISTINCT CP.Codigo_Professor, CP.Nome, CP.Endereco, CP.Numero, CP.Complemento, CP.Bairro, CP.Cidade, CP.Estado, CP.CEP, CE.CGC_Escola, CE.Nome_Fantasia, CP.Data_Inicio
FROM         Professores_Geral_Escolas PGE INNER JOIN
                      Cadastro_Escolas CE ON PGE.CGC_Escola = CE.CGC_Escola INNER JOIN
                      Cadastro_Professores CP ON PGE.Codigo_Professor = CP.Codigo_Professor
WHERE     CE.Ens_Superior = 0
	AND CE.CGC_Escola <> N'00.000.000/0000-00'
	AND PGE.Cobranca = 1
	AND CONVERT(CHAR(10),CP.Data_Inicio,111) BETWEEN CONVERT(CHAR(10),DATEADD(m,-1,@Pdt_sindicalizacao),111) AND CONVERT(CHAR(10),DATEADD(d,-1,@Pdt_sindicalizacao),111) 

UNION

SELECT     CP.Codigo_Professor, CP.Nome, CP.Endereco, CP.Numero, CP.Complemento, CP.Bairro, CP.Cidade, CP.Estado, CP.CEP, CE.CGC_Escola, CE.Nome_Fantasia, CP.Data_Inicio
FROM         Professores_Geral_Escolas PGE INNER JOIN
                      Cadastro_Escolas CE ON PGE.CGC_Escola = CE.CGC_Escola INNER JOIN
                      Cadastro_Professores CP ON PGE.Codigo_Professor = CP.Codigo_Professor
WHERE     (CP.Pre = 1 OR CP.[1_4Serie] = 1 OR CP.[5_8Serie] = 1 OR CP.Ens_Medio = 1 )
	AND PGE.Cobranca = 1
	AND CE.CGC_Escola IN  ( SELECT CGC_Escola FROM Cadastro_Escolas CE WHERE Razao_Social LIKE N'%MACKENZIE%' OR Nome_Fantasia LIKE N'%MACKENZIE%') 
	AND CONVERT(CHAR(10),CP.Data_Inicio,111) BETWEEN CONVERT(CHAR(10),DATEADD(m,-1,@Pdt_sindicalizacao),111) AND CONVERT(CHAR(10),DATEADD(d,-1,@Pdt_sindicalizacao),111) 
ORDER BY CP.Codigo_Professor
go

