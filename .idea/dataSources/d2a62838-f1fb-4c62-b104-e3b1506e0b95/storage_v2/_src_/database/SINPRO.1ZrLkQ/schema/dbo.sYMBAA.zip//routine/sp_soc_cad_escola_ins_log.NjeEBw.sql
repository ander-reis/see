
/*******************************************************************
Objeto criado: 	sp_soc_cad_escola_ins_log
Descriçao:	Inclui Log's do Cadastro de Escola
Entrada:	
Saída:		
Data da Criaçao: 28/11/2005
Autor:		Ronaldo Araujo (SinproSP)
*******************************************************************/

CREATE PROCEDURE sp_soc_cad_escola_ins_log
(
@pNvc_CNPJ				NVARCHAR(18),
@pNvc_user				VARCHAR(30),
@pDt_data				DATETIME
)
AS

INSERT INTO Log_Escola (
	CNPJ_Escola,
	User_Escola,
	Data_Escola) 
VALUES (
	@pNvc_CNPJ,
	@pNvc_user,
	@pDt_data)

go

