/*******************************************************************
Objeto criado: 	 sp_eleicao_agenda_upd
Descriçao:	Atualiza Distribuição de Agenda
Data da Criaçao: 20/07/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_agenda_upd
(
@Pcd_agenda		INT = 0,
@Pds_eleicao		CHAR(4) = '',
@Pds_urna		INT,
@Pdt_eleicao		DATETIME,
@Pnr_entregue		INT = 0,
@Pnr_devolvida		INT = 0
)
AS

DECLARE @Vfl_achou TINYINT
SET @Vfl_achou = 0

IF @Pcd_agenda = 0
	INSERT INTO tb_ele_agenda 
		(ele_eag_ds_eleicao,
		ele_eag_ds_urna,
		ele_eag_dt_eleicao,
		ele_eag_nr_entregue,
		ele_eag_nr_valido,
		ele_eag_nr_separado,
		ele_eag_nr_devolvida)
	VALUES
		(@Pds_eleicao,
		@Pds_urna,
		@Pdt_eleicao,
		@Pnr_entregue,
		0,
		0,
		0)

ELSE
BEGIN
	SELECT @Vfl_achou = 1 FROM tb_ele_agenda
	WHERE ele_eag_ds_eleicao = @Pds_eleicao
	AND ele_eag_ds_urna = @Pds_urna
	AND CONVERT(CHAR(10),ele_eag_dt_eleicao,111) = CONVERT(CHAR(10),@Pdt_eleicao,111)

	IF @Vfl_achou = 0 

		INSERT INTO tb_ele_agenda 
			(ele_eag_ds_eleicao,
			ele_eag_ds_urna,
			ele_eag_dt_eleicao,
			ele_eag_nr_entregue,
			ele_eag_nr_valido,
			ele_eag_nr_separado,
			ele_eag_nr_devolvida)
		VALUES
			(@Pds_eleicao,
			@Pds_urna,
			@Pdt_eleicao,
			@Pnr_entregue,
			0,
			0,
			0)
	ELSE
		UPDATE tb_ele_agenda SET
			ele_eag_nr_entregue = @Pnr_entregue,
			ele_eag_nr_devolvida = @Pnr_devolvida
		WHERE
			ele_eag_cd_agenda = @Pcd_agenda
END
go

