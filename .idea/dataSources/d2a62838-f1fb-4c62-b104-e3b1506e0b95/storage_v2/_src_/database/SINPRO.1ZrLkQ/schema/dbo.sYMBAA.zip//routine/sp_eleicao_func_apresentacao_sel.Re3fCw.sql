/*******************************************************************
Objeto criado: 	 sp_eleicao_func_apresentacao_sel
Descriçao:	Seleciona Dados para Impressão de Carta de Apresentação dos Funcionarios
Data da Criaçao: 13/10/2010
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_func_apresentacao_sel
(
@Pds_eleicao		CHAR(4),
@Pds_urna		INT
)
AS

IF @Pds_urna < 9999

	SELECT
		CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Endereco + ', ' + CE.Numero + ' -' + CE.Complemento AS Endereco, 
             		CE.Bairro + ' - ' + CE.Cidade + ' - ' + CE.Estado AS Complemento, CE.CEP, CE.Urna, FUN.ele_fun_nm_funcionario, FUN.ele_fun_ds_rg, 
                      	FUN.ele_fun_cd_funcionario, TOT.ele_dad_nr_total 
	FROM
		Cadastro_Professores CP RIGHT OUTER JOIN
                      	Cadastro_Escolas CE INNER JOIN
                      	Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
                      	tb_ele_funcionario FUN INNER JOIN
                      	tb_ele_func_dados DAD ON FUN.ele_fun_cd_funcionario = DAD.ele_dad_cd_funcionario ON CE.Urna = DAD.ele_dad_nr_urna ON 
                      	CP.Codigo_Professor = PGE.Codigo_Professor	INNER JOIN
		(SELECT ele_dad_nr_urna, COUNT(ele_dad_nr_urna) AS ele_dad_nr_total FROM tb_ele_func_dados WHERE ele_dad_ds_eleicao = @Pds_eleicao AND ele_dad_fl_aprovado = 1 AND ele_dad_nr_urna = @Pds_urna GROUP BY ele_dad_nr_urna) AS TOT ON DAD.ele_dad_nr_urna = TOT.ele_dad_nr_urna
	WHERE
		(CP.Data_Inicio <= DATEADD(month, - 6, DATEADD(day, - 1, '10/24/2018'))) AND (CP.Situacao IN (1, 5, 9, 2, 10,12,13)) AND 
                      	(PGE.CGC_Escola <> '00.000.000/0000-00') AND (CE.Categoria IN (1, 6)) AND (CE.Situacao IN (0, 1))  AND 
                      	(DAD.ele_dad_fl_aprovado = 1) AND (CE.Urna = @Pds_urna) AND (DAD.ele_dad_ds_eleicao = @Pds_eleicao) AND CE.Urna NOT IN(0,1)
	GROUP BY
		CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Situacao, CE.Categoria, CE.Estado, CE.CEP, CE.Urna, CE.Endereco, CE.Numero, 
                      	CE.Complemento, CE.Bairro, CE.Cidade, CE.ds_latitude, CE.ds_longitude, FUN.ele_fun_nm_funcionario, FUN.ele_fun_ds_rg, FUN.ele_fun_cd_funcionario, TOT.ele_dad_nr_total 
	HAVING
		 (COUNT(PGE.CPF) >= 1)
	ORDER BY
		CE.Urna, CE.CGC_Escola, CE.Razao_Social, FUN.ele_fun_nm_funcionario
ELSE IF @Pds_urna = 0
	SELECT
		CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Endereco + ', ' + CE.Numero + ' -' + CE.Complemento  AS Endereco, 
             		CE.Bairro + ' - ' + CE.Cidade + ' - ' + CE.Estado AS Complemento, CE.CEP, CE.Urna, FUN.ele_fun_nm_funcionario, FUN.ele_fun_ds_rg, 
                      	FUN.ele_fun_cd_funcionario, TOT.ele_dad_nr_total 
	FROM
		Cadastro_Professores CP RIGHT OUTER JOIN
                      	Cadastro_Escolas CE INNER JOIN
                      	Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola INNER JOIN
                      	tb_ele_funcionario FUN INNER JOIN
                      	tb_ele_func_dados DAD ON FUN.ele_fun_cd_funcionario = DAD.ele_dad_cd_funcionario ON CE.Urna = DAD.ele_dad_nr_urna ON 
                      	CP.Codigo_Professor = PGE.Codigo_Professor		INNER JOIN
		(SELECT ele_dad_nr_urna, COUNT(ele_dad_nr_urna) AS ele_dad_nr_total FROM tb_ele_func_dados WHERE ele_dad_ds_eleicao = @Pds_eleicao AND ele_dad_fl_aprovado = 1 GROUP BY ele_dad_nr_urna) AS TOT ON DAD.ele_dad_nr_urna = TOT.ele_dad_nr_urna
	WHERE
		(CP.Data_Inicio <= DATEADD(month, - 6, DATEADD(day, - 1, '10/24/2018'))) AND (CP.Situacao IN (1, 5, 9, 2, 10,12,13)) AND 
                      	(PGE.CGC_Escola <> '00.000.000/0000-00') AND (CE.Categoria IN (1, 6)) AND (CE.Situacao IN (0, 1))  AND 
                      	(DAD.ele_dad_fl_aprovado = 1) AND (DAD.ele_dad_ds_eleicao = @Pds_eleicao)  AND CE.Urna NOT IN(0,1)
	GROUP BY
		CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Situacao, CE.Categoria, CE.Estado, CE.CEP, CE.Urna, CE.Endereco, CE.Numero, 
                      	CE.Complemento, CE.Bairro, CE.Cidade, CE.ds_latitude, CE.ds_longitude, FUN.ele_fun_nm_funcionario, FUN.ele_fun_ds_rg, FUN.ele_fun_cd_funcionario, TOT.ele_dad_nr_total 
	HAVING
		 (COUNT(PGE.CPF) >= 1)
	ORDER BY
		CE.Urna, CE.CGC_Escola, CE.Razao_Social, FUN.ele_fun_nm_funcionario
ELSE IF @Pds_urna = 9999
	SELECT     CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Endereco + ', ' + CE.Numero + ' -' + CE.Complemento AS Endereco, 
             		CE.Bairro + ' - ' + CE.Cidade + ' - ' + CE.Estado AS Complemento, CE.CEP, CE.Urna
	FROM         Cadastro_Escolas CE INNER JOIN
                      Professores_Geral_Escolas PGE ON CE.CGC_Escola = PGE.CGC_Escola LEFT OUTER JOIN
                      tb_ele_func_dados DAD ON CE.Urna = DAD.ele_dad_nr_urna LEFT OUTER JOIN
                      Cadastro_Professores CP ON PGE.Codigo_Professor = CP.Codigo_Professor
	WHERE     (CP.Data_Inicio <= DATEADD(month, - 6, DATEADD(day, - 1, '10/24/2018'))) AND (CP.Situacao IN (1, 5, 9, 2, 10,12,13)) AND 
                      (PGE.CGC_Escola <> '00.000.000/0000-00') AND (CE.Categoria IN (1, 6)) AND (CE.Situacao IN (0, 1)) AND (CE.Urna NOT IN (0, 1)) AND 
                      DAD.ele_dad_cd_funcionario IS NULL
	GROUP BY
		CE.CGC_Escola, CE.Razao_Social, CE.Nome_Fantasia, CE.Situacao, CE.Categoria, CE.Estado, CE.CEP, CE.Urna, CE.Endereco, CE.Numero, 
                      	CE.Complemento, CE.Bairro, CE.Cidade, CE.ds_latitude, CE.ds_longitude
	HAVING
		 (COUNT(PGE.CPF) >= 1)
	ORDER BY
		CE.Urna, CE.CGC_Escola, CE.Razao_Social
go

