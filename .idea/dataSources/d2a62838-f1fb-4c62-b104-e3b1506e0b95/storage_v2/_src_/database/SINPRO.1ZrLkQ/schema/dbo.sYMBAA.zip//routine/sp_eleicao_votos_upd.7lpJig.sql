



/*******************************************************************
Objeto criado: 	 sp_eleicao_votos_upd
Descriçao:	Atualiza os Votos da Eleicao
Data da Criaçao: 07/07/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_eleicao_votos_upd
(
@Pds_eleicao		CHAR(4),


@Pnr_total_votos	INT = 0,
@Pnr_total_separado	INT = 0,
@Pnr_total_branco	INT = 0,
@Pnr_total_nulo	INT = 0,
@Pfl_status		TINYINT = 1,

@Pds_chapa		CHAR(2) = '',
@Pds_urna		INT = 0,
@Pdt_eleicao		DATETIME = '1900/01/01',
@Pnr_valido		INT = 0,
@Pval_branco 		INT = 0,
@Pval_nulo 		INT = 0,

@Pfl_tipo		TINYINT,

@Pnr_total_inscrito	INT = 0,
@Pnr_total_normal	INT = 0,
@Pnr_total_desprezado	INT = 0

)

AS

DECLARE
	@Vnr_total_votos 	INT,
	@Vnr_total_separado	INT,
	@Vnr_total_branco	INT,
	@Vnr_total_nulo		INT

UPDATE    tb_ele_votos_detalhe SET
	ele_evd_nr_valido	= @Pnr_valido
WHERE     ele_evd_ds_eleicao 	= @Pds_eleicao
	AND ele_evd_dt_eleicao = @Pdt_eleicao
	AND ele_evd_ds_chapa	 = @Pds_chapa
	 AND ele_evd_ds_urna = @Pds_urna

UPDATE    tb_ele_votos_detalhe SET
	ele_evd_nr_val_branco	= @Pval_branco,
	ele_evd_nr_val_nulo 	= @Pval_nulo
WHERE     ele_evd_ds_eleicao 	= @Pds_eleicao
	AND ele_evd_dt_eleicao = @Pdt_eleicao
	AND ele_evd_ds_chapa = @Pds_chapa
	AND ele_evd_ds_urna = @Pds_urna
/*
SELECT 
	@Vnr_total_votos	= SUM(ele_evd_nr_valido), 
	@Vnr_total_branco	= SUM(ele_evd_nr_val_branco) / 2,
	@Vnr_total_nulo		= SUM(ele_evd_nr_val_nulo) / 2
FROM  tb_ele_votos_detalhe
WHERE     ele_evd_ds_eleicao 	= @Pds_eleicao
	AND ele_evd_ds_urna = @Pds_urna
*/

SELECT 
	@Vnr_total_votos	= SUM(ele_evd_nr_valido), 
	@Vnr_total_branco	= SUM(ele_evd_nr_val_branco) ,
	@Vnr_total_nulo		= SUM(ele_evd_nr_val_nulo) 
FROM  tb_ele_votos_detalhe
WHERE     ele_evd_ds_eleicao 	= @Pds_eleicao
	AND ele_evd_ds_urna = @Pds_urna


UPDATE    tb_ele_votos SET
	ele_evt_nr_total_votos		= @Vnr_total_votos,
	ele_evt_nr_total_separado	= @Pnr_total_separado,
	ele_evt_nr_total_branco		= @Vnr_total_branco,
	ele_evt_nr_total_nulo		= @Vnr_total_nulo,
	ele_evt_fl_status 		= @Pfl_status,
	ele_evt_nr_inscrito		= @Pnr_total_inscrito,
	ele_evt_nr_normal		= @Pnr_total_normal,
	ele_evt_nr_desprezado		= @Pnr_total_desprezado
WHERE     ele_evt_ds_eleicao 		= @Pds_eleicao
	 AND ele_evt_ds_urna = @Pds_urna
go

