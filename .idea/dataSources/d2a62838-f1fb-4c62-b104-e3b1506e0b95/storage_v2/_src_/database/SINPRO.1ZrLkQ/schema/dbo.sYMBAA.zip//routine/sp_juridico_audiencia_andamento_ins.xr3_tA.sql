/*******************************************************************
Objeto criado: 	 sp_juridico_audiencia_andamento_ins
Descriçao:	Atualiza o Andamento do Processo
Data da Criaçao: 08/08/2006
Autor:		Ronaldo Araujo - SinproSP
*******************************************************************/

CREATE PROCEDURE sp_juridico_audiencia_andamento_ins
(
@Pnr_pasta		NVARCHAR(8),
@Pfl_audiencia		TINYINT,
@Pdt_audiencia		DATETIME,
@Phr_audiencia		CHAR(5),
@Pds_audiencia	NTEXT,
@Pnm_cadastrado	NVARCHAR(30),
@Pdt_cadastrado	DATETIME,
@Pfl_concluido		TINYINT,
@Pfl_audiencia_del	TINYINT,
@Pcd_advogado	INT
)

AS

IF @Pfl_concluido <= 1 
BEGIN
	IF @Pfl_audiencia_del <> 56
	BEGIN
		DELETE 
		FROM	
			tb_jur_processo_agendamento
		WHERE
			jur_pca_nr_pasta		= @Pnr_pasta
			AND jur_pca_cd_andamento	= @Pfl_audiencia_del
			AND  jur_pca_fl_concluido 	= 0
	
		INSERT INTO tb_jur_processo_agendamento
			(jur_pca_nr_pasta,
			jur_pca_cd_andamento,
			jur_pca_dt_agendamento,
			jur_pca_hr_agendamento,
			jur_pca_fl_concluido,
			jur_pca_ds_observacao,
			jur_pca_dt_cadastro,
			jur_pca_nm_login,
			jur_pca_cd_advogado)
		VALUES
			(@Pnr_pasta,
			@Pfl_audiencia,
			@Pdt_audiencia,
			@Phr_audiencia,	
			@Pfl_concluido,
			@Pds_audiencia,
			@Pdt_cadastrado,
			@Pnm_cadastrado,
			@Pcd_advogado)
	END
	ELSE
	BEGIN
		INSERT INTO tb_jur_processo_agendamento
			(jur_pca_nr_pasta,
			jur_pca_cd_andamento,
			jur_pca_dt_agendamento,
			jur_pca_hr_agendamento,
			jur_pca_fl_concluido,
			jur_pca_ds_observacao,
			jur_pca_dt_cadastro,
			jur_pca_nm_login,
			jur_pca_cd_advogado)
		VALUES
			(@Pnr_pasta,
			56,
			@Pdt_audiencia,
			'00:00',	
			1,	
			@Pds_audiencia,
			@Pdt_cadastrado,
			@Pnm_cadastrado,
			@Pcd_advogado)

		UPDATE tb_jur_processo_agendamento SET
			 jur_pca_cd_advogado = @Pcd_advogado
		WHERE
			jur_pca_dt_agendamento = @Pdt_audiencia
			AND jur_pca_hr_agendamento = @Phr_audiencia
			AND jur_pca_cd_andamento = @Pfl_audiencia
	END

END
ELSE
BEGIN
	UPDATE tb_jur_processo_agendamento SET
		jur_pca_ds_observacao	= @Pds_audiencia,
		jur_pca_fl_concluido	= CONVERT(TINYINT,RIGHT(CONVERT(NVARCHAR(2),@Pfl_concluido),1)),
		jur_pca_cd_advogado	= @Pcd_advogado
	WHERE 
		jur_pca_nr_pasta		= @Pnr_pasta
		AND jur_pca_cd_andamento	= @Pfl_audiencia
		AND  jur_pca_fl_concluido 	= 0
END
go

